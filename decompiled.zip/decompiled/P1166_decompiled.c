#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int score;
    int type;
    int throw_count;
} Round;

int n, top, bb, bbb;
Round a[100];
int q[100];
char b[300];
int zan[100];

void init();
void solve();
int main();

void init()
{
    n = 1;
    bb = 0;
    top = 0;
    memset(a, -1, sizeof(a));
    memset(q, -1, sizeof(q));
    memset(b, 0, sizeof(b));
    memset(zan, 0, sizeof(zan));
}
void solve()
{
    int round_idx;
    int i;
    int cumulative_sum;

    cumulative_sum = 0;
    for (i = 1; i <= 10 && i < n; ++i)
    {
        if (a[i].type)
        {
            if (a[i].type == 1)
            {
                if (q[a[i].throw_count + 1] == -1)
                {
                    n = i;
                    break;
                }
                a[i].score += q[a[i].throw_count + 1];
            }
        }
        else
        {
            if (q[a[i].throw_count + 1] == -1 || q[a[i].throw_count + 2] == -1)
            {
                n = i;
                break;
            }
            a[i].score += q[a[i].throw_count + 1] + q[a[i].throw_count + 2];
        }
        printf("%d ", a[i].score);
        cumulative_sum += a[i].score;
        zan[i] = cumulative_sum;
    }
    putchar('\n');
    for (round_idx = 1; round_idx <= 10 && round_idx < n; ++round_idx)
    {
        printf("%d ", zan[round_idx]);
    }
    putchar('\n');
}
int main()
{
    init();
    fgets(b, 300, stdin);
    bbb = strlen(b);
    while (b[bb] && n <= 12 && bb < bbb)
    {
        if (b[bb] == ' ')
        {
            ++bb;
        }
        else
        {
            if (b[bb] == '/')
            {
                a[n].score = 10;
                a[n].type = 0;
                q[++top] = 10;
                a[n++].throw_count = top;
            }
            else if (b[bb] > '0' && b[bb] <= '9')
            {
                if (a[n].score < 0)
                {
                    a[n].score = b[bb] - '0';
                    a[n].type = 2;
                    q[++top] = b[bb] - '0';
                }
                else
                {
                    a[n].score += b[bb] - '0';
                    a[n].type = 2;
                    q[++top] = b[bb] - '0';
                    ++n;
                }
            }
            ++bb;
        }
    }
    solve();
    return 0;
}