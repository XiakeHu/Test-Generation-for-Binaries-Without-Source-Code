#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define MAXN 1005
#define INF 1061109567

typedef struct {
    int d;
    int n;
} node;

typedef struct {
    int v;
    int next;
    int val;
} data;

node d[MAXN];
int pq_size;
int cnt;
int n, m;
int now;
int book[MAXN];
long long res;
data edge[MAXN * 2];
int alist[MAXN];

node pop();
void add(int u, int v, int val);
void push(node a);
int main();

node pop()
{
    node ret;
    node last;
    int child;
    int i;

    ret = d[0];
    last = d[--pq_size];
    i = 2;
    child = 1;

    while (i < pq_size)
    {
        if (d[i].d <= d[i - 1].d || d[i].n >= last.n)
        {
            if (d[i - 1].d <= last.n)
            {
                child = i - 1;
            }
        }
        else
        {
            child = i;
        }

        d[(child - 1) >> 1] = d[child];
        i = (2 * child) | 1;
    }

    d[(child - 1) >> 1] = last;
    return ret;
}

void add(int u, int v, int val)
{
    cnt++;
    edge[cnt].v = v;
    edge[cnt].val = val;
    edge[cnt].next = alist[u];
    alist[u] = cnt;
}

void push(node a)
{
    int i;
    int parent_index;
    node temp;

    pq_size = pq_size + 1;
    i = pq_size;

    while (i > 1)
    {
        parent_index = (i >> 1) - 1;
        if ((i & 1) == 0)
        {
            parent_index = parent_index + 1;
        }

        if (d[a.n].d >= d[parent_index].d)
        {
            break;
        }

        d[i - 1] = d[parent_index];
        i = i >> 1;
    }

    d[i - 1] = a;
}

int main()
{
    node temp_node;
    node temp_node2;
    int edge_weight;
    int vertex_to;
    int vertex_from;
    int current_edge_weight;
    int current_vertex_to;
    int i_outer;
    int edge_index;
    int i_init;
    int i_edges;

    scanf("%d%d", &n, &m);
    cnt = 0;
    for (i_edges = 0; i_edges < m; ++i_edges)
    {
        scanf("%d%d%d", &vertex_from, &vertex_to, &edge_weight);
        add(vertex_from, vertex_to, edge_weight);
        add(vertex_to, vertex_from, edge_weight);
    }
    for (i_init = 1; i_init <= n; ++i_init)
    {
        d[i_init].d = INF;
        d[i_init].n = i_init;
    }
    d[1].d = 0;
    temp_node = d[1];
    pq_size = 0;
    push(temp_node);
    while (pq_size > 0)
    {
        now = pop().n;
        book[now] = 1;
        for (edge_index = alist[now]; edge_index; edge_index = edge[edge_index].next)
        {
            current_vertex_to = edge[edge_index].v;
            current_edge_weight = edge[edge_index].val;
            if (!book[current_vertex_to] && d[current_vertex_to].d > d[now].d + current_edge_weight)
            {
                d[current_vertex_to].d = current_edge_weight + d[now].d;
                temp_node2 = d[current_vertex_to];
                push(temp_node2);
            }
        }
    }
    res = 0;
    for (i_outer = 1; i_outer <= n; ++i_outer)
        res += d[i_outer].d;
    printf("%lld", res);
    return 0;
}