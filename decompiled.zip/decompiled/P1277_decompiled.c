#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

typedef struct {
    int x;
    int y;
    int maxValue;
} Node;

int row[4];
int column[4];
int diagonal[2];
int puzzle[4][4];
int minx[4][4];
int numr[4];
int numc[4];
int numd[2];
Node vec[16];
int vec_size;

int checkPos(int x, int y);
bool check();
int cmp(const void *a, const void *b);
void dfs(int k);

int checkPos(int x, int y)
{
    if (x == y)
        return 0;
    if (x == 3 - y)
        return 1;
    return -1;
}
bool check()
{
    int row_index;
    int column_index;
    int diagonal_index;

    for (row_index = 0; row_index <= 3; ++row_index)
    {
        if (row[row_index])
            return false;
    }

    for (column_index = 0; column_index <= 3; ++column_index)
    {
        if (column[column_index])
            return false;
    }

    for (diagonal_index = 0; diagonal_index <= 1; ++diagonal_index)
    {
        if (diagonal[diagonal_index])
            return false;
    }

    return true;
}
int cmp(const void *a, const void *b)
{
    const Node *node_a = (const Node *)a;
    const Node *node_b = (const Node *)b;
    return node_a->maxValue - node_b->maxValue;
}
void dfs(int k)
{
    if (k == vec_size)
    {
        if (check())
        {
            for (int row_index = 0; row_index <= 3; ++row_index)
            {
                for (int col_index = 0; col_index <= 3; ++col_index)
                {
                    printf("%d ", puzzle[row_index][col_index]);
                }
                putchar('\n');
            }
            exit(0);
        }
    }
    else
    {
        int current_x = vec[k].x;
        int current_y = vec[k].y;
        int diagonal_flag = checkPos(current_x, current_y);
        
        double column_value = (double)column[current_y];
        double row_value = (double)row[current_x];
        double node_max = (double)vec[k].maxValue;
        double min_row_node = fmin(node_max, row_value);
        int max_allowed_value = (int)fmin(min_row_node, column_value);
        
        if (diagonal_flag == -1)
        {
            --numr[current_x];
            --numc[current_y];
            
            for (int try_value = max_allowed_value; try_value > 0; --try_value)
            {
                puzzle[current_x][current_y] = try_value;
                row[current_x] -= try_value;
                column[current_y] -= try_value;
                
                if ((numr[current_x] != 0) || (row[current_x] != 0))
                {
                    if ((numc[current_y] != 0) || (column[current_y] != 0))
                    {
                        dfs(k + 1);
                        puzzle[current_x][current_y] = 0;
                        row[current_x] += try_value;
                        column[current_y] += try_value;
                    }
                    else
                    {
                        puzzle[current_x][current_y] = 0;
                        row[current_x] += try_value;
                        column[current_y] += try_value;
                    }
                }
                else
                {
                    puzzle[current_x][current_y] = 0;
                    row[current_x] += try_value;
                    column[current_y] += try_value;
                }
            }
            
            ++numr[current_x];
            ++numc[current_y];
        }
        else
        {
            --numr[current_x];
            --numc[current_y];
            --numd[diagonal_flag];
            
            double diagonal_value = (double)diagonal[diagonal_flag];
            double min_diag = fmin((double)max_allowed_value, diagonal_value);
            int max_diag_value = (int)min_diag;
            
            for (int try_value = max_diag_value; try_value > 0; --try_value)
            {
                puzzle[current_x][current_y] = try_value;
                row[current_x] -= try_value;
                column[current_y] -= try_value;
                diagonal[diagonal_flag] -= try_value;
                
                if ((numr[current_x] != 0) || (row[current_x] != 0))
                {
                    if ((numc[current_y] != 0) || (column[current_y] != 0))
                    {
                        if ((numd[diagonal_flag] != 0) || (diagonal[diagonal_flag] != 0))
                        {
                            dfs(k + 1);
                            puzzle[current_x][current_y] = 0;
                            row[current_x] += try_value;
                            column[current_y] += try_value;
                            diagonal[diagonal_flag] += try_value;
                        }
                        else
                        {
                            puzzle[current_x][current_y] = 0;
                            row[current_x] += try_value;
                            column[current_y] += try_value;
                            diagonal[diagonal_flag] += try_value;
                        }
                    }
                    else
                    {
                        puzzle[current_x][current_y] = 0;
                        row[current_x] += try_value;
                        column[current_y] += try_value;
                        diagonal[diagonal_flag] += try_value;
                    }
                }
                else
                {
                    puzzle[current_x][current_y] = 0;
                    row[current_x] += try_value;
                    column[current_y] += try_value;
                    diagonal[diagonal_flag] += try_value;
                }
            }
            
            ++numr[current_x];
            ++numc[current_y];
            ++numd[diagonal_flag];
        }
    }
}
int main()
{
    int value;
    int y;
    int x;
    int j2;
    int i8;
    int i7;
    int i6;
    int i5;
    int i4;
    int sum0;
    int j1;
    int j0;
    int j;
    int sum;
    int i3;
    int i2;
    int i1;
    int i0;
    int i;

    for (i = 0; i <= 3; ++i) {
        scanf("%d", &row[i]);
        numr[i] = 4;
    }
    for (i0 = 0; i0 <= 3; ++i0) {
        scanf("%d", &column[i0]);
        numc[i0] = 4;
    }
    for (i1 = 0; i1 <= 1; ++i1) {
        scanf("%d", &diagonal[i1]);
        numd[i1] = 4;
    }
    memset(puzzle, 0, sizeof(puzzle));
    for (i2 = 0; i2 <= 3; ++i2)
    {
        scanf("%d %d %d", &x, &y, &value);
        puzzle[x][y] = value;
    }
    for (i3 = 0; i3 <= 3; ++i3)
    {
        sum = row[i3];
        for (j = 0; j <= 3; ++j)
            sum -= puzzle[i3][j];
        for (j0 = 0; j0 <= 3; ++j0)
            minx[i3][j0] = sum;
        row[i3] = sum;
    }
    for (j1 = 0; j1 <= 3; ++j1)
    {
        sum0 = column[j1];
        for (i4 = 0; i4 <= 3; ++i4)
            sum0 -= puzzle[i4][j1];
        for (i5 = 0; i5 <= 3; ++i5)
            minx[i5][j1] = (int)fmin((double)sum0, (double)minx[i5][j1]);
        column[j1] = sum0;
    }
    diagonal[0] -= puzzle[2][2] + puzzle[1][1] + puzzle[0][0] + puzzle[3][3];
    diagonal[1] -= puzzle[2][1] + puzzle[1][2] + puzzle[0][3] + puzzle[3][0];
    for (i6 = 0; i6 <= 3; ++i6)
    {
        minx[0][5 * i6] = (int)fmin((double)diagonal[0], (double)minx[0][5 * i6]);
        if (puzzle[0][5 * i6])
            --numd[0];
    }
    for (i7 = 0; i7 <= 3; ++i7)
    {
        minx[i7][3 - i7] = (int)fmin((double)diagonal[1], (double)minx[i7][3 - i7]);
        if (puzzle[i7][3 - i7])
            --numd[1];
    }
    vec_size = 0;
    for (i8 = 0; i8 <= 3; ++i8)
    {
        for (j2 = 0; j2 <= 3; ++j2)
        {
            if (puzzle[i8][j2])
            {
                --numr[i8];
                --numc[j2];
            }
            else
            {
                vec[vec_size].x = i8;
                vec[vec_size].y = j2;
                vec[vec_size].maxValue = minx[i8][j2];
                vec_size++;
            }
        }
    }
    qsort(vec, vec_size, sizeof(Node), cmp);
    dfs(0);
    return 0;
}