#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

void readInt(int *x) ;
int main() ;
void readInt(int *x)
{
    char ch;
    int sign;

    *x = 0;
    sign = 1;
    ch = getchar();
    while ((unsigned int)(ch - '0') > 9) {
        if (ch == '-')
            sign = 0;
        else
            sign = 1;
        ch = getchar();
    }
    while ((unsigned int)(ch - '0') <= 9) {
        *x = 10 * *x + ch - '0';
        ch = getchar();
    }
    if (!sign)
        *x = -*x;
}
int main()
{
    int n;
    int h[1000];
    int z[1000];
    int vis[1000][1000] = {0};

    readInt(&n);
    int min_h = 500;
    int max_h = 0;
    int min_z = 500;
    int max_z = 0;
    for (int i = 1; i <= n; ++i)
    {
        readInt(&h[i]);
        readInt(&z[i]);
        if (min_h <= h[i] + 204)
            min_h = min_h;
        else
            min_h = h[i] + 205;
        if (max_h < h[i] + 205)
            max_h = h[i] + 205;
        if (min_z <= z[i] + 204)
            min_z = min_z;
        else
            min_z = z[i] + 205;
        if (max_z < z[i] + 205)
            max_z = z[i] + 205;
    }
    h[0] = h[n];
    z[0] = z[n];
    for (int i = 1; i <= n; ++i)
    {
        if (h[i] == h[i - 1])
        {
            int start = (z[i - 1] <= z[i]) ? z[i - 1] : z[i];
            int end = (z[i - 1] >= z[i]) ? z[i - 1] : z[i];
            for (int k = start; k < end; ++k)
                vis[h[i] + 205][k + 205] = 1;
        }
    }
    int ans = 0;
    for (int i = min_z; i <= max_z; ++i)
    {
        int segment_sum = 0;
        int segment_start = 0;
        int in_segment = 0;
        for (int k = min_h; k <= max_h; ++k)
        {
            if (vis[k][i])
            {
                if (in_segment)
                {
                    segment_sum += k - segment_start;
                    in_segment = 0;
                }
                else
                {
                    segment_start = k;
                    in_segment = 1;
                }
            }
        }
        ans += segment_sum;
    }
    printf("%d", ans);
    return 0;
}
