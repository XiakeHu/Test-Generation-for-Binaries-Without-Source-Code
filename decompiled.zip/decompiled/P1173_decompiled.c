#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int x;
    int y;
}Point;

int h, w, n;
void sol() ;
 int main() ;
void sol()
{
    int i;
    scanf("%d %d %d", &h, &w, &n);
    for (i = 0; i < n; ++i)
        scanf("%d %d\n", (int*)(8LL * i + 4210784), (int*)(8LL * i + 4210788));
}
int main()
{
    int test_case_count;
    int i;

    scanf("%d", &test_case_count);
    for (i = 0; i < test_case_count; ++i)
        sol();
    return 0;
}