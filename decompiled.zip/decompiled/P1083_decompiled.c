#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int l, r, minn, p;
} node;

int n, m;
int a[100005];
node tree[400020];

void pushdown(int x);
void build(int x, int l, int r);
void update_qj(int x, int l, int r, int v);
int main();

void pushdown(int x)
{
    tree[2 * x].p += tree[x].p;
    tree[2 * x + 1].p += tree[x].p;
    tree[2 * x].minn += tree[x].p;
    tree[2 * x + 1].minn += tree[x].p;
    tree[x].p = 0;
}
void build(int x, int l, int r)
{
    tree[x].p = 0;
    tree[x].l = l;
    tree[x].r = r;
    if (l == r)
    {
        tree[x].minn = a[l];
    }
    else
    {
        int mid = (l + r) >> 1;
        build(2 * x, l, mid);
        build(2 * x + 1, mid + 1, r);
        int left_min = tree[2 * x].minn;
        int right_min = tree[2 * x + 1].minn;
        tree[x].minn = (left_min < right_min) ? left_min : right_min;
    }
}
void update_qj(int x, int l, int r, int v)
{
    int min_value;
    int mid;

    if (l == tree[x].l && r == tree[x].r)
    {
        tree[x].p += v;
        tree[x].minn += v;
    }
    else
    {
        if (tree[x].p)
            pushdown(x);
        mid = (tree[x].l + tree[x].r) >> 1;
        if (r > mid)
        {
            if (l <= mid)
            {
                update_qj(2 * x, l, mid, v);
                update_qj(2 * x + 1, mid + 1, r, v);
            }
            else
            {
                update_qj(2 * x + 1, l, r, v);
            }
        }
        else
        {
            update_qj(2 * x, l, r, v);
        }
        min_value = tree[2 * x].minn;
        if (tree[2 * x + 1].minn <= min_value)
            min_value = tree[2 * x + 1].minn;
        tree[x].minn = min_value;
    }
}
int main()
{
    int decrement_value;
    int left_index;
    int right_index;
    int i_outer;
    int i_inner;

    scanf("%d%d", &n, &m);
    for (i_inner = 1; i_inner <= n; ++i_inner)
        scanf("%d", &a[i_inner]);
    build(1, 1, n);
    for (i_outer = 1; i_outer <= m; ++i_outer)
    {
        scanf("%d%d%d", &decrement_value, &left_index, &right_index);
        update_qj(1, left_index, right_index, -decrement_value);
        if (tree[1].minn < 0)
        {
            puts("-1");
            return 0;
        }
    }
    puts("0");
    return 0;
}