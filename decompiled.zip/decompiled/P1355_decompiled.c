#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int x;
    int y;
} sb;

int cmp(const void *a, const void *b);
void zhuan(char *s, int i, sb *e);

int cmp(const void *a, const void *b)
{
    const sb *point_a = (const sb *)a;
    const sb *point_b = (const sb *)b;

    if (point_a->x == point_b->x)
    {
        return point_a->y - point_b->y;
    }
    else
    {
        return point_a->x - point_b->x;
    }
}
void zhuan(char *s, int i, sb *e)
{
    e[i].x = 0;
    e[i].y = 0;
    int digit_index = 1;
    int multiplier = 1;
    while (s[digit_index] > 47 && s[digit_index] <= 57)
    {
        int temp_index = digit_index++;
        e[i].x = multiplier * e[i].x + s[temp_index] - 48;
        multiplier *= 10;
    }
    int second_digit_index = digit_index + 1;
    int second_multiplier = 1;
    while (s[second_digit_index] > 47 && s[second_digit_index] <= 57)
    {
        int temp_index = second_digit_index++;
        e[i].y = second_multiplier * e[i].y + s[temp_index] - 48;
        second_multiplier *= 10;
    }
}
int main()
{
    sb e[4];
    char s[4][256];
    int flag;
    int ans;
    int i_0;
    int i;

    ans = 0;
    flag = 0;
    for (i = 0; i <= 3; ++i)
    {
        scanf("%s", s[i]);
        zhuan(s[i], i, e);
    }
    qsort(e, 4, sizeof(sb), cmp);
    for (i_0 = 0; i_0 <= 3; ++i_0)
    {
        e[i_0].x *= 100000000;
        e[i_0].y *= 100000000;
    }
    return 0;
}