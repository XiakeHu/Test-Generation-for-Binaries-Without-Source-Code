#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

void solve_int(const int *pn, const int *pm, const int *px, int *pa) ;
 int a, n, m, x;  int main() ;
void solve_int(const int *pn, const int *pm, const int *px, int *pa)
{
}
int main()
{
    scanf("%d %d %d %d", &a, &n, &m, &x);
    solve_int(&n, &m, &x, &a);
    return 0;
}
