#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

 int main() ;
int main()
{
    int digits[9] = {0};
    long long input_value;
    long long temp_value;
    long long reversed_value = 0;
    int digit_index;
    int i;

    memset(digits, 0, sizeof(digits));
    scanf("%lld", &input_value);

    if (input_value >= 0)
        temp_value = input_value;
    else
        temp_value = -input_value;

    for (digit_index = 8; digit_index >= 0; --digit_index)
    {
        digits[digit_index] = (int)(temp_value % 10);
        temp_value /= 10;
        if (!temp_value)
            break;
    }

    for (i = 8; i >= 0; --i)
    {
        reversed_value = 10 * reversed_value + digits[i];
        if (!digits[i])
        {
            if (i)
                break;
        }
    }

    if (input_value < 0)
        reversed_value = -reversed_value;

    printf("%lld", reversed_value);
    return 0;
}
