#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

#define MAX_N 1005
#define MAX_M 2005

typedef struct {
    int to;
    int nxt;
    int w;
} Edge;

Edge edge[MAX_M];
int head[MAX_N];
int num_edge;
int n, k, l;
int zjq[MAX_N];
int dis[MAX_N];

void dfs(int s, int fa);
void add_edge(int from, int to, int w);
int main();

void dfs(int s, int fa) {
    int father_edge_index = 0;
    bool has_child = false;
    int child_node;
    int temp_distance;

    for (int edge_index = head[s]; edge_index != 0; edge_index = edge[edge_index].nxt) {
        child_node = edge[edge_index].to;
        if (child_node == fa) {
            father_edge_index = edge_index;
        } else {
            if (edge[edge_index].w >= l) {
                puts("No solution.");
                exit(0);
            }
            dfs(child_node, s);
            has_child = true;
            zjq[s] += zjq[child_node];
            temp_distance = dis[child_node] + edge[edge_index].w;
            if (temp_distance < dis[s]) {
                temp_distance = dis[s];
            }
            dis[s] = temp_distance;
        }
    }

    if (!has_child) {
        zjq[s] = 0;
        dis[s] = 1;
    } else if (s != 1 && dis[s] + edge[father_edge_index].w >= l) {
        ++zjq[s];
        dis[s] = 1;
    }
}

void add_edge(int from, int to, int w)
{
    int new_edge_index = ++num_edge;
    int previous_head = head[from];
    
    edge[new_edge_index].to = to;
    edge[new_edge_index].nxt = previous_head;
    edge[new_edge_index].w = w;
    
    head[from] = new_edge_index;
}

int main()
{
    int w;
    int to;
    int j;
    int i;

    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
    {
        scanf("%d", &k);
        for (j = 1; j <= k; ++j)
        {
            scanf("%d %d", &to, &w);
            add_edge(i, to, w);
        }
    }
    scanf("%d", &l);
    dfs(1, 0x7FFFFFFF);
    printf("%d\n", zjq[1]);
    return 0;
}