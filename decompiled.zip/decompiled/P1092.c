#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
#include<stdbool.h>
#define N 25 + 2
char a[N],b[N],c[N];
int num[N],n,k[N];
bool pan[N],ban[N];

int compare(const void *a, const void *b) {
    return ( *(int*)a - *(int*)b );
}

bool pd(int i) {
     while(i--) {
         if(pan[a[i]]  && pan[b[i]]  && pan[c[i]]) {
             int k=num[a[i]]+num[b[i]];int x=num[c[i]];
             if((k+1)%n==x || k%n==x || (k+n-1)%n==x) continue;
            else return true;
           }
       }
     return false;
}
void dfs(int temp) {
    if(temp  == -1) {
        for(int i=0;i<n;i++) printf("%d ",num[i]);
        exit(0);
      } else {
        if(pd(temp)) return;
        if(pan[a[temp]]  && pan[b[temp]]  && pan[c[temp]]) {
            if((num[a[temp]]+num[b[temp]]+k[temp])%n == num[c[temp]]) {
                k[temp-1]+=(num[a[temp]]+num[b[temp]]+k[temp])/n;
                dfs(temp-1);
                k[temp-1]-=(num[a[temp]]+num[b[temp]]+k[temp])/n;
              }
            else return;
          }
      }
}
int main() {
    scanf("%d",&n);
    scanf("%s%s%s",a,b,c);
    for(int i=0;i<n;i++) {
        a[i]-='A';
        b[i]-='A';
        c[i]-='A';
      }
    dfs(n-1);
    return 0;
}
