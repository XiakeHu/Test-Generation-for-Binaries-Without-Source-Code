#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>

char ans[20] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J'};
char answer[100] = "l";
char c[100] = "l";
int i, m, t = 1, len, j, l, ll, sum, kkk;

void change(int a) {
    int k = a % m;
    int next_a = a / m;
    if (next_a > 0)
        change(next_a);
    answer[t++] = ans[k];
}

int main() {
    if (scanf("%d", &m) != 1) return 0;
    for(i = 1; i <= 300; i++) {
        kkk = 0;
        t = 1;
        answer[0] = 'l';
        sum = i * i;
        change(sum);
        answer[t] = '\0';
        len = strlen(answer) - 1;
        
        for(j = 1, l = len; j < l; j++, l--) {
            if(answer[l] != answer[j]) {
                kkk = 1;
                break;
            }
        }
        
        if(kkk == 0) {
            strcpy(c, answer);
            
            t = 1;
            answer[0] = 'l';
            change(i);
            answer[t] = '\0';
            int len_i = strlen(answer) - 1;
            
            for(ll = 1; ll <= len_i; ll++)
                printf("%c", answer[ll]);
                
            printf(" ");
            
            for(ll = 1; ll <= len; ll++)
                printf("%c", c[ll]);
                
            printf("\n");
        }
    }
    
    return 0;
}