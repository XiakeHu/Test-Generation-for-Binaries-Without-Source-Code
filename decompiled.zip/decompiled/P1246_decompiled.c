#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

char input[100];
int cnt;
char a[100];

void init_1();
void init_3();
void init_2();
void init_6();
void init_4();
void init_5();
int main();

void init_1()
{
    int current_char;

    for (current_char = 97; current_char <= 122; ++current_char)
    {
        if (current_char == input[0])
        {
            printf("%d\n", ++cnt);
            return;
        }
        a[strlen(a)] = current_char;
        ++cnt;
        memset(a, 0, sizeof(a));
    }
}

void init_3()
{
    int i;
    int j;
    int k;

    for (i = 97; i <= 122; ++i)
    {
        for (j = i + 1; j <= 122; ++j)
        {
            for (k = j + 1; k <= 122; ++k)
            {
                if (i == input[0] && j == input[1] && k == input[2])
                {
                    printf("%d\n", ++cnt);
                    return;
                }
                a[strlen(a)] = i;
                a[strlen(a)] = j;
                a[strlen(a)] = k;
                ++cnt;
                memset(a, 0, sizeof(a));
            }
        }
    }
}

void init_2()
{
    int outer_char;
    int inner_char;

    for (outer_char = 97; outer_char <= 122; ++outer_char)
    {
        for (inner_char = outer_char + 1; inner_char <= 122; ++inner_char)
        {
            if (outer_char == input[0] && inner_char == input[1])
            {
                printf("%d\n", ++cnt);
                return;
            }
            a[strlen(a)] = outer_char;
            a[strlen(a)] = inner_char;
            ++cnt;
            memset(a, 0, sizeof(a));
        }
    }
}

void init_6()
{
    int char_j;
    int char_i;
    int char_k;
    int char_l;
    int char_m;
    int char_n;

    for (char_n = 97; char_n <= 122; ++char_n)
    {
        for (char_m = char_n + 1; char_m <= 122; ++char_m)
        {
            for (char_l = char_m + 1; char_l <= 122; ++char_l)
            {
                for (char_k = char_l + 1; char_k <= 122; ++char_k)
                {
                    for (char_i = char_k + 1; char_i <= 122; ++char_i)
                    {
                        for (char_j = char_i + 1; char_j <= 122; ++char_j)
                        {
                            if (char_n == input[0] && char_m == input[1] && char_l == input[2] && char_k == input[3] && char_i == input[4] && char_j == input[5])
                            {
                                printf("%d\n", ++cnt);
                                return;
                            }
                            a[strlen(a)] = (char)char_n;
                            a[strlen(a)] = (char)char_m;
                            a[strlen(a)] = (char)char_l;
                            a[strlen(a)] = (char)char_k;
                            a[strlen(a)] = (char)char_i;
                            a[strlen(a)] = (char)char_j;
                            ++cnt;
                            memset(a, 0, sizeof(a));
                        }
                    }
                }
            }
        }
    }
}

void init_4()
{
    int char1;
    int char2;
    int char3;
    int char4;

    for (char1 = 97; char1 <= 122; ++char1)
    {
        for (char2 = char1 + 1; char2 <= 122; ++char2)
        {
            for (char3 = char2 + 1; char3 <= 122; ++char3)
            {
                for (char4 = char3 + 1; char4 <= 122; ++char4)
                {
                    if (char1 == input[0] && char2 == input[1] && char3 == input[2] && char4 == input[3])
                    {
                        printf("%d\n", ++cnt);
                        return;
                    }
                    a[strlen(a)] = char1;
                    a[strlen(a)] = char2;
                    a[strlen(a)] = char3;
                    a[strlen(a)] = char4;
                    ++cnt;
                    memset(a, 0, sizeof(a));
                }
            }
        }
    }
}

void init_5()
{
    int char_m;
    int char_l;
    int char_k;
    int char_i;
    int char_j;

    for (char_m = 97; char_m <= 122; ++char_m)
    {
        for (char_l = char_m + 1; char_l <= 122; ++char_l)
        {
            for (char_k = char_l + 1; char_k <= 122; ++char_k)
            {
                for (char_i = char_k + 1; char_i <= 122; ++char_i)
                {
                    for (char_j = char_i + 1; char_j <= 122; ++char_j)
                    {
                        if (char_m == input[0] && char_l == input[1] && char_k == input[2] && char_i == input[3] && char_j == input[4])
                        {
                            printf("%d\n", ++cnt);
                            return;
                        }
                        a[strlen(a)] = (char)char_m;
                        a[strlen(a)] = (char)char_l;
                        a[strlen(a)] = (char)char_k;
                        a[strlen(a)] = (char)char_i;
                        a[strlen(a)] = (char)char_j;
                        ++cnt;
                        memset(a, 0, sizeof(a));
                    }
                }
            }
        }
    }
}

int main()
{
    int i;

    scanf("%s", input);
    if (strlen(input) == 1)
    {
        cnt = 0;
        init_1();
        return 0;
    }
    else
    {
        for (i = 1; i < strlen(input); ++i)
        {
            if (input[i] <= input[i - 1])
            {
                puts("0");
                return 0;
            }
        }
        if (strlen(input) == 2)
        {
            cnt = 26;
            init_2();
            return 0;
        }
        else if (strlen(input) == 3)
        {
            cnt = 351;
            init_3();
            return 0;
        }
        else if (strlen(input) == 4)
        {
            cnt = 2951;
            init_4();
            return 0;
        }
        else if (strlen(input) == 5)
        {
            cnt = 17901;
            init_5();
            return 0;
        }
        else
        {
            if (strlen(input) == 6)
            {
                cnt = 83681;
                init_6();
            }
            return 0;
        }
    }
}