#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int value;
} Pair;

int merge(Pair *a, int l, int mid, int r);
void reverse(int *first, int *last);
int mergeSort(Pair *a, int l, int r);
void next_permutation(int *first, int *last);
int SmallSum(Pair *a, int len);
int main();

int merge(Pair *a, int l, int mid, int r)
{
    Pair *array = a;
    int left = l;
    int middle = mid;
    int right = r;
    int count = 0;
    int p1 = l;
    int p2 = mid + 1;
    int temp_size = r - l + 1;
    Pair *temp_array = (Pair *)alloca(temp_size * sizeof(Pair));
    int temp_index = 0;

    while (p1 <= middle && p2 <= right)
    {
        int increment = 0;
        if (array[p1].value > array[p2].value)
        {
            increment = middle - p1 + 1;
        }
        count += increment;

        int copy_index;
        if (array[p1].value > array[p2].value)
        {
            copy_index = p2++;
        }
        else
        {
            copy_index = p1++;
        }
        temp_array[temp_index++] = array[copy_index];
    }

    while (p1 <= middle)
    {
        int copy_index = p1++;
        temp_array[temp_index++] = array[copy_index];
    }

    while (p2 <= right)
    {
        int copy_index = p2++;
        temp_array[temp_index++] = array[copy_index];
    }

    for (int i = 0; i < temp_index; ++i)
    {
        array[left + i] = temp_array[i];
    }

    return count;
}

void reverse(int *first, int *last)
{
    int temp_value;

    while (first != last)
    {
        if (--last == first)
            break;
        temp_value = *first;
        *first = *last;
        *last = temp_value;
        ++first;
    }
}

int mergeSort(Pair *a, int l, int r)
{
    int left_count;
    int total_count;
    int mid;

    if (l == r)
        return 0;

    mid = (r - l) / 2 + l;
    left_count = mergeSort(a, l, mid);
    total_count = mergeSort(a, mid + 1, r) + left_count;
    return total_count + merge(a, l, mid, r);
}

void next_permutation(int *first, int *last)
{
    int temp_value;
    int *current;
    int *next;
    int *swap_target;

    if (first != last && first + 1 != last)
    {
        current = last - 1;
        while (1)
        {
            next = current;
            --current;
            if (*current < *next)
                break;
            if (current == first)
            {
                reverse(first, last);
                return;
            }
        }
        swap_target = last;
        do
        {
            --swap_target;
        } while (*current >= *swap_target);
        temp_value = *current;
        *current = *swap_target;
        *swap_target = temp_value;
        reverse(next, last);
    }
}

int SmallSum(Pair *a, int len)
{
    if (len > 1)
        return mergeSort(a, 0, len - 1);
    else
        return 0;
}

int main()
{
    int i;
    int j;
    int k;
    int n, m;
    int calendar[100];
    Pair calendar_c[100];

    scanf("%d %d", &n, &m);
    for (i = 0; i < n; ++i)
    {
        calendar[i] = i + 1;
        calendar_c[i].value = calendar[i];
    }
    while (SmallSum(calendar_c, n) != m)
    {
        next_permutation(calendar, calendar + n);
        for (j = 0; j < n; ++j)
            calendar_c[j].value = calendar[j];
    }
    for (k = 0; k < n; ++k)
        printf("%d ", calendar[k]);
    return 0;
}