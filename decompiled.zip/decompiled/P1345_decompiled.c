#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int first;
    int second;
}Pair;

int compare(const void *a, const void *b) ;
void sort(int *v, size_t n) ;
void f_int(int *x) ;
int main(int argc, const char **argv, const char **envp) ;
int compare(const void *a, const void *b)
{
    const int *first_value = (const int *)a;
    const int *second_value = (const int *)b;
    return *first_value - *second_value;
}
void sort(int *v, size_t n)
{
    qsort(v, n, sizeof(int), compare);
}
void f_int(int *x)
{
    scanf("%d", x);
}
int main(int argc, const char **argv, const char **envp)
{
    int x;
    int max_val;
    int n;
    int *v;

    n = 10;
    v = (int *)malloc(4 * n);
    max_val = 2;
    sort(v, n);
    f_int(&x);
    free(v);
    return 0;
}