#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

 int n, m; int Map[1001][1001]; int DP[1001][1001];  int main() ;
int main()
{
    int x, y;
    int i, j;

    scanf("%d %d", &n, &m);
    for (i = 1; i <= n; ++i)
    {
        for (j = 1; j <= n; ++j)
            Map[i][j] = 1;
    }
    for (i = 0; i < m; ++i)
    {
        scanf("%d %d", &x, &y);
        Map[x][y] = 0;
    }
    for (i = 1; i <= n && Map[i][1]; ++i)
        DP[i][1] = 1;
    for (i = 1; i <= n && Map[1][i]; ++i)
        DP[1][i] = 1;
    for (i = 2; i <= n; ++i)
    {
        for (j = 2; j <= n; ++j)
        {
            if (Map[i][j])
                DP[i][j] = (DP[i - 1][j] + DP[i][j - 1]) % 100003;
        }
    }
    printf("%d\n", DP[n][n]);
    return 0;
}
