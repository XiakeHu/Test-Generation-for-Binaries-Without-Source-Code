#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

void dr(int x, int y, int deep) ;
 char mp[2050 * 2050]; int n;  void dr(int x, int y, int deep) ;
void dr(int x, int y, int deep)
{
    if (deep == 1)
    {
        mp[2050 * x + y] = '/';
        mp[2050 * x + 1 + y] = '\\';
        mp[2050 * x + 2049 + y] = '/';
        mp[2050 * x + 2050 + y] = '_';
        mp[2050 * x + 2051 + y] = '_';
        mp[2050 * x + 2052 + y] = '\\';
    }
    else
    {
        dr(x, y, deep - 1);
        int offset = (int)pow(2.0, (double)(deep - 1));
        int left_y = (int)((double)y - offset);
        dr(x + offset, left_y, deep - 1);
        int right_y = (int)((double)y + offset);
        dr(x + offset, right_y, deep - 1);
    }
}
int main()
{
    scanf("%d", &n);
    
    int max_i = (int)pow(2.0, (double)n);
    int max_j = (int)pow(2.0, (double)(n + 1));
    
    for (int i = 1; i <= max_i; ++i)
    {
        for (int j = 1; j <= max_j; ++j)
        {
            mp[2050 * i + j] = ' ';
        }
    }
    
    int start_y = (int)pow(2.0, (double)n);
    dr(1, start_y, n);
    
    for (int i = 1; i <= max_i; ++i)
    {
        for (int j = 1; j <= max_j; ++j)
        {
            putchar(mp[2050 * i + j]);
        }
        putchar('\n');
    }
    
    return 0;
}
