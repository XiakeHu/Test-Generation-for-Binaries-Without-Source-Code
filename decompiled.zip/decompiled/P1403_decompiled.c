#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef long long ll;
int d[1000010];
int flg[1000010];
int pr[1000010];
int f[1000010];

int gi()
{
    int result;
    char ch;
    int sign;
    int value;

    value = 0;
    sign = 1;
    ch = getchar();
    while (ch <= 47 || ch > 57)
    {
        if (ch == '-')
        {
            sign = -1;
        }
        else
        {
            sign = sign;
        }
        ch = getchar();
    }
    while (ch > 47 && ch <= 57)
    {
        value = 10 * value + ch - '0';
        ch = getchar();
    }
    result = sign * value;
    return result;
}
int main()
{
    int n;
    int i;
    int i_0;
    int j;
    int i_1;
    ll m;

    n = gi();
    for (i = 1; i <= n; ++i)
        d[i] = 1;

    for (i_0 = 2; i_0 <= n; ++i_0)
    {
        if (!flg[i_0])
        {
            pr[++pr[0]] = i_0;
            d[i_0] = 2;
            f[i_0] = 1;
        }
        for (j = 1; i_0 * pr[j] <= n && j <= pr[0]; ++j)
        {
            flg[i_0 * pr[j]] = 1;
            if (i_0 % pr[j] == 0)
            {
                f[i_0 * pr[j]] = f[i_0] + 1;
                d[i_0 * pr[j]] = d[i_0] / (f[i_0] + 1) * (f[i_0 * pr[j]] + 1);
                break;
            }
            f[i_0 * pr[j]] = 1;
            d[i_0 * pr[j]] = 2 * d[i_0];
        }
    }

    m = 0LL;
    for (i_1 = 1; i_1 <= n; ++i_1)
        m += d[i_1];

    printf("%lld", m);
    return 0;
}