#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int x;
    int y;
} pair_t;

#define MAX_A 1505
#define MAX_B 1505

int a, b;
int vis[MAX_A][MAX_B];
short UpL[MAX_A][MAX_B][2];
int dir[4][2] = {{1,0},{-1,0},{0,1},{0,-1}};

int front, rear;
pair_t queue[MAX_A * MAX_B];

int empty() {
    return front == rear;
}
void push(pair_t p) {
    int index = rear++;
    queue[index] = p;
}
pair_t pop() {
    int current_front = front;
    front = current_front + 1;
    return queue[current_front];
}
int main() {
    pair_t current_pos;
    pair_t neighbor_pos;
    pair_t temp_pair;
    char cell_char;
    long long combined_offset;
    int direction_index;
    int found_cycle;
    int col_index;
    int row_index;
    pair_t start_pos;
    int pp, qq;

    while (scanf("%d %d", &a, &b) == 2) {
        memset(vis, 0, sizeof(vis));
        memset(UpL, 0, sizeof(UpL));
        for (row_index = 0; row_index < a; ++row_index) {
            for (col_index = 0; col_index < b; ++col_index) {
                scanf(" %c", &cell_char);
                if (cell_char == '#') {
                    vis[row_index][col_index] = 1;
                    UpL[row_index][col_index][0] = 0x7FFF;
                } else if (cell_char == 'S') {
                    pp = row_index;
                    qq = col_index;
                }
            }
        }
        found_cycle = 0;
        front = rear = 0;
        vis[pp][qq] = 1;
        start_pos.x = pp;
        start_pos.y = qq;
        push(start_pos);
        while (!empty() && !found_cycle) {
            current_pos = pop();
            for (direction_index = 0; direction_index <= 3 && !found_cycle; ++direction_index) {
                neighbor_pos.x = current_pos.x + dir[direction_index][0];
                neighbor_pos.y = current_pos.y + dir[direction_index][1];
                combined_offset = ((long long)UpL[current_pos.x][current_pos.y][0] << 32) | (unsigned int)UpL[current_pos.x][current_pos.y][1];
                if (neighbor_pos.x >= 0) {
                    if (neighbor_pos.x >= a) {
                        neighbor_pos.x -= a;
                        combined_offset -= 1;
                    }
                } else {
                    neighbor_pos.x += a;
                    combined_offset += 1;
                }
                if (neighbor_pos.y >= 0) {
                    if (neighbor_pos.y >= b) {
                        neighbor_pos.y -= b;
                        combined_offset -= (1LL << 32);
                    }
                } else {
                    neighbor_pos.y += b;
                    combined_offset += (1LL << 32);
                }
                if (vis[neighbor_pos.x][neighbor_pos.y]) {
                    long long stored_offset = ((long long)UpL[neighbor_pos.x][neighbor_pos.y][0] << 32) | (unsigned int)UpL[neighbor_pos.x][neighbor_pos.y][1];
                    if (UpL[neighbor_pos.x][neighbor_pos.y][0] != 0x7FFF && combined_offset != stored_offset)
                        found_cycle = 1;
                } else {
                    vis[neighbor_pos.x][neighbor_pos.y] = 1;
                    UpL[neighbor_pos.x][neighbor_pos.y][0] = (short)(combined_offset >> 32);
                    UpL[neighbor_pos.x][neighbor_pos.y][1] = (short)combined_offset;
                    temp_pair = neighbor_pos;
                    push(temp_pair);
                }
            }
        }
        if (found_cycle)
            puts("Yes");
        else
            puts("No");
    }
    return 0;
}