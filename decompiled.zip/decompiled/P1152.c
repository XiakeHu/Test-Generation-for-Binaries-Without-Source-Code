#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h> // 添加了这个头文件以使用 isdigit() 函数
#include <stdbool.h>

typedef struct {
    int first;
    int second;
} Pair;

int read() {
    int t = 0, flag = 1;
    char a = getchar();
    while (!isdigit(a)) { // 使用 isdigit() 函数来检查字符是否为数字
        if (a == '-') {
            flag = -1;
        }
        a = getchar();
    }
    while (isdigit(a)) {
        t = t * 10 + a - '0';
        a = getchar();
    }
    return t * flag;
}

void put(int x) {
    if (x < 0) {
        putchar('-');
        x = -x;
    }
    if (x < 10) {
        putchar(x + '0');
    } else {
        put(x / 10);
        putchar(x % 10 + '0');
    }
}

int n;
int a[1005];
Pair b[1005]; // 将 Pair 结构体的定义移到了文件头部

// 比较函数需要是 const void*，并且在函数内部强制转换为具体类型指针
int compare(const void *a, const void *b) {
    Pair *p1 = (Pair *)a;
    Pair *p2 = (Pair *)b;
    return p1->second - p2->second;
}

int main() {
    n = read();
    for (int i = 0; i < n; i++) {
        a[i] = read();
    }
    // 将变量定义移到了循环外部，以符合 C99 标准
    int i;
    for (i = 0; i < n - 1; i++) {
        b[i].first = i;
        b[i].second = abs(a[i] - a[i + 1]);
    }
    qsort(b, n - 1, sizeof(Pair), compare); // 使用了 C99 的变长数组
    for (i = 0; i < n - 1; i++) {
        if (b[i].second != i + 1) {
            printf("Not jolly");
            return 0;
        }
    }
    printf("Jolly");
    return 0;
}