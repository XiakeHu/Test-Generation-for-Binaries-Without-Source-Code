#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>
#define MAX_N 10008
#define MAX_M 20008
typedef struct {
    int to;
    int next;
    int w;
}Edge;

int tot;
Edge edge[MAX_M];
int head[MAX_N];
int dis[MAX_N];
bool vis[MAX_N];

void addedge(int from, int to, int w) ;
void spfa() ;
int main() ;
void addedge(int from, int to, int w)
{
    tot++;
    edge[tot].to = to;
    edge[tot].w = w;
    edge[tot].next = head[from];
    head[from] = tot;
}
void spfa()
{
    int queue[10008];
    int front = 0;
    int rear = 0;
    int current_node;
    int edge_index;

    memset(dis, 0x7F, sizeof(dis));
    dis[1] = 0;
    queue[rear++] = 1;

    while (front != rear)
    {
        current_node = queue[front++];
        vis[current_node] = 0;

        for (edge_index = head[current_node]; edge_index != 0; edge_index = edge[edge_index].next)
        {
            int neighbor = edge[edge_index].to;
            int new_distance = dis[current_node] + edge[edge_index].w;

            if (dis[neighbor] > new_distance)
            {
                dis[neighbor] = new_distance;

                if (!vis[neighbor])
                {
                    queue[rear++] = neighbor;
                    vis[neighbor] = 1;
                }
            }
        }
    }
}
int main()
{
    int test_cases;
    int start_node;
    int edge_count;
    int node_count;
    int i;

    scanf("%d%d", &node_count, &edge_count);
    while (edge_count--)
    {
        scanf("%d%d", &start_node, &test_cases);
        addedge(start_node, test_cases + start_node, test_cases);
    }
    for (i = 1; i <= node_count; ++i)
    {
        if (!head[i])
            addedge(i, i + 1, 0);
    }
    spfa();
    printf("%d", node_count - dis[node_count + 1]);
    return 0;
}