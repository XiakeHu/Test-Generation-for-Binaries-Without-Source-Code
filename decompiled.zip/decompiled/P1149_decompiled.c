#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int mu[10];
int cnt;

int check(int x) ;
int read() ;
void write(int x) ;
int main() ;
int check(int x)
{
    int current_value = x;
    int result = 0;

    if (current_value == 0) {
        return mu[0];
    }

    while (current_value != 0) {
        int digit = current_value % 10;
        result += mu[digit];
        current_value /= 10;
    }

    return result;
}
int read()
{
    char current_char;
    int sign;
    int value;

    value = 0;
    sign = 1;
    for ( current_char = getchar(); current_char <= 47 || current_char > 57; current_char = getchar() )
    {
        if ( current_char == 45 )
            sign = -1;
    }
    while ( current_char > 47 && current_char <= 57 )
    {
        value = 10 * value + (current_char ^ 0x30);
        current_char = getchar();
    }
    return sign * value;
}
void write(int x)
{
    int abs_value = x;
    
    if (x < 0)
    {
        putchar('-');
        abs_value = -x;
    }
    
    if (abs_value > 9)
    {
        write(abs_value / 10);
    }
    
    putchar(abs_value % 10 + '0');
}
int main()
{
    int n_value;
    int outer_counter;
    int inner_counter;
    int check_sum_outer;
    int check_sum_inner;
    int check_sum_total;

    for (int i = 0; i < 10; ++i) {
        mu[i] = read();
    }
    n_value = read();
    cnt = 0;

    for (outer_counter = 0; outer_counter <= 1000; ++outer_counter)
    {
        for (inner_counter = 0; inner_counter <= 1000; ++inner_counter)
        {
            check_sum_outer = check(outer_counter);
            check_sum_inner = check(inner_counter);
            check_sum_total = check_sum_outer + check_sum_inner;
            if (check_sum_total + check(outer_counter + inner_counter) + 4 == n_value)
            {
                ++cnt;
            }
        }
    }
    write(cnt);
    return 0;
}