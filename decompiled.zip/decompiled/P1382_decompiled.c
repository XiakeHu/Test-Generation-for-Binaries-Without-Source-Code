#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>
#define MAXN 200005
typedef struct {
    int val;
    int cnt;
    int size;
    int fa;
    int son[2];
} Node;
typedef struct {
    int x;
    int y;
    int h;
} House;
typedef struct {
    int y;
    int h;
} Popout;
Node t[MAXN];
int root = 0;
int tot = 0;
int n;
House h[MAXN];
Popout p[MAXN];
int tims[MAXN * 2];
int cot = 0;
int tt;
int hst1 = -1000000001;
int hst2;
int u = 1;
int in = 0;
int v = 1;
int ans[MAXN * 2][2];
int cnt = 0;
void Connect(int p, int fa, int which);
int Relate(int p);
void Update(int p);
void Rotate(int p);
unsigned int Splay(unsigned int node, int target_parent);
void Find(int x);
void New(int x);
int GN(int x);
int GP(int x);
int compare_ints(const void *a, const void *b);
int comp(const void *a, const void *b);
int cmp(const void *a, const void *b);
void Insert(int x);
int GVBR(int rank);
void Delete(int x);
void Splay_0(int node, int target);
int main();
void Connect(int p, int fa, int which)
{
    t[p].fa = fa;
    if (fa != 0)
    {
        t[fa].son[which] = p;
    }
}
int Relate(int p)
{
    return p == t[t[p].fa].son[1];
}
void Update(int p)
{
    t[p].size = t[p].cnt + t[t[p].son[0]].size + t[t[p].son[1]].size;
}
void Rotate(int p)
{
    int parent;
    bool is_right_child;
    int grandparent_rel;

    parent = t[p].fa;
    is_right_child = Relate(p) != 0;
    grandparent_rel = Relate(parent);
    Connect(p, t[parent].fa, grandparent_rel);
    Connect(t[p].son[!is_right_child], parent, is_right_child);
    Connect(parent, p, !is_right_child);
    Update(parent);
    Update(p);
}
unsigned int Splay(unsigned int node, int target_parent)
{
    unsigned int parent;
    bool is_same_relation;
    unsigned int rotate_node;

    while (1)
    {
        parent = t[node].fa;
        if (parent == target_parent)
            break;
        if (target_parent != t[parent].fa)
        {
            is_same_relation = (Relate(node) == Relate(parent));
            rotate_node = is_same_relation ? parent : node;
            Rotate(rotate_node);
        }
        Rotate(node);
    }
    if (target_parent == 0)
    {
        root = node;
    }
    return node;
}
void Splay_0(int node, int target)
{
    Splay(node, target);
}
void Find(int x)
{
    int current_node;

    if (root)
    {
        current_node = root;
        while (t[current_node].son[x > t[current_node].val] && x != t[current_node].val)
        {
            current_node = t[current_node].son[x > t[current_node].val];
        }
        Splay_0(current_node, 0);
    }
}
void New(int x)
{
    t[++tot].val = x;
    t[tot].cnt = 1;
    t[tot].size = 1;
    t[tot].fa = 0;
    t[tot].son[0] = 0;
    t[tot].son[1] = 0;
}
int GN(int x)
{
    int current_node;

    Find(x);
    if (x < t[root].val)
        return root;

    current_node = t[root].son[1];
    while (t[current_node].son[0])
    {
        current_node = t[current_node].son[0];
    }
    return current_node;
}
int GP(int x)
{
    int current_node;

    Find(x);
    if (x > t[root].val)
        return root;

    current_node = t[root].son[0];
    while (t[current_node].son[1])
        current_node = t[current_node].son[1];

    return current_node;
}
int compare_ints(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;

    if (value_a < value_b)
        return -1;
    else if (value_a > value_b)
        return 1;
    else
        return 0;
}
int comp(const void *a, const void *b)
{
    const int *pa = (const int *)a;
    const int *pb = (const int *)b;
    return *pa - *pb;
}
int cmp(const void *a, const void *b)
{
    const House *house_a = (const House *)a;
    const House *house_b = (const House *)b;

    if (house_a->x == house_b->x)
    {
        return house_b->h - house_a->h;
    }
    else
    {
        return house_a->x - house_b->x;
    }
}
void Insert(int x)
{
    bool is_right_child;
    int parent;
    int current_node;

    if (root)
    {
        current_node = root;
        do
        {
            if (x == t[current_node].val)
            {
                ++t[current_node].cnt;
                Update(current_node);
                Update(t[current_node].fa);
                Splay_0(current_node, 0);
                return;
            }
            parent = current_node;
            is_right_child = x > t[current_node].val;
            current_node = t[current_node].son[is_right_child];
        }
        while (current_node);
        New(x);
        Connect(tot, parent, is_right_child);
        Update(parent);
        Splay_0(tot, 0);
    }
    else
    {
        New(x);
        root = tot;
    }
}
int GVBR(int rank)
{
    int current_node = root;
    
    while (current_node != 0)
    {
        int left_child = t[current_node].son[0];
        
        if (left_child != 0 && rank <= t[left_child].size)
        {
            current_node = left_child;
        }
        else
        {
            int left_size = (left_child != 0) ? t[left_child].size : 0;
            rank -= left_size + t[current_node].cnt;
            
            if (rank <= 0)
            {
                return t[current_node].val;
            }
            
            current_node = t[current_node].son[1];
        }
    }
    
    return 0;
}
void Delete(int x)
{
    int predecessor;
    int successor;
    int node_to_delete;

    predecessor = GP(x);
    successor = GN(x);
    Splay_0(predecessor, 0);
    Splay_0(successor, predecessor);
    node_to_delete = t[successor].son[0];
    if (t[node_to_delete].cnt <= 1)
    {
        t[successor].son[0] = 0;
    }
    else
    {
        --t[node_to_delete].cnt;
        Splay_0(node_to_delete, 0);
    }
}
int main()
{
    int i, j, k;
    int current_height;
    int previous_height_value;
    int new_height_value;

    Insert(-1000000001);
    Insert(1000000001);
    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
    {
        scanf("%d%d%d", &h[i].x, &h[i].y, &h[i].h);
        p[i].y = h[i].y;
        p[i].h = h[i].h;
        tims[++cot] = h[i].x;
        tims[++cot] = h[i].y;
    }
    qsort(&h[1], n, sizeof(House), cmp);
    qsort(&p[1], n, sizeof(Popout), comp);
    qsort(&tims[1], cot, sizeof(int), compare_ints);
    for (j = 1; j <= cot; ++j)
    {
        tt = tims[j];
        hst2 = 0;
        while (h[u].x == tt)
        {
            Insert(h[u].h);
            ++u;
            ++in;
        }
        while (p[v].y == tt)
        {
            Delete(p[v].h);
            ++v;
            --in;
        }
        current_height = GVBR(in + 1);
        hst2 = (int)fmax((double)hst2, (double)current_height);
        if (hst1 != hst2)
        {
            ans[++cnt][0] = tt;
            previous_height_value = (hst1 == -1000000001) ? 0 : hst1;
            ans[cnt][1] = previous_height_value;
            ans[++cnt][0] = tt;
            new_height_value = (hst2 == -1000000001) ? 0 : hst2;
            ans[cnt][1] = new_height_value;
        }
        hst1 = hst2;
    }
    printf("%d", cnt);
    for (k = 1; k <= cnt; ++k)
        printf("%d %d\n", ans[k][0], ans[k][1]);
    return 0;
}