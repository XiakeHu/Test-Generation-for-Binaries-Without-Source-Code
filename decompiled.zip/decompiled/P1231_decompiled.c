#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#define MAXN 10010
#define MAXM 100010

struct Edge {
    int to;
    int val;
    struct Edge *nxt;
    struct Edge *ops;
};

struct Edge e[MAXM * 2];
struct Edge *head[MAXN];
int dep[MAXN];
int gap[MAXN];
struct Edge *cur[MAXN];
int s, t;
int n1, n2, n3;
int res;
int cnt = 1;

int Dfs(int u, int flow) ;
void Bfs() ;
void Isap() ;
void AddEdge(int u, int v, int w) ;
int main() ;
int Dfs(int u, int flow) {
    int min_flow;
    int v;
    int used;

    if (u == t) {
        res += flow;
        return flow;
    } else {
        used = 0;
        while (cur[u] != NULL) {
            v = cur[u]->to;
            if (cur[u]->val && dep[v] == dep[u] - 1) {
                double temp = (double)cur[u]->val < (double)(flow - used) ? (double)cur[u]->val : (double)(flow - used);
                min_flow = Dfs(v, (int)temp);
                if (min_flow) {
                    used += min_flow;
                    cur[u]->val -= min_flow;
                    cur[u]->ops->val += min_flow;
                }
                if (used == flow) {
                    return used;
                }
            }
            cur[u] = cur[u]->nxt;
        }
        cur[u] = head[u];
        if (!--gap[dep[u]]) {
            dep[s] = n3 + n2 + 2 * n1 + 3;
        }
        ++gap[++dep[u]];
        return used;
    }
}
void Bfs()
{
    int queue[10010];
    int v;
    int u;
    struct Edge* e;
    int front = 0;
    int rear = 1;

    memset(gap, 0, sizeof(gap));
    memset(dep, -1, sizeof(dep));
    dep[t] = 0;
    ++gap[dep[t]];
    queue[0] = t;

    while (front < rear)
    {
        u = queue[front];
        ++front;

        for (e = head[u]; e != NULL; e = e->nxt)
        {
            v = e->to;
            if (dep[v] == -1)
            {
                dep[v] = dep[u] + 1;
                ++gap[dep[v]];
                queue[rear] = v;
                ++rear;
            }
        }
    }
}
void Isap()
{
    res = 0;
    Bfs();
    memcpy(cur, head, sizeof(cur));
    while (dep[s] <= n2 + 2 * n1 + n3 + 2)
    {
        Dfs(s, 0x3F3F3F3F);
    }
}
void AddEdge(int u, int v, int w)
{
    struct Edge *forward_edge;
    struct Edge *reverse_edge;

    forward_edge = &e[cnt++];
    forward_edge->to = v;
    forward_edge->val = w;
    forward_edge->nxt = head[u];
    head[u] = forward_edge;

    reverse_edge = &e[cnt++];
    reverse_edge->to = u;
    reverse_edge->val = 0;
    reverse_edge->nxt = head[v];
    head[v] = reverse_edge;

    forward_edge->ops = reverse_edge;
    reverse_edge->ops = forward_edge;
}
int main()
{
    int y_0;
    int x_0;
    int y;
    int x;
    int m;
    int i_3;
    int i_2;
    int i_1;
    int i_0;
    int i;

    scanf("%d%d%d", &n1, &n2, &n3);
    s = 0;
    t = n2 + 2 * n1 + n3 + 1;
    scanf("%d", &m);
    for (i = 1; i <= n2; ++i)
        AddEdge(0, 2 * n1 + i, 1);
    for (i_0 = 1; i_0 <= n3; ++i_0)
        AddEdge(i_0 + n2 + 2 * n1, t, 1);
    for (i_1 = 1; i_1 <= n1; ++i_1)
        AddEdge(i_1, n1 + i_1, 1);
    for (i_2 = 1; i_2 <= m; ++i_2)
    {
        scanf("%d%d", &x, &y);
        AddEdge(y + 2 * n1, x, 1);
    }
    scanf("%d", &m);
    for (i_3 = 1; i_3 <= m; ++i_3)
    {
        scanf("%d%d", &x_0, &y_0);
        AddEdge(n1 + x_0, n2 + 2 * n1 + y_0, 1);
    }
    Isap();
    printf("%d\n", res);
    return 0;
}