#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct { int t; int w; } task;
task a[100005];
int vis[100005];
int m, n;

int cmp(const void *a, const void *b);
int main();

int cmp(const void *a, const void *b)
{
    const task *task_a = (const task *)a;
    const task *task_b = (const task *)b;
    return task_b->w - task_a->w;
}
int main()
{
    int j;
    int inner_loop_index;
    int second_input_loop_index;
    int first_input_loop_index;

    scanf("%d%d", &m, &n);
    for (first_input_loop_index = 1; first_input_loop_index <= n; ++first_input_loop_index)
        scanf("%d", &a[first_input_loop_index].t);
    for (second_input_loop_index = 1; second_input_loop_index <= n; ++second_input_loop_index)
        scanf("%d", &a[second_input_loop_index].w);
    qsort(&a[1], n, sizeof(task), cmp);
    for (inner_loop_index = 1; inner_loop_index <= n; ++inner_loop_index)
    {
        for (j = a[inner_loop_index].t; j > 0; --j)
        {
            if (!vis[j])
            {
                vis[j] = 1;
                break;
            }
            if (j == 1 && vis[1])
            {
                m -= a[inner_loop_index].w;
                break;
            }
        }
    }
    printf("%d", m);
    return 0;
}