#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int to;
    int w;
} Edge;

Edge nbr[105][105];
int nbr_size[105];
int cnt;
int val[105];
int leaf[105];
int dp[105][105];
int seconds;

int min(int a, int b);
void make_subtree(int cur);
int dfs(int u);
int main();

int min(int a, int b)
{
    int result = a;
    if (b <= a)
    {
        result = b;
    }
    return result;
}

void make_subtree(int cur)
{
    int pic;
    int w;
    int boot;
    int i;

    scanf("%d%d", &pic, &w);
    nbr[cur][nbr_size[cur]].to = ++cnt;
    nbr[cur][nbr_size[cur]].w = w;
    nbr_size[cur]++;

    if (pic != 0)
    {
        val[cnt] = pic;
        leaf[cnt] = 1;
        for (i = 1; i <= pic; ++i)
        {
            dp[cnt][i] = 5 * i;
        }
    }
    else
    {
        boot = cnt;
        make_subtree(cnt);
        make_subtree(boot);
    }
}

int dfs(int u)
{
    int child_value;
    int j;
    int i;
    int total_sum;

    if (leaf[u])
        return val[u];
    total_sum = 0;
    for (i = 0; i < nbr_size[u]; ++i)
    {
        child_value = dfs(nbr[u][i].to);
        total_sum += child_value;
        for (j = total_sum; j > 0; --j)
        {
            for (int k = 0; k <= child_value; ++k)
                dp[u][j] = min(dp[u][j], dp[u][j - k] + dp[nbr[u][i].to][k] + 2 * nbr[u][i].w);
        }
    }
    return total_sum;
}

int main()
{
    int max_pictures;
    int i;
    int j;

    memset(dp, 0x3F, sizeof(dp));
    scanf("%d", &seconds);
    cnt = 0;
    make_subtree(1);

    for (i = 1; i <= cnt; ++i)
    {
        dp[i][0] = 0;
    }

    max_pictures = dfs(1);
    for (j = max_pictures; j >= 0; --j)
    {
        if (dp[1][j] < seconds)
        {
            printf("%d", j);
            return 0;
        }
    }
    return 0;
}