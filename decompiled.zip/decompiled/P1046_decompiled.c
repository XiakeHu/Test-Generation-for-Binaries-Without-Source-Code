#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define MAX_SIZE 1000

int MAXN;
int n;
int d = 0;
int a[MAX_SIZE];

int compare(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;
    return value_b - value_a;
}

int main(int argc, const char **argv, const char **envp)
{
    int i;
    int j;

    scanf("%d", &MAXN);
    for (i = 0; i < MAXN; ++i)
        scanf("%d", &a[i]);
    scanf("%d", &n);
    qsort(a, MAXN, sizeof(int), compare);
    for (j = 0; j < MAXN; ++j)
    {
        if (n + 30 >= a[j])
            ++d;
    }
    printf("%d\n", d);
    return 0;
}