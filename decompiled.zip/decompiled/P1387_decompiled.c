#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n, m;
int dp[100][100];
int maxx = 0;

int main()
{
    int i, j, i_0, j_0, k, ii, jj;
    int temp_min;
    int ok;

    scanf("%d%d", &n, &m);
    for (i = 1; i <= n; ++i)
    {
        for (j = 1; j <= m; ++j)
        {
            scanf("%d", &dp[i][j]);
        }
    }

    for (i_0 = 1; i_0 <= n; ++i_0)
    {
        for (j_0 = 1; j_0 <= m; ++j_0)
        {
            temp_min = (i_0 < j_0) ? i_0 : j_0;
            for (k = 1; k <= temp_min; ++k)
            {
                ok = 0;
                for (ii = i_0 - k; ii <= i_0; ++ii)
                {
                    for (jj = j_0 - k; jj <= j_0; ++jj)
                    {
                        if (dp[ii][jj] == 0)
                        {
                            ok = 1;
                        }
                    }
                }
                if (ok == 0)
                {
                    if (k + 1 > maxx)
                    {
                        maxx = k + 1;
                    }
                }
            }
        }
    }

    printf("%d", maxx);
    return 0;
}