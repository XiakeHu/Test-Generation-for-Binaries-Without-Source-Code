#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

typedef struct {
    int x;
    int y;
} node;

typedef struct {
    int xmax;
    int xmin;
    int ymax;
    int ymin;
    bool em;
} dat;

int n, k, ans;
node a[15];
dat c[15];

void add(int x, int y, int k);
bool check(int step);
int pd();
void dfs(int step);

void add(int x, int y, int k)
{
    c[k].xmax = (int)fmax((double)c[k].xmax, (double)x);
    c[k].xmin = (int)fmin((double)c[k].xmin, (double)x);
    c[k].ymax = (int)fmax((double)c[k].ymax, (double)y);
    c[k].ymin = (int)fmin((double)c[k].ymin, (double)y);
    c[k].em = false;
}

bool check(int step)
{
    for (int i = 1; i <= k; ++i)
    {
        for (int j = i + 1; j <= k; ++j)
        {
            if (!c[i].em && !c[j].em)
            {
                bool overlap = false;
                if (c[i].xmin <= c[j].xmin && c[j].xmin <= c[i].xmax && c[i].ymin <= c[j].ymin && c[j].ymin <= c[i].ymax)
                    overlap = true;
                else if (c[i].xmin <= c[j].xmax && c[j].xmax <= c[i].xmax && c[i].ymin <= c[j].ymin && c[j].ymin <= c[i].ymax)
                    overlap = true;
                else if (c[i].xmin <= c[j].xmin && c[j].xmin <= c[i].xmax && c[i].ymin <= c[j].ymax && c[j].ymax <= c[i].ymax)
                    overlap = true;
                else if (c[i].xmin <= c[j].xmax && c[j].xmax <= c[i].xmax && c[i].ymin <= c[j].ymax && c[j].ymax <= c[i].ymax)
                    overlap = true;
                else if (c[j].xmin <= c[i].xmin && c[i].xmin <= c[j].xmax && c[j].ymin <= c[i].ymin && c[i].ymin <= c[j].ymax)
                    overlap = true;
                else if (c[j].xmin <= c[i].xmax && c[i].xmax <= c[j].xmax && c[j].ymin <= c[i].ymin && c[i].ymin <= c[j].ymax)
                    overlap = true;
                else if (c[j].xmin <= c[i].xmin && c[i].xmin <= c[j].xmax && c[j].ymin <= c[i].ymax && c[i].ymax <= c[j].ymax)
                    overlap = true;
                else if (c[j].xmin <= c[i].xmax && c[i].xmax <= c[j].xmax && c[j].ymin <= c[i].ymax && c[i].ymax <= c[j].ymax)
                    overlap = true;

                if (overlap)
                {
                    return false;
                }
            }
        }
    }
    return true;
}

int pd()
{
    int i;
    int total_area = 0;

    total_area = 0;
    for ( i = 1; i <= k; ++i )
    {
        if ( !c[i].em )
            total_area += (c[i].xmax - c[i].xmin) * (c[i].ymax - c[i].ymin);
    }
    return total_area;
}

void dfs(int step)
{
    if (step > n)
    {
        int current_area = pd();
        if (current_area < ans)
        {
            ans = current_area;
        }
        return;
    }

    if (pd() > ans)
    {
        return;
    }

    for (int cluster_index = 1; cluster_index <= k; ++cluster_index)
    {
        dat cluster_backup = c[cluster_index];

        add(a[step].x, a[step].y, cluster_index);

        if (check(step))
        {
            dfs(step + 1);
        }

        c[cluster_index] = cluster_backup;
    }
}

int main()
{
    int i;
    ans = 0x7fffffff;
    for (i = 0; i < 15; ++i) {
        c[i].xmax = -1000;
        c[i].xmin = 1000;
        c[i].ymax = -1000;
        c[i].ymin = 1000;
        c[i].em = true;
    }
    scanf("%d%d", &n, &k);
    for (i = 1; i <= n; ++i)
        scanf("%d%d", &a[i].x, &a[i].y);
    dfs(1);
    printf("%d\n", ans);
    return 0;
}