#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int p;
    int r;
    int c;
    int ake;
} ac;

int n, m;
int ta, tb, tc, td, a, h, e;
int R;
long long ans1, ans2;
int sc[1005][1005];
int cnt[1005][1005];
ac cp[100005];

int compare(const void *a, const void *b);

int compare(const void *a, const void *b)
{
    const ac *ac_a = (const ac *)a;
    const ac *ac_b = (const ac *)b;

    if (ac_a->r != ac_b->r)
        return ac_a->r - ac_b->r;

    if (ac_a->p == ac_b->p)
        return ac_a->ake - ac_b->ake;

    return ac_a->p - ac_b->p;
}
int main()
{
    double temp_double;
    int j;
    int outer_loop_i;
    int inner_loop_i;
    int current_mle;
    int current_tle;
    int record_loop_i;
    int second_input_loop_i;
    int first_input_loop_i;

    scanf("%d %d", &n, &m);
    for (first_input_loop_i = 1; first_input_loop_i <= n; ++first_input_loop_i)
        scanf("%d", &sc[first_input_loop_i][0]);
    for (second_input_loop_i = 1; second_input_loop_i <= m; ++second_input_loop_i)
        scanf("%d", &cnt[second_input_loop_i][0]);
    scanf("%d %d %d %d %d %d %d", &ta, &tb, &tc, &td, &a, &h, &e);
    scanf("%d", &R);
    ans1 = n * ta;
    ans2 = n * ta;
    for (record_loop_i = 1; record_loop_i <= R; ++record_loop_i)
    {
        scanf("%d %d %d", &cp[record_loop_i].p, &cp[record_loop_i].r, &cp[record_loop_i].c);
        cp[record_loop_i].ake = record_loop_i;
        ans2 += tc;
    }
    qsort(&cp[1], R, sizeof(ac), compare);
    current_tle = 1;
    current_mle = 1;
    for (inner_loop_i = 1; inner_loop_i <= R; ++inner_loop_i)
    {
        if (sc[current_tle][current_mle] < cp[inner_loop_i].c)
        {
            sc[current_tle][current_mle] = cp[inner_loop_i].c;
            if (e)
                ans1 += td;
        }
        ++cnt[current_tle][current_mle];
        if (inner_loop_i < R && cp[inner_loop_i].p != cp[inner_loop_i + 1].p)
            ++current_mle;
        if (inner_loop_i < R && cp[inner_loop_i].r != cp[inner_loop_i + 1].r)
        {
            ++current_tle;
            current_mle = 1;
        }
    }
    for (outer_loop_i = 1; outer_loop_i <= current_tle; ++outer_loop_i)
    {
        for (j = 1; j <= 1001; ++j)
        {
            temp_double = (double)ans1;
            ans1 = (long long)(fmin((double)(cnt[outer_loop_i][j] * tb),
                                         (double)(tc * cnt[outer_loop_i][j] + ta)) +
                               temp_double);
        }
    }
    ans2 = (long long)((double)ans2 / ((double)a / 100.0)) + h;
    printf("%lld\n%lld\n", ans1, ans2);
    if (ans1 <= ans2)
        printf("Forget it...");
    else
        printf("Use Luogu!");
    return 0;
}