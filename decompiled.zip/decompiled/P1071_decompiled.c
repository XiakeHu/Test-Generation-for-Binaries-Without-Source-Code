#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

typedef struct {
    char key;
    bool visited;
} MapEntry;

MapEntry mp[26];
char a[100], b[100], c[100];

void set_entry(char a, char b);
bool is_visited(char ch_0);
bool is_mapped(char a, char b);
int main(int argc, const char **argv, const char **envp);

void set_entry(char a, char b)
{
    for (int i = 0; i <= 25; ++i)
    {
        if (!mp[i].key)
        {
            mp[i].key = a;
            mp[i].visited = true;
            return;
        }
    }
}

bool is_visited(char ch_0)
{
    for (int i = 0; i <= 25; ++i)
    {
        if (ch_0 == mp[i].key && mp[i].visited)
            return true;
    }
    return false;
}

bool is_mapped(char a, char b)
{
    int i;
    
    for (i = 0; i <= 25; ++i)
    {
        if (a == mp[i].key && mp[i].visited)
        {
            return b == mp[i].key;
        }
    }
    return false;
}

int main(int argc, const char **argv, const char **envp)
{
    int j;
    size_t i_1;
    int i_0;
    size_t i;

    scanf("%s %s %s", a, b, c);
    if (strlen(a) > 0x19)
    {
        for (i = 0; i < strlen(a); ++i)
        {
            if (mp[a[i] - 'A'].key)
            {
                if (!is_mapped(a[i], b[i]))
                    goto LABEL_12;
            }
            else
            {
                if (is_visited(b[i]))
                    goto LABEL_12;
                set_entry(a[i], b[i]);
            }
        }
        for (i_0 = 0; i_0 <= 25; ++i_0)
        {
            if (!mp[i_0].visited)
                goto LABEL_12;
        }
        for (i_1 = 0; i_1 < strlen(c); ++i_1)
        {
            for (j = 0; j <= 25; ++j)
            {
                if (mp[j].key == c[i_1])
                {
                    putchar(j + 'A');
                    break;
                }
            }
        }
        return 0;
    }
    else
    {
    LABEL_12:
        printf("Failed");
        return 0;
    }
}