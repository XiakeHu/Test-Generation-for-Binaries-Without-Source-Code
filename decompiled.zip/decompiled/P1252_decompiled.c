#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

long long ans = -1;
int k = 0;
int b[6] = {0};
int a[6][11] = {{0}};

int pd(void);
void dfs(long long s, int x, int l, int o);

int pd()
{
    int index;
    
    for (index = 1; index <= 5; ++index)
    {
        if (!b[index])
            return 0;
    }
    return 1;
}
void dfs(long long s, int x, int l, int o)
{
    int i;

    if (x == 5)
    {
        if (l == 25 && pd())
        {
            if (ans == -1)
            {
                ans = s;
                k = o;
            }
            else if (s <= ans)
            {
                if (s == ans)
                {
                    k = (int)fmax((double)o, (double)k);
                }
                ans = s;
                k = o;
            }
        }
    }
    else if (l <= 24 || x > 5)
    {
        for (i = 1; i <= 10; ++i)
        {
            b[x + 1] = i;
            dfs(a[x + 1][i] + s, x + 1, l + i, 100 * o + i);
        }
    }
}
int main()
{
    int i, j;

    for (i = 1; i <= 5; ++i)
    {
        for (j = 1; j <= 10; ++j)
        {
            scanf("%d", &a[i][j]);
        }
    }

    dfs(0LL, 0, 0, 0);

    if (k + 999999999 <= 1999999998)
    {
        printf("%d ", k / 100000000);
    }
    else
    {
        printf("10 ");
    }
    k %= 100000000;

    if (k + 9999999 <= 19999998)
    {
        printf("%d ", k / 1000000);
    }
    else
    {
        printf("10 ");
    }
    k %= 1000000;

    if (k + 99999 <= 199998)
    {
        printf("%d ", k / 10000);
    }
    else
    {
        printf("10 ");
    }
    k %= 10000;

    if (k + 999 <= 1998)
    {
        printf("%d ", k / 100);
    }
    else
    {
        printf("10\n");
    }
    k %= 100;

    if (k + 9 <= 18)
    {
        printf("%d\n", k % 10);
    }
    else
    {
        printf("10\n");
    }

    return 0;
}