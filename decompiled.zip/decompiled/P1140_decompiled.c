#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int main(int argc, const char **argv, const char **envp) ;
int main(int argc, const char **argv, const char **envp)
{
    int la, lb;
    char ch_a, ch_b;
    int i, j;
    int temp_val;
    int dp[102][102];
    int a[102];
    int b[102];
    int v[6][6];

    for (i = 1; i <= 101; ++i)
    {
        for (j = 1; j <= 101; ++j)
            dp[i][j] = -1000000;
    }

    scanf("%d", &la);
    getchar();
    for (i = 1; i <= la; ++i)
    {
        ch_a = getchar();
        switch (ch_a)
        {
        case 'A':
            a[i] = 1;
            break;
        case 'C':
            a[i] = 2;
            break;
        case 'G':
            a[i] = 3;
            break;
        case 'T':
            a[i] = 4;
            break;
        }
    }

    scanf("%d", &lb);
    getchar();
    for (i = 1; i <= lb; ++i)
    {
        ch_b = getchar();
        switch (ch_b)
        {
        case 'A':
            b[i] = 1;
            break;
        case 'C':
            b[i] = 2;
            break;
        case 'G':
            b[i] = 3;
            break;
        case 'T':
            b[i] = 4;
            break;
        }
    }

    for (i = 1; i <= la; ++i)
        dp[i][0] = dp[i - 1][0] + v[a[i]][5];
    for (i = 1; i <= lb; ++i)
        dp[0][i] = v[5][b[i]] + dp[0][i - 1];

    for (i = 1; i <= la; ++i)
    {
        for (j = 1; j <= lb; ++j)
        {
            temp_val = dp[i][j];
            if (dp[i - 1][j] + v[a[i]][5] >= temp_val)
                temp_val = dp[i - 1][j] + v[a[i]][5];
            dp[i][j] = temp_val;

            temp_val = dp[i][j];
            if (v[5][b[j]] + dp[i - 1][j + 101] >= temp_val)
                temp_val = v[5][b[j]] + dp[i - 1][j + 101];
            dp[i][j] = temp_val;

            temp_val = dp[i][j];
            if (dp[i - 1][j - 1] + v[a[i]][b[j]] >= temp_val)
                temp_val = dp[i - 1][j - 1] + v[a[i]][b[j]];
            dp[i][j] = temp_val;
        }
    }

    printf("%d", dp[la][lb]);
    return 0;
}
