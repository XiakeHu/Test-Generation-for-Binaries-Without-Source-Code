#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int min(int x, int y) ;
int main(int argc, const char **argv, const char **envp) ;
int min(int x, int y)
{
    if (x >= y)
        return y;
    else
        return x;
}
int main(int argc, const char **argv, const char **envp)
{
    int diff;
    int temp_val;
    int edit_cost;
    int n2;
    int n1;
    int j_inner;
    int i_inner;
    int j;
    int i;
    int k;
    char a[100];
    char b[100];
    int f[101][101];

    scanf("%s", a);
    scanf("%s", b);
    scanf("%d", &k);
    n1 = strlen(a);
    n2 = strlen(b);
    f[0][0] = 0;
    for (i = 1; i <= n1; ++i)
        f[i][0] = i * k;
    for (j = 1; j <= n2; ++j)
        f[0][j] = j * k;
    for (i_inner = 1; i_inner <= n1; ++i_inner)
    {
        for (j_inner = 1; j_inner <= n2; ++j_inner)
        {
            diff = a[i_inner - 1] - b[j_inner - 1];
            if (b[j_inner - 1] - a[i_inner - 1] >= 0)
                diff = b[j_inner - 1] - a[i_inner - 1];
            edit_cost = f[i_inner - 1][j_inner - 1] + diff;
            temp_val = min(f[i_inner - 1][j_inner], f[i_inner][j_inner - 1]);
            f[i_inner][j_inner] = min(k + temp_val, edit_cost);
        }
    }
    printf("%d\n", f[n1][n2]);
    return 0;
}