#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

void check(int n, char *num) ;
int main() ;
void check(int n, char *num)
{
    int i;
    int last_sign;
    int current_number;
    int total_sum;

    total_sum = 0;
    current_number = 0;
    last_sign = 1;
    for (i = 0; i < 2 * n - 1; ++i)
    {
        if (num[i] <= 47 || num[i] > 57)
        {
            if (num[i] != 32)
            {
                total_sum += current_number * last_sign;
                current_number = 0;
                if (num[i] == 43)
                    last_sign = 1;
                if (num[i] == 45)
                    last_sign = -1;
            }
        }
        else
        {
            current_number = 10 * current_number + num[i] - 48;
        }
    }
    total_sum += current_number * last_sign;
    if (total_sum == 0)
        printf("%.*s\n", 2 * n - 1, num);
}
int main()
{
    int b;
    int a;
    int n;
    char num[100];
    char o[3] = {'+', '-', ' '};

    scanf("%d", &n);
    if ( n == 3 )
    {
        num[0] = '1';
        num[2] = '2';
        num[4] = '3';
        for ( a = 0; a <= 2; ++a )
        {
            num[1] = o[a];
            for ( b = 0; b <= 2; ++b )
            {
                num[3] = o[b];
                check(n, num);
            }
        }
    }
    return 0;
}