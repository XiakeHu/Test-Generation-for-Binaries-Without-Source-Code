#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int compare(const void *a, const void *b) ;
int main(int argc, const char **argv, const char **envp) ;
int compare(const void *a, const void *b)
{
    int first_value = *(const int *)a;
    int second_value = *(const int *)b;
    return first_value - second_value;
}
int main(int argc, const char **argv, const char **envp)
{
    int i;
    int a[5];

    for (i = 1; i <= 4; ++i)
        scanf("%d", &a[i]);
    qsort(&a[1], 4, sizeof(int), compare);
    return 0;
}