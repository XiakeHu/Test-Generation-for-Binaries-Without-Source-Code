#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int mp[3][3];
}Martrix;

Martrix* matrix_mul(Martrix* retstr, Martrix* rec_1, Martrix* rec_2) ;
long long gcd(long long x, long long y) ;
Martrix* matrix_power(Martrix* retstr, Martrix* rec, long long exp) ;
int main(int argc, const char **argv, const char **envp) ;

Martrix unit;
Martrix mul;
Martrix init;

Martrix* matrix_mul(Martrix* retstr, Martrix* rec_1, Martrix* rec_2)
{
    Martrix ans;
    int i, j, k;

    for (i = 0; i <= 2; ++i)
    {
        for (j = 0; j <= 2; ++j)
        {
            ans.mp[i][j] = 0;
            for (k = 0; k <= 2; ++k)
            {
                ans.mp[i][j] += rec_1->mp[i][k] * rec_2->mp[k][j];
                ans.mp[i][j] %= 100000000;
            }
        }
    }

    retstr->mp[0][0] = ans.mp[0][0];
    retstr->mp[0][1] = ans.mp[0][1];
    retstr->mp[0][2] = ans.mp[0][2];
    retstr->mp[1][0] = ans.mp[1][0];
    retstr->mp[1][1] = ans.mp[1][1];
    retstr->mp[1][2] = ans.mp[1][2];
    retstr->mp[2][0] = ans.mp[2][0];
    retstr->mp[2][1] = ans.mp[2][1];
    retstr->mp[2][2] = ans.mp[2][2];

    return retstr;
}
long long gcd(long long x, long long y)
{
    if (x % y != 0)
        return gcd(y, x % y);
    else
        return y;
}
Martrix* matrix_power(Martrix* retstr, Martrix* rec, long long exp)
{
    Martrix* result_ptr = retstr;
    Martrix* base_matrix = rec;
    long long exponent = exp;
    Martrix temp_result;
    Martrix current_result = unit;

    while (exponent)
    {
        if ((exponent & 1) != 0)
        {
            --exponent;
            matrix_mul(&temp_result, &current_result, base_matrix);
            current_result = temp_result;
        }
        exponent >>= 1;
        matrix_mul(&temp_result, base_matrix, base_matrix);
        *base_matrix = temp_result;
    }

    *result_ptr = current_result;
    return result_ptr;
}
int main(int argc, const char **argv, const char **envp)
{
    Martrix power_result;
    Martrix ans;
    long long gcd_result;
    int j;
    int i;
    long long n, m;

    scanf("%lld%lld", &n, &m);
    mul.mp[0][0] = 1;
    mul.mp[0][1] = 1;
    mul.mp[0][2] = 0;
    mul.mp[1][0] = 0;
    mul.mp[1][1] = 0;
    mul.mp[1][2] = 0;
    mul.mp[2][0] = 0;
    mul.mp[2][1] = 0;
    mul.mp[2][2] = 0;
    init.mp[0][0] = 0;
    init.mp[0][1] = 1;
    init.mp[0][2] = 0;
    init.mp[1][0] = 1;
    init.mp[1][1] = 1;
    init.mp[1][2] = 0;
    init.mp[2][0] = 0;
    init.mp[2][1] = 0;
    init.mp[2][2] = 0;
    for ( i = 0; i <= 2; ++i )
    {
        unit.mp[i][i] = 1;
        for ( j = i + 1; j <= 2; ++j )
        {
            unit.mp[i][j] = 0;
            unit.mp[j][i] = 0;
        }
    }
    gcd_result = gcd(n, m);
    if ( gcd_result == 1 || gcd_result == 2 )
    {
        puts("1");
        return 0;
    }
    else
    {
        matrix_power(&power_result, &init, gcd_result - 2);
        matrix_mul(&ans, &mul, &power_result);
        printf("%d", ans.mp[0][1]);
        return 0;
    }
}