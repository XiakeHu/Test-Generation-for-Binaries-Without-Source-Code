#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int solve_int(int x) ;
 int ans[1000];  int solve_int(int x) ;
int solve_int(int x)
{
    int i;
    int tmp;

    if (x == 1)
        return 1;
    if (ans[x] != -1)
        return ans[x];
    tmp = 1;
    for (i = 1; i <= x / 2; ++i)
        tmp += solve_int(i);
    ans[x] = tmp;
    return ans[x];
}
int main()
{
    int input_number;
    int result;

    scanf("%d", &input_number);
    memset(ans, -1, sizeof(ans));
    result = solve_int(input_number);
    printf("%d", result);
    return 0;
}
