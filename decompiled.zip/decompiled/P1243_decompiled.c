#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n, k, cnt;
int ans[100];
int dp[100];
int tbl[100][100];
char s[2] = "";

int g(int lim, int cnt) ;
int f(int lim) ;
void dfs(int lim, int k) ;
int read() ;
int main() ;
int g(int lim, int cnt)
{
    long long result;
    int recursive_result;

    if (cnt > 0)
    {
        if (!tbl[lim][cnt])
        {
            recursive_result = g(lim, cnt - 1);
            tbl[lim][cnt] = recursive_result + f(lim + cnt);
        }
        return tbl[lim][cnt];
    }
    else
    {
        result = 0;
    }
    return result;
}
int f(int lim)
{
    long long result;

    if (lim == n)
    {
        result = 1;
    }
    else
    {
        if (!dp[lim])
        {
            int recursive_result = g(lim, n - lim);
            dp[lim] = recursive_result + 1;
        }
        result = dp[lim];
    }
    return result;
}
void dfs(int lim, int k)
{
    int ka;
    int i;
    int i_0;
    int g_result;
    int index;

    if (k == 1)
    {
        for (i = 0; i < n - lim; ++i)
        {
            printf("%d ", ans[i]);
        }
        puts(s);
    }
    else
    {
        ka = k - 1;
        for (i_0 = 0; i_0 < n - lim; ++i_0)
        {
            g_result = g(lim, i_0);
            if (ka > g_result)
            {
                g_result = g(lim, i_0 + 1);
                if (ka <= g_result)
                {
                    index = cnt++;
                    ans[index] = lim + i_0 + 1;
                    g_result = g(lim, i_0);
                    dfs(lim + i_0 + 1, ka - g_result);
                    return;
                }
            }
        }
        index = cnt++;
        ans[index] = n;
        dfs(n, 1);
    }
}
int read()
{
    char current_char;
    int sign;
    int value;

    value = 0;
    sign = 1;
    do
    {
        current_char = getchar();
        if ( current_char == 45 )
            sign = -1;
    }
    while ( current_char > 57 || current_char <= 47 );
    do
    {
        value = 10 * value + current_char - 48;
        current_char = getchar();
    }
    while ( current_char > 47 && current_char <= 57 );
    return sign * value;
}
int main()
{
    cnt = 0;
    n = read();
    k = read();
    f(0);
    dfs(0, k);
    return 0;
}