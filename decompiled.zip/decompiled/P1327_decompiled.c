#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int num;
    int id;
} point;

int f[100005];
int dword_465B20[100005];
point pt[100005];
int n;
int ans;

int Find(int x);
int compare(const void *a, const void *b);
void Union(int u, int c);
int main();

int Find(int x)
{
    if (x == f[x])
        return x;
    f[x] = Find(f[x]);
    return f[x];
}
int compare(const void *a, const void *b)
{
    const point *point_a = (const point *)a;
    const point *point_b = (const point *)b;
    return point_a->num - point_b->num;
}
void Union(int u, int c)
{
    int root_u;
    int root_c;
    int temp;

    root_u = Find(u);
    root_c = Find(c);
    if ( dword_465B20[root_u] < dword_465B20[root_c] )
    {
        temp = root_u;
        root_u = root_c;
        root_c = temp;
    }
    dword_465B20[root_u] += dword_465B20[root_c];
    f[root_c] = root_u;
}
int main()
{
    int current_element;
    int root_of_current;
    int *stack;
    int stack_top;
    int stack_top_temp;
    int popped_element;

    scanf("%d", &n);
    for (int i = 1; i <= n; ++i)
    {
        scanf("%d", &pt[i].num);
        pt[i].id = i;
        dword_465B20[i] = 1;
        f[i] = i;
    }
    qsort(&pt[1], n, sizeof(point), compare);
    for (int i = 1; i <= n; ++i)
    {
        if (i == f[i])
        {
            stack = (int *)malloc(sizeof(int));
            stack[0] = i;
            stack_top = 1;
            while (stack_top > 0)
            {
                stack_top_temp = stack_top - 1;
                popped_element = stack[stack_top_temp];
                root_of_current = Find(popped_element);
                if (root_of_current == Find(pt[popped_element].id))
                {
                    ans += dword_465B20[pt[popped_element].id] - 1;
                    break;
                }
                Union(popped_element, pt[popped_element].id);
                stack_top = stack_top_temp + 1;
                stack[stack_top_temp] = pt[popped_element].id;
            }
            free(stack);
        }
    }
    printf("%d", ans);
    return 0;
}