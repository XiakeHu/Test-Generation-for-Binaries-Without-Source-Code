#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int x;
    int dir;
} player;

int cmpfunc(const void *a, const void *b) ;
void q_in(int *e) ;
void q_out(int e) ;
int main() ;
int cmpfunc(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;
    return value_a - value_b;
}
void q_in(int *e)
{
    char c;

    while (1)
    {
        c = getchar();
        if (c > 47 && c <= 57)
            break;
        if (c == '-')
            *e = -*e;
    }

    *e = 0;
    while (c > 47 && c <= 57)
    {
        *e = 10 * *e + c - '0';
        c = getchar();
    }
}
void q_out(int e)
{
    if (e >= 0)
    {
        if (e > 9)
            q_out(e / 10);
        putchar(e % 10 + '0');
    }
    else
    {
        putchar('-');
        q_out(-e);
    }
}
int main()
{
    player rplayers[5000];
    player players[5000];
    int tmpx;
    int m;
    int n;
    int i;
    int j;
    int ans2;
    int ans1;
    int direction;

    ans1 = 0;
    ans2 = 0;
    q_in(&n);
    q_in(&m);
    for (i = 0; i < m; ++i)
    {
        q_in(&tmpx);
        if (n / 2 < tmpx)
            direction = 1;
        else
            direction = -1;
        rplayers[i].x = tmpx;
        rplayers[i].dir = direction;
        players[i].x = tmpx;
        players[i].dir = -direction;
    }
    do
    {
        ++ans1;
        for (j = 0; j < m; ++j)
            rplayers[j].x += rplayers[j].dir;
        qsort(rplayers, m, sizeof(player), cmpfunc);
    } while (rplayers[0].x && rplayers[0].x != n + 1);
    do
    {
        ++ans2;
        for (j = 0; j < m; ++j)
            players[j].x += players[j].dir;
        qsort(players, m, sizeof(player), cmpfunc);
    } while (players[0].x && players[0].x != n + 1);
    q_out(ans1);
    putchar(' ');
    q_out(ans2);
    putchar('\n');
    return 0;
}