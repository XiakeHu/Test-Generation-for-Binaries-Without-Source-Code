#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

#define MAX_V 25
#define MAX_G 15

int v, g;
short need[MAX_V + 1];
short food[MAX_G][MAX_V];
typedef struct {
    bool chos[20];
    short now[30];
    short sum;
    short cnt;
} node;
node ans;

void add(node *n, bool t, int k);
bool pd(node *n);
void scan();
void init(node *n);
void dfs(node *now, int k);
void print();
void Healthy_Holsteins();
int main();

void add(node *n, bool t, int k)
{
    short temp_sum;
    int i;

    n->cnt += t;
    temp_sum = 2 * n->sum;
    n->chos[k] = t;
    n->sum = n->chos[k] | temp_sum;

    if (t)
    {
        for (i = 0; i < v; ++i)
        {
            n->now[i] += food[k][i];
        }
    }
}
bool pd(node *n)
{
    int i;

    for (i = 0; i < v; ++i)
    {
        if (n->now[i] < need[i])
            return false;
    }
    return true;
}
void scan()
{
    int j;
    int i_0;
    int i;

    memset(need, 0, sizeof(need));
    memset(food, 0, sizeof(food));
    scanf("%d", &v);
    for (i = 0; i < v; ++i)
        scanf("%hd", &need[i]);
    scanf("%d", &g);
    for (i_0 = 0; i_0 < g; ++i_0)
    {
        for (j = 0; j < v; ++j)
            scanf("%hd", &food[i_0][j]);
    }
}
void init(node *n)
{
    memset(n->chos, 0, sizeof(n->chos));
    memset(n->now, 0, sizeof(n->now));
    n->cnt = 0;
    n->sum = n->cnt;
}
void dfs(node *now, int k)
{
    node next1;
    node next2;

    if (!pd(now))
    {
        goto LABEL_8;
    }

    if (now->cnt < ans.cnt)
    {
        memcpy(ans.chos, now->chos, sizeof(now->chos));
        memcpy(ans.now, now->now, sizeof(now->now));
        ans.sum = now->sum;
        ans.cnt = now->cnt;
    }

    if (k < g)
    {
        now->sum <<= (g - k);
    }

    if (now->cnt != ans.cnt || now->sum >= ans.sum)
    {
    LABEL_8:
        if (k != g)
        {
            memcpy(&next1, now, sizeof(node));
            memcpy(&next2, now, sizeof(node));

            add(&next1, 1, k);
            dfs(&next1, k + 1);

            add(&next2, 0, k);
            dfs(&next2, k + 1);
        }
    }
}
void print()
{
    int i;

    printf("%hd", ans.cnt);
    for (i = 0; i < g; ++i)
    {
        if (ans.chos[i])
            printf(" %d", i + 1);
    }
    putchar('\n');
}
void Healthy_Holsteins()
{
    node start;

    scan();
    init(&start);
    ans.cnt = g + 2;
    dfs(&start, 0);
    print();
}
int main()
{
    Healthy_Holsteins();
    return 0;
}