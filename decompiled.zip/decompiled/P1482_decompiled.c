#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int first;
    int last;
} fraction;

typedef fraction f;
typedef long long int64;

int64 gcd(int64 a, int64 b);
f reduce(f old);
f multiply(f a, f b);
f toFractionOf(char *in);

int64 gcd(int64 a, int64 b)
{
    if (b != 0)
    {
        return gcd(b, a % b);
    }
    else
    {
        return a;
    }
}
f reduce(f old)
{
    f result;
    int64 divisor;

    divisor = gcd(old.first, old.last);
    result.first = old.first / divisor;
    result.last = old.last / divisor;
    return result;
}
f multiply(f a, f b)
{
    f result;
    
    result.first = a.first * b.first;
    result.last = a.last * b.last;
    
    return reduce(result);
}
f toFractionOf(char *in)
{
    f result;
    size_t count = 0;
    long long numerator = 0;
    long long denominator = 0;

    while (in[count] != '/' && count < strlen(in))
    {
        numerator = numerator * 10 + (in[count] - '0');
        count++;
    }

    if (count == strlen(in))
    {
        result.first = numerator;
        result.last = 1;
        return result;
    }

    size_t denominator_start = count + 1;
    while (denominator_start < strlen(in))
    {
        denominator = denominator * 10 + (in[denominator_start] - '0');
        denominator_start++;
    }

    result.first = numerator;
    result.last = denominator;
    return result;
}
int main() {
    char input_a[1008];
    char input_b[1008];
    f fraction_a;
    f fraction_b;
    f result;

    scanf("%s%s", input_a, input_b);

    fraction_a = toFractionOf(input_a);
    fraction_b = toFractionOf(input_b);

    result = multiply(fraction_a, fraction_b);

    printf("%d %d\n", result.first, result.last);
    return 0;
}