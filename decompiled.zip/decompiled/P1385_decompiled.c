#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct Node {
    int id;
    int len;
    int sum;
    long long ans;
} Node;

int T;
char s[100005];
Node q[100005];
long long dp[2500005];
long long m;

int cmp2(const void *a, const void *b);
int cmp1(const void *a, const void *b);

int cmp2(const void *a, const void *b)
{
    const Node *node_a = (const Node *)a;
    const Node *node_b = (const Node *)b;
    return node_a->id - node_b->id;
}

int cmp1(const void *a, const void *b)
{
    const Node *node_a = (const Node *)a;
    const Node *node_b = (const Node *)b;
    return node_a->len - node_b->len;
}

int main() {
    scanf("%d", &T);
    for (int test_case = 1; test_case <= T; ++test_case) {
        scanf("%s", s);
        q[test_case].id = test_case;
        q[test_case].len = strlen(s);
        q[test_case].sum = 0;
        for (int i = 0; i < q[test_case].len; ++i) {
            q[test_case].sum += s[i] - 'a';
        }
        if (q[test_case].sum > m) {
            m = q[test_case].sum;
        }
    }

    qsort(&q[1], T, sizeof(Node), cmp1);

    int current_index = 1;
    for (int i = 0; i <= 25; ++i) {
        dp[i] = 1LL;
    }

    while (current_index <= T && q[current_index].len == 1) {
        q[current_index].ans = 1LL;
        ++current_index;
    }

    for (int length = 1; length < q[T].len; ++length) {
        for (int j = m; j >= 0; --j) {
            for (int k = 1; k <= 25 && j >= k; ++k) {
                dp[j] += dp[j - k];
            }
            dp[j] %= 1000000007LL;
        }
        while (current_index <= T && q[current_index].len == length + 1) {
            q[current_index].ans = dp[q[current_index].sum];
            ++current_index;
        }
    }

    qsort(&q[1], T, sizeof(Node), cmp2);

    for (int i = 1; i <= T; ++i) {
        printf("%lld\n", q[i].ans - 1);
    }

    return 0;
}