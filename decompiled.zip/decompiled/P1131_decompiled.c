#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int to;
    int next;
    int w;
} Edge;

#define MAXN 100005
#define MAXM 200005
#define INF 1000000000

Edge e[MAXM * 2];
int head[MAXN];
int sz;
int n, s;
int in[MAXN], out[MAXN], cnt;
int w[MAXN];
long long ans;
int Bit[MAXN];
int le[MAXN], c;
int Max;

int lowbit(int x);
int query(int i);
void add(int i, int v);
void dfs3(int u, int fa);
void add_edge(int u, int v, int w);
void dfs1(int u, int fa);
void dfs2(int u, int fa);
int main();

int lowbit(int x)
{
    return x & -x;
}

int query(int i)
{
    int sum = 0;
    while (i)
    {
        sum += Bit[i];
        i -= lowbit(i);
    }
    return sum;
}

void add(int i, int v)
{
    while (i <= n)
    {
        Bit[i] += v;
        i += lowbit(i);
    }
}

void dfs3(int u, int fa)
{
    int edge_weight;
    int neighbor_vertex;
    int edge_index;

    for (edge_index = head[u]; edge_index != -1; edge_index = e[edge_index].next)
    {
        neighbor_vertex = e[edge_index].to;
        edge_weight = query(in[neighbor_vertex]);
        if (neighbor_vertex != fa)
        {
            add(in[neighbor_vertex], -edge_weight);
            add(out[neighbor_vertex] + 1, edge_weight);
            ans += edge_weight;
            dfs3(neighbor_vertex, u);
        }
    }
    if (head[u] == -1)
    {
        ans += query(in[u]);
    }
}

void add_edge(int u, int v, int w)
{
    int edge_index = sz;
    e[edge_index].to = v;
    e[edge_index].w = w;
    e[edge_index].next = head[u];
    head[u] = edge_index;
    sz++;
}

void dfs1(int u, int fa)
{
    int v;
    int edge_index;

    in[u] = ++cnt;
    for (edge_index = head[u]; edge_index != -1; edge_index = e[edge_index].next)
    {
        v = e[edge_index].to;
        if (v != fa)
        {
            w[v] = e[edge_index].w + w[u];
            dfs1(v, u);
        }
    }
    out[u] = cnt;
}

void dfs2(int u, int fa)
{
    int v;
    int i;
    int min_val;

    min_val = INF;
    for (i = head[u]; i != -1; i = e[i].next)
    {
        v = e[i].to;
        if (v != fa)
        {
            dfs2(v, u);
            if (w[v] < min_val)
            {
                min_val = w[v];
            }
        }
    }
    if (head[u] == -1)
    {
        w[u] = min_val;
    }
}

int main()
{
    int edge_weight;
    int vertex_y;
    int vertex_x;
    int i;
    int leaf_index;
    int vertex_index;

    memset(head, -1, sizeof(head));
    scanf("%d%d", &n, &s);
    for (vertex_index = 1; vertex_index < n; ++vertex_index)
    {
        scanf("%d%d%d", &vertex_x, &vertex_y, &edge_weight);
        add_edge(vertex_x, vertex_y, edge_weight);
        add_edge(vertex_y, vertex_x, edge_weight);
    }
    dfs1(s, -1);
    Max = 0;
    for (i = 1; i <= n; i++) {
        if (head[i] == -1) {
            le[++c] = i;
            if (w[i] > Max) Max = w[i];
        }
    }
    for (leaf_index = 1; leaf_index <= c; ++leaf_index)
        w[le[leaf_index]] = Max - w[le[leaf_index]];
    dfs2(s, -1);
    for (i = 1; i <= n; ++i)
    {
        add(in[i], w[i]);
        add(in[i] + 1, -w[i]);
    }
    dfs3(s, -1);
    printf("%lld", ans);
    return 0;
}