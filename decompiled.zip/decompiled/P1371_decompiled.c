#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

 int main(int argc, const char **argv, const char **envp) ;
int main(int argc, const char **argv, const char **envp)
{
    char temp_buffer[100016];
    char input_string[100008];
    long long n;
    long long max_result;
    long long i_count;
    long long n_count;
    long long max_product;
    long long i;
    long long total_sum;

    total_sum = 0LL;
    max_product = 0LL;
    n_count = 0LL;
    i_count = 0LL;
    scanf("%lld", &n);
    scanf("%s", input_string);
    for (i = 0LL; i < n; ++i)
    {
        if (input_string[i] == 'I')
            ++i_count;
    }
    for (i = 0LL; i < n; ++i)
    {
        if (input_string[i] == 'N')
            ++n_count;
        if (input_string[i] == 'O')
            total_sum += i_count * n_count;
        if (input_string[i] == 'I')
            --i_count;
        max_product = (long long)fmax((double)max_product, (double)(i_count * n_count));
    }
    max_result = total_sum + max_product;
    ++n;
    strcpy(temp_buffer, input_string);
    input_string[0] = 'N';
    strcat(input_string, temp_buffer);
    total_sum = 0LL;
    n_count = 0LL;
    i_count = 0LL;
    for (i = 0LL; i < n; ++i)
    {
        if (input_string[i] == 'I')
            ++i_count;
    }
    for (i = 0LL; i < n; ++i)
    {
        if (input_string[i] == 'N')
            ++n_count;
        if (input_string[i] == 'O')
            total_sum += i_count * n_count;
        if (input_string[i] == 'I')
            --i_count;
    }
    max_result = (long long)fmax((double)max_result, (double)total_sum);
    strcpy(input_string, temp_buffer);
    input_string[n - 1] = 'I';
    total_sum = 0LL;
    n_count = 0LL;
    i_count = 0LL;
    for (i = 0LL; i < n; ++i)
    {
        if (input_string[i] == 'I')
            ++i_count;
    }
    for (i = 0LL; i < n; ++i)
    {
        if (input_string[i] == 'N')
            ++n_count;
        if (input_string[i] == 'O')
            total_sum += i_count * n_count;
        if (input_string[i] == 'I')
            --i_count;
    }
    max_result = (long long)fmax((double)max_result, (double)total_sum);
    printf("%lld", max_result);
    return 0;
}
