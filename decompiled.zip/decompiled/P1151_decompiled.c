#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int wan;
    int qian;
    int bai;
    int shi;
    int ge;
} Number;

int sub1(Number *n);
int sub2(Number *n);
int sub3(Number *n);

int sub1(Number *n)
{
    int result;

    if (n->wan != 0) {
        result = 100 * n->wan + 10 * n->qian;
    } else {
        result = 10 * n->qian;
    }

    result += n->bai;
    return result;
}
int sub2(Number *n)
{
    int result;

    if (n->qian != 0) {
        result = 100 * n->qian + 10 * n->bai;
    } else {
        result = 10 * n->bai;
    }

    result += n->shi;
    return result;
}
int sub3(Number *n)
{
    int result;

    if (n->bai != 0) {
        result = 100 * n->bai + 10 * n->shi;
    } else {
        result = 10 * n->shi;
    }

    result += n->ge;
    return result;
}
int main() {
    Number num;
    int divisor;
    int current_number;
    int found_count = 0;

    scanf("%d", &divisor);

    for (current_number = 10000; current_number <= 30000; ++current_number) {
        num.wan = current_number / 10000;
        num.qian = (current_number / 1000) % 10;
        num.bai = (current_number / 100) % 10;
        num.shi = (current_number / 10) % 10;
        num.ge = current_number % 10;

        if ((sub1(&num) % divisor == 0) &&
            (sub2(&num) % divisor == 0) &&
            (sub3(&num) % divisor == 0)) {
            printf("%d\n", current_number);
            ++found_count;
        }
    }

    if (found_count == 0) {
        printf("No");
    }

    return 0;
}