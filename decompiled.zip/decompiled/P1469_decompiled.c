#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int main(int argc, const char **argv, const char **envp) ;
int main(int argc, const char **argv, const char **envp)
{
    int n;
    int i;
    int ans;

    ans = 0;
    n = read(argc, argv, (size_t)envp);
    for (i = 1; i <= n; ++i)
        ans ^= read(argc, argv, (size_t)envp);
    printf("%d", ans);
    return 0;
}
