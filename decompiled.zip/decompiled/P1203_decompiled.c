#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

char x[1000];
char y[1000];
char s[1000];
int n;
int maxn;

void init(int l) ;
int dfs_back(int l) ;
int dfs_front(int l) ;
int main() ;

void init(int l)
{
    char temp_char;
    int i;
    int j;
    int k;

    memset(x, 0, sizeof(x));
    memset(y, 0, sizeof(y));

    for (i = l + 1; i < n; ++i)
        strncat(x, (const char *)(s + i), 1uLL);

    for (j = 0; j <= l; ++j)
        strncat(x, (const char *)(s + j), 1uLL);

    strcpy(y, x);

    for (k = 0; k < n / 2; ++k)
    {
        temp_char = y[k];
        y[k] = y[n - k - 1];
        y[n - k - 1] = temp_char;
    }
}
int dfs_back(int l)
{
    int i;
    int k;
    int ans;

    ans = 0;
    for (k = 0; y[k] == 'w'; ++k)
        ++ans;
    for (i = k; i < n && (y[k] == y[i] || y[i] == 'w'); ++i)
        ++ans;
    return ans;
}
int dfs_front(int l)
{
    int i;
    int k;
    int ans;

    ans = 0;
    for (k = 0; x[k] == 'w'; ++k)
        ++ans;
    for (i = k; i < n && (x[k] == x[i] || x[i] == 'w'); ++i)
        ++ans;
    return ans;
}
int main()
{
    int front_result;
    int back_result;
    int i;

    maxn = 0;
    scanf("%d", &n);
    scanf("%s", s);
    for (i = 0; i < n; ++i)
    {
        init(i);
        front_result = dfs_front(i);
        back_result = dfs_back(i);
        maxn = (int)fmax((double)maxn, (double)(front_result + back_result));
    }
    if(maxn > n) maxn = n;
    printf("%d", (unsigned int)maxn);
    return 0;
}