#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int x, y;
} node;

int n;
node a[1006];

int cmp(const void* a, const void* b) {
    node p = *(node*)a;
    node q = *(node*)b;
    if (p.y == q.y) return p.x - q.x;
    return p.y - q.y;
}

void init() {  
    int i, j;
    double tx, ty, px, py;
    if (scanf("%d", &n) != 1) return;
    for(i = 1; i <= n; i++)
        scanf("%d %d", &a[i].x, &a[i].y);
    qsort(a + 1, n, sizeof(node), cmp);
    tx = (a[1].x + a[n].x) / 2.0;
    ty = (a[1].y + a[n].y) / 2.0;  
    for(i = 1, j = n; i <= j; i++, j--) {  
        px = (a[i].x + a[j].x) / 2.0;
        py = (a[i].y + a[j].y) / 2.0;
        if(px != tx || py != ty) {
            printf("This is a dangerous situation!");  
            return;
         }
     }
    printf("V.I.P. should stay at (%.1f,%.1f).\n", tx, ty);
}

int main() {
    init();  
    return 0;
}