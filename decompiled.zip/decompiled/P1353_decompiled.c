#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int k[1005];
int f[1005][1005][2];

int read() ;
int main() ;
int read()
{
    char ch;
    int result = 0;
    
    ch = getchar();
    while (ch < '0' || ch > '9')
        ch = getchar();
    
    while (ch >= '0' && ch <= '9')
    {
        result = 10 * result + (ch - '0');
        ch = getchar();
    }
    
    return result;
}
int main()
{
    int n, m;
    int i, i_0, j;
    int limit_j;
    int temp_val;

    n = read();
    m = read();
    for (i = 1; i <= n; ++i)
        k[i] = read();

    for (i_0 = 1; i_0 <= n; ++i_0)
    {
        for (j = 0; ; ++j)
        {
            limit_j = i_0;
            if (m <= i_0)
                limit_j = m;
            if (j > limit_j)
                break;

            if (j)
            {
                temp_val = f[i_0][j][1];
                if (k[i_0] + f[i_0 - 1][j - 1][1] >= temp_val)
                    temp_val = k[i_0] + f[i_0 - 1][j - 1][1];
                f[i_0][j][1] = temp_val;
            }

            if (j == 1)
            {
                temp_val = f[i_0][1][1];
                if (k[i_0] + f[i_0 - 1][0][0] >= temp_val)
                    temp_val = k[i_0] + f[i_0 - 1][0][0];
                f[i_0][1][1] = temp_val;
            }

            temp_val = f[i_0 - 1][j + 1][0];
            if (f[i_0 - 1][j + 1][1] >= temp_val)
                temp_val = f[i_0 - 1][j + 1][1];
            f[i_0][j][0] = temp_val;

            if (!j)
                f[i_0][0][0] = f[i_0][0][0];
        }
    }

    printf("%d", f[n][0][0]);
    return 0;
}