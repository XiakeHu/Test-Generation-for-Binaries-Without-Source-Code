#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <limits.h>
#define MAX_N 1005
#define MAX_M 2005
typedef struct {
    int v;
    int nxt;
    int w;
} Edge;

Edge edge[MAX_M * 2];
int head[MAX_N];
int num;
int n, m;
int js[MAX_N];
int dist[MAX_N];
int vis[MAX_N];

int qread();
void ct(int u, int v, int w);
void dijkstra();
int main();
int compare(const void *a, const void *b);

int qread()
{
    int sign = 1;
    int number = 0;
    char ch = getchar();

    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            sign = -1;
        ch = getchar();
    }

    while (ch >= '0' && ch <= '9')
    {
        number = number * 10 + (ch - '0');
        ch = getchar();
    }

    return sign * number;
}
void ct(int u, int v, int w)
{
    edge[++num].v = v;
    edge[num].w = w;
    edge[num].nxt = head[u];
    head[u] = num;
}
void dijkstra()
{
    for (int i = 1; i <= n; ++i) {
        dist[i] = INT_MAX;
        vis[i] = 0;
        js[i] = 0;
    }
    dist[1] = 0;
    js[1] = 1;

    for (int i = 1; i <= n; ++i) {
        int u = -1, minDist = INT_MAX;
        for (int j = 1; j <= n; ++j) {
            if (!vis[j] && dist[j] < minDist) {
                minDist = dist[j];
                u = j;
            }
        }
        if (u == -1) break;
        vis[u] = 1;

        for (int e = head[u]; e; e = edge[e].nxt) {
            int v = edge[e].v;
            int w = edge[e].w;
            if (dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                js[v] = js[u];
            } else if (dist[u] + w == dist[v]) {
                js[v] += js[u];
            }
        }
    }
}
int main()
{
    int v;
    int u;
    int i_outer;
    int i_inner;

    n = qread();
    m = qread();
    for (i_inner = 1; i_inner <= m; ++i_inner)
    {
        u = qread();
        v = qread();
        ct(u, v, 1);
        ct(v, u, 1);
    }
    dijkstra();
    for (i_outer = 1; i_outer <= n; ++i_outer)
        printf("%d\n", js[i_outer]);
    return 0;
}
int compare(const void *a, const void *b)
{
    const int *ptr_a = (const int *)a;
    const int *ptr_b = (const int *)b;
    int value_b = ptr_b[1];
    int value_a = ptr_a[1];
    return value_b - value_a;
}