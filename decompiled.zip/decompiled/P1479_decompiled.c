#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

int f[10][10];
int v[20];
int n;
int ans;

void check();
void dfs(int start_index, int remaining_count);
void in(int *a1);
int yg();
int main(int argc, const char **argv, const char **envp);

void check()
{
    int count = 0;
    int i, j, k, m, n;

    for (i = 1; i <= 5 && f[0][7 * i]; ++i)
    {
        if (i == 5)
            ++count;
    }

    for (j = 1; j <= 5 && f[j][6 - j]; ++j)
    {
        if (j == 5)
            ++count;
    }

    for (k = 1; k <= 5; ++k)
    {
        for (m = 1; m <= 5 && f[k][m]; ++m)
        {
            if (m == 5)
                ++count;
        }

        for (n = 1; n <= 5 && f[n][k]; ++n)
        {
            if (n == 5)
                ++count;
        }
    }

    v[count] = 1;
}

void dfs(int start_index, int remaining_count)
{
    int current_index;
    int row;
    int col;

    if (remaining_count)
    {
        if (remaining_count <= 26 - start_index)
        {
            for (current_index = start_index; current_index <= 25; ++current_index)
            {
                row = (current_index - 1) / 5 + 1;
                col = (current_index - 1) % 5 + 1;
                f[row][col] = 1;
                dfs(current_index + 1, remaining_count - 1);
                f[row][col] = 0;
            }
        }
    }
    else
    {
        check();
    }
}

void in(int *a1)
{
    char ch;
    bool neg;

    do
    {
        ch = getchar();
    } while (ch != '-' && (ch <= '/' || ch > '9'));

    *a1 = 0;
    neg = 0;

    if (ch == '-')
    {
        neg = 1;
        ch = getchar();
    }

    while (ch > '/' && ch <= '9')
    {
        *a1 = 10 * *a1 + ch - '0';
        ch = getchar();
    }

    if (neg)
    {
        *a1 = -*a1;
    }
}

int yg()
{
    int i;
    ans = 0;
    memset(v, 0, sizeof(v));
    memset(f, 0, sizeof(f));

    in(&n);
    dfs(1, n);
    for (i = 1; i <= 12; ++i)
    {
        if (v[i])
            ans += i;
    }
    printf("%d", ans);
    return 0;
}

int main(int argc, const char **argv, const char **envp)
{
    yg();
    return 0;
}