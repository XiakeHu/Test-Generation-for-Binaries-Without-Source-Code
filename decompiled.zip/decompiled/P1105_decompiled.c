#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int height;
    int index;
    int left;
    int right;
} Platform;

int compare(const void *a, const void *b) ;
int compare(const void *a, const void *b)
{
    const Platform *platformA = (const Platform *)a;
    const Platform *platformB = (const Platform *)b;

    if (platformA->height < platformB->height)
        return -1;
    if (platformA->height > platformB->height)
        return 1;
    if (platformA->index > platformB->index)
        return -1;
    if (platformA->index < platformB->index)
        return 1;
    return 0;
}
int main() {
    int n;
    scanf("%d", &n);

    Platform *platforms = (Platform *)malloc(n * sizeof(Platform));
    int *a = (int *)malloc(n * sizeof(int));
    int *b = (int *)malloc(n * sizeof(int));

    for (int i = 0; i < n; ++i) {
        scanf("%d %d %d", &platforms[i].height, &platforms[i].left, &platforms[i].right);
        platforms[i].index = i + 1;
    }

    qsort(platforms, n, sizeof(Platform), compare);

    for (int i = 0; i < n; ++i) {
        int found = 0;
        for (int j = i - 1; j >= 0; --j) {
            if (platforms[j].left < platforms[i].left && platforms[j].right > platforms[i].left) {
                a[platforms[i].index - 1] = platforms[j].index;
                found = 1;
                break;
            }
        }
        if (!found) {
            a[platforms[i].index - 1] = 0;
        }

        found = 0;
        for (int j = i - 1; j >= 0; --j) {
            if (platforms[j].left < platforms[i].right && platforms[j].right > platforms[i].right) {
                b[platforms[i].index - 1] = platforms[j].index;
                found = 1;
                break;
            }
        }
        if (!found) {
            b[platforms[i].index - 1] = 0;
        }
    }

    for (int i = 0; i < n; ++i) {
        printf("%d %d\n", a[i], b[i]);
    }

    free(platforms);
    free(a);
    free(b);

    return 0;
}