#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int abs_val(int a) ;
int gcd(int a, int b) ;
 int gcd(int a, int b); int abs_val(int a);  int main() ;
int abs_val(int a)
{
    if (a >= 0)
        return a;
    else
        return -a;
}
int gcd(int a, int b)
{
    if (b != 0)
    {
        return gcd(b, a % b);
    }
    else
    {
        return a;
    }
}
int main()
{
    int test_cases;
    int i;
    int x1, y1, x2, y2;
    int delta_x, delta_y;

    scanf("%d", &test_cases);
    for (i = 0; i < test_cases; ++i)
    {
        scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
        delta_x = abs_val(x1 - x2);
        delta_y = abs_val(y1 - y2);
        if (gcd(delta_x, delta_y) == 1)
            puts("no");
        else
            puts("yes");
    }
    return 0;
}
