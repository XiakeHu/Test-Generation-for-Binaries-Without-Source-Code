#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

 void readInt(int *x) ;
void printInt(int x) ;
 int main() ;
void readInt(int *x) {
    int sign;
    char ch;
    int f;

    *x = 0;
    f = 1;
    ch = getchar();
    while ((((*__ctype_b_loc())[(unsigned char)ch] & 0x800) == 0)) {
        if (ch == '-') {
            sign = -1;
        } else {
            sign = f;
        }
        f = sign;
        ch = getchar();
    }
    while ((((*__ctype_b_loc())[(unsigned char)ch] & 0x800) != 0)) {
        *x = (ch ^ 0x30) + 10 * *x;
        ch = getchar();
    }
    *x *= f;
}
void printInt(int x)
{
    int value;
    int digit_stack[23];
    int stack_top;

    value = x;
    if (x != 0)
    {
        if (x < 0)
        {
            value = -x;
            putchar('-');
        }
        stack_top = -1;
        while (value != 0)
        {
            digit_stack[++stack_top] = value % 10 + '0';
            value /= 10;
        }
        while (stack_top >= 0)
        {
            int index = stack_top--;
            putchar(digit_stack[index]);
        }
    }
    else
    {
        putchar('0');
    }
}
int main()
{
    int sum[23];
    int n;
    int *id1;
    int *id;
    int *b;
    int *a;
    int base = 10;
    int cnt = 1;
    int i, j, k, l, m, p, q, r, s;

    readInt(&n);
    a = (int *)malloc(sizeof(int) * (n + 1));
    b = (int *)malloc(sizeof(int) * (n + 1));
    memset(sum, 0, sizeof(sum));
    id = (int *)malloc(sizeof(int) * (n + 1));
    id1 = (int *)malloc(sizeof(int) * (n + 1));

    for (i = 1; i <= n; ++i)
    {
        readInt(&a[i]);
        b[i] = a[i];
    }

    for (j = 1; j <= n; ++j)
    {
        int remainder = a[j] % base;
        ++sum[remainder];
    }

    for (k = 1; k <= 9; ++k)
    {
        sum[k] += sum[k - 1];
    }

    for (l = n; l > 0; --l)
    {
        int remainder = a[l] % base;
        int index = sum[remainder];
        sum[remainder] = index - 1;
        id[index] = l;
        a[l] /= base;
    }

    while (cnt <= 8)
    {
        memset(sum, 0, sizeof(sum));

        for (m = 1; m <= n; ++m)
        {
            id1[m] = id[m];
        }

        for (p = 1; p <= n; ++p)
        {
            int remainder = a[p] % base;
            ++sum[remainder];
        }

        for (q = 1; q <= 9; ++q)
        {
            sum[q] += sum[q - 1];
        }

        for (r = n; r > 0; --r)
        {
            int idx = id1[r];
            int remainder = a[idx] % base;
            int index = sum[remainder];
            sum[remainder] = index - 1;
            id[index] = idx;
            a[idx] /= base;
        }

        ++cnt;
    }

    for (s = 1; s <= n; ++s)
    {
        printInt(b[id[s]]);
        putchar(' ');
    }

    fflush(stdout);
    free(a);
    free(b);
    free(id);
    free(id1);
    return 0;
}