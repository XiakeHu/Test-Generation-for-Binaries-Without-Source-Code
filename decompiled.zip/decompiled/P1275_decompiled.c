#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

int nx, ny;
int **bd1;
int **bd2;
int *n1;
int *n2;
bool flg;

bool same(int i, int j) ;
bool sm(int i, int j, int cur) ;
bool match() ;
bool check(int cur) ;
void turn(int i) ;
void dfs(int cur) ;
int main() ;
bool same(int i, int j)
{
    bool is_same = true;
    for (int k = 1; k <= nx; ++k)
    {
        if (bd1[k][i] != bd2[k][j])
        {
            return false;
        }
    }
    return is_same;
}
bool sm(int i, int j, int cur)
{
    bool flag = true;
    for (int k = 1; k <= cur; ++k)
    {
        if (bd1[k][i] != bd2[k][j])
        {
            return false;
        }
    }
    return flag;
}
bool match()
{
    int* used_flags = (int*)malloc(0x1A4);
    memset(used_flags, 0, 8);
    
    for (int i = 1; i <= ny; ++i)
    {
        bool found_match = false;
        for (int j = 1; j <= ny; ++j)
        {
            if (!used_flags[j] && same(i, j))
            {
                used_flags[j] = i;
                found_match = true;
                break;
            }
        }
        if (!found_match)
        {
            free(used_flags);
            return false;
        }
    }
    
    free(used_flags);
    return true;
}
bool check(int cur)
{
    int *match_arr = (int *)malloc(0x1A4);
    memset(match_arr, 0, 8);
    
    for (int i = 1; i <= ny; ++i)
    {
        bool found_match = false;
        
        for (int j = 1; j <= ny; ++j)
        {
            if (match_arr[j] == 0 && sm(i, j, cur))
            {
                match_arr[j] = i;
                found_match = true;
                break;
            }
        }
        
        if (!found_match)
        {
            free(match_arr);
            return false;
        }
    }
    
    free(match_arr);
    return true;
}
void turn(int i)
{
    int column;
    
    for (column = 1; column <= ny; ++column)
    {
        bd1[i][column] ^= 1;
    }
}
void dfs(int cur)
{
    if (!flg)
    {
        if (cur == nx + 1)
        {
            flg = match();
        }
        else
        {
            dfs(cur + 1);
            if (n1[cur] == ny / 2)
            {
                turn(cur);
                if (check(cur))
                {
                    dfs(cur + 1);
                }
            }
        }
    }
}
int main()
{
    int test_case_count;
    scanf("%d", &test_case_count);

    bd1 = (int **)malloc(105 * sizeof(int *));
    bd2 = (int **)malloc(105 * sizeof(int *));
    n1 = (int *)malloc(105 * sizeof(int));
    n2 = (int *)malloc(105 * sizeof(int));

    for (int i = 0; i < 105; ++i)
    {
        bd1[i] = (int *)malloc(105 * sizeof(int));
        bd2[i] = (int *)malloc(105 * sizeof(int));
    }

    while (test_case_count--)
    {
        scanf("%d %d", &nx, &ny);
        memset(n1, 0, 105 * sizeof(int));
        memset(n2, 0, 105 * sizeof(int));

        for (int row = 1; row <= nx; ++row)
        {
            for (int col = 1; col <= ny; ++col)
            {
                scanf("%d", &bd1[row][col]);
                n1[row] += bd1[row][col];
            }
        }

        for (int row = 1; row <= nx; ++row)
        {
            for (int col = 1; col <= ny; ++col)
            {
                scanf("%d", &bd2[row][col]);
                n2[row] += bd2[row][col];
            }
        }

        bool is_possible = true;
        for (int row = 1; row <= nx; ++row)
        {
            if (n2[row] + n1[row] == ny)
            {
                turn(row);
            }
            else if (n1[row] != n2[row])
            {
                is_possible = false;
                break;
            }
        }

        flg = false;
        if (is_possible && (match() || (ny % 2 == 0 && (flg = 0, dfs(1), flg))))
        {
            printf("YES\n");
        }
        else
        {
            printf("NO\n");
        }
    }

    for (int i = 0; i < 105; ++i)
    {
        free(bd1[i]);
        free(bd2[i]);
    }
    free(bd1);
    free(bd2);
    free(n1);
    free(n2);

    return 0;
}