#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define MAX_SIZE 200005

typedef struct {
    int son[2];
    int fa;
    int maxl;
    int v;
} splay_node;

splay_node tree[MAX_SIZE];
int root = 0;
int tot = 0;
int n = 0;
long long mod = 0;
long long t = 0;

void update(int now);
void rotate(int now);
void splay(int now, int goal);
long long query(int l);
void insert(long long value, int number);

void update(int now)
{
    int left_child = tree[now].son[0];
    int right_child = tree[now].son[1];
    
    tree[now].maxl = tree[now].v;
    
    if (left_child)
    {
        int current_max = tree[now].maxl;
        if (tree[left_child].maxl >= current_max)
            current_max = tree[left_child].maxl;
        tree[now].maxl = current_max;
    }
    
    if (right_child)
    {
        int current_max = tree[now].maxl;
        if (tree[right_child].maxl >= current_max)
            current_max = tree[right_child].maxl;
        tree[now].maxl = current_max;
    }
}

void rotate(int now)
{
    int parent;
    int grandparent;
    int is_right_child;
    
    parent = tree[now].fa;
    grandparent = tree[parent].fa;
    is_right_child = (now == tree[parent].son[1]);
    
    tree[now].fa = grandparent;
    if (grandparent)
    {
        tree[grandparent].son[parent == tree[grandparent].son[1]] = now;
    }
    
    tree[parent].son[is_right_child] = tree[now].son[!is_right_child];
    if (tree[now].son[!is_right_child])
    {
        tree[tree[now].son[!is_right_child]].fa = parent;
    }
    
    tree[now].son[!is_right_child] = parent;
    tree[parent].fa = now;
    
    update(parent);
    update(now);
}

void splay(int now, int goal)
{
    int parent;
    int grandparent;

    while (goal != tree[now].fa)
    {
        parent = tree[now].fa;
        grandparent = tree[parent].fa;
        if (grandparent != goal)
        {
            if ((now == tree[parent].son[0]) != (parent == tree[grandparent].son[0]))
            {
                rotate(now);
            }
            else
            {
                rotate(parent);
            }
        }
        rotate(now);
    }
    if (!goal)
    {
        root = now;
    }
}

long long query(int l)
{
    long long result;

    if (l == tot - 1)
    {
        splay(1, 0);
        result = tree[1].maxl;
        splay(tot - 1, 0);
        return result;
    }
    else
    {
        splay(tot - l - 1, 0);
        return tree[tree[root].son[1]].maxl;
    }
}

void insert(long long value, int number)
{
    int parent = 0;
    int current_node = root;

    while (current_node != 0)
    {
        parent = current_node;
        current_node = tree[current_node].son[current_node < number];
    }

    ++tot;
    int new_node = number;
    tree[new_node].fa = parent;
    tree[parent].son[parent < number] = new_node;
    tree[new_node].v = value;
    update(new_node);
    splay(new_node, 0);
}

int main()
{
    long long x;
    char op;

    scanf("%d%lld", &n, &mod);
    while (n--)
    {
        getchar();
        scanf(" %c %lld", &op, &x);
        if (op == 'Q')
        {
            t = query(x);
            printf("%lld\n", t);
        }
        if (op == 'A')
            insert((x + t) % mod, tot);
    }
    return 0;
}