#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <ctype.h>

typedef long long ll;

inline ll read() {
    ll ans = 0;
    char ch = getchar(), last = ' ';
    while(!isdigit(ch)) {
        last = ch;
        ch = getchar();
    }
    while(isdigit(ch)) {
        ans = (ans << 1) + (ans << 3) + ch - '0';
        ch = getchar();
    }
    if(last == '-') ans = -ans;
    return ans;
}

int M, S, T;
int SS, TT;

int main() {
    M = (int)read();
    S = (int)read();
    T = (int)read();
    SS = S;
    TT = T;
    int i;
    for(i = 0; i < T; i++) {
        if(S <= 0) break;
        if(M >= 10) {
            M -= 10;
            S -= 60;
        } else if((T - i <= 1 || S <= 17) || (M < 6 && (T - i <= 2 || S <= 34)) || (M < 2 && (T - i <= 6 || S <= 119))) {
            S -= 17;
        } else if(M >= 2) {
            M += 4;
        } else if(S >= 120 && T - i >= 7) {
            while(S >= 120 && T - i >= 7) {
                S -= 120;
                i += 7;
            }
            i--;
        }
    }
    if(S <= 0) printf("Yes%d", i);
    else printf("No%d", SS - S);
    return 0;
}