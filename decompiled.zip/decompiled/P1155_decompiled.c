#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int v;
    int nxt;
} Graph;

int st_top[3];
int st[3][100005];
int now;
int col[100005];
int head[100005];
Graph gra[200010];
int idx;
int n;
int a[100005];
int suc[100005];

int check(int x);
void out(int x);
int make_color(int now, int color);
void add(int u, int v);

int check(int x)
{
    return (st_top[x] > 0) && (st[x][st_top[x]] == a[now] + 1);
}

void out(int x)
{
    ++now;
    --st_top[x];
    if (x == 1)
        printf("b ");
    else
        printf("d ");
}

int make_color(int now, int color)
{
    int neighbor_vertex;
    int edge_index;

    col[now] = color;
    for (edge_index = head[now]; edge_index != 0; edge_index = gra[edge_index].nxt)
    {
        neighbor_vertex = gra[edge_index].v;
        if (col[neighbor_vertex] != 0)
        {
            if (color == col[neighbor_vertex])
                return 0;
        }
        else if (make_color(neighbor_vertex, 3 - color) == 0)
        {
            return 0;
        }
    }
    return 1;
}

void add(int u, int v)
{
    idx++;
    gra[idx].v = v;
    gra[idx].nxt = head[u];
    head[u] = idx;
}

int main()
{
    int i;
    int j;
    int vertex_index;
    int current_vertex;
    int processing_vertex;

    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
        scanf("%d", &a[i]);

    suc[n] = a[n];
    for (vertex_index = n - 1; vertex_index > 0; --vertex_index)
        suc[vertex_index] = (suc[vertex_index + 1] < a[vertex_index]) ? suc[vertex_index + 1] : a[vertex_index];

    for (i = 1; i <= n; ++i)
    {
        for (j = i + 1; j < n; ++j)
        {
            if (suc[j + 1] < a[i] && a[i] < a[j])
            {
                add(i, j);
                add(j, i);
            }
        }
    }

    for (current_vertex = 1; current_vertex <= n; ++current_vertex)
    {
        if (!col[current_vertex] && !make_color(current_vertex, 1))
        {
            puts("0");
            return 0;
        }
    }

    now = 1;
    for (processing_vertex = 1; processing_vertex <= n; ++processing_vertex)
    {
        if (col[processing_vertex] == 2)
        {
            while (check(1))
                out(1);
        }

        while (st_top[col[processing_vertex]] > 0 && st[col[processing_vertex]][st_top[col[processing_vertex]]] < a[processing_vertex])
        {
            if (check(col[processing_vertex]))
                out(col[processing_vertex]);
            else
                out(3 - col[processing_vertex]);
        }

        if (col[processing_vertex] == 2)
        {
            while (check(1))
                out(1);
        }

        st[col[processing_vertex]][++st_top[col[processing_vertex]]] = a[processing_vertex];
        if (col[processing_vertex] == 1)
            printf("a ");
        else
            printf("c ");
    }

    while (st_top[1] > 0)
    {
        if (check(1))
            out(1);
        else
            out(2);
    }

    while (st_top[2] > 0)
        out(2);

    return 0;
}