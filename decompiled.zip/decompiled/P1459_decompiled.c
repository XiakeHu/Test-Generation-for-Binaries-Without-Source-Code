#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

 int main() ;
void swap(int *xp, int *yp) ;
int main()
{
    int n;
    int swap_count = 0;
    int count_1 = 0;
    int count_2 = 0;
    int count_3 = 0;
    int temp_value;
    int i, j;

    scanf("%d", &n);
    int a[n + 1]; // 假设数组a已定义，索引从1开始使用

    for (i = 1; i <= n; ++i)
    {
        scanf("%d", &a[i]);
        if (a[i] == 1)
            ++count_1;
        if (a[i] == 2)
            ++count_2;
        if (a[i] == 3)
            ++count_3;
    }

    for (i = 1; i <= count_1; ++i)
    {
        if (a[i] == 2)
        {
            for (j = count_1 + 1; j <= count_1 + count_2; ++j)
            {
                if (a[j] == 1)
                {
                    temp_value = a[i];
                    a[i] = a[j];
                    a[j] = temp_value;
                    ++swap_count;
                    break;
                }
            }
        }
        if (a[i] == 3)
        {
            for (j = count_1 + count_2 + 1; j <= count_1 + count_2 + count_3; ++j)
            {
                if (a[j] == 1)
                {
                    temp_value = a[i];
                    a[i] = a[j];
                    a[j] = temp_value;
                    ++swap_count;
                    break;
                }
            }
        }
    }

    for (i = 1; i <= count_1; ++i)
    {
        if (a[i] != 1)
        {
            for (j = count_1 + 1; j <= count_1 + count_2 + count_3; ++j)
            {
                if (a[j] == 1)
                {
                    temp_value = a[i];
                    a[i] = a[j];
                    a[j] = temp_value;
                    ++swap_count;
                    break;
                }
            }
        }
    }

    for (i = count_1 + 1; i <= count_1 + count_2; ++i)
    {
        if (a[i] == 3)
        {
            for (j = count_1 + count_2 + 1; j <= count_1 + count_2 + count_3; ++j)
            {
                if (a[j] == 2)
                {
                    temp_value = a[i];
                    a[i] = a[j];
                    a[j] = temp_value;
                    ++swap_count;
                    break;
                }
            }
        }
    }

    printf("%d", swap_count);
    return 0;
}
void swap(int *xp, int *yp)
{
    int temp;

    temp = *xp;
    *xp = *yp;
    *yp = temp;
}
