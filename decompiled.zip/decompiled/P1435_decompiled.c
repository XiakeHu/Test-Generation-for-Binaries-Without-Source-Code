#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define MAX_N 1000
char str1[MAX_N + 2];
char str2[MAX_N + 2];
int dp1[MAX_N + 1];
int dp2[MAX_N + 1];
int n;

void solve();
void solve()
{
    int temp_max;
    int j;
    int i_outer;
    int i;

    scanf("%s", &str1[1]);
    n = strlen(&str1[1]);
    for (i = 1; i <= n; ++i)
        str2[i] = str1[n - i + 1];
    for (i_outer = 1; i_outer <= n; ++i_outer)
    {
        for (j = 1; j <= n; ++j)
        {
            if (str1[i_outer] == str2[j])
            {
                dp1[j] = dp2[j - 1] + 1;
            }
            else
            {
                temp_max = dp2[j];
                if (temp_max < dp1[j - 1])
                    temp_max = dp1[j - 1];
                dp1[j] = temp_max;
            }
        }
        memcpy(dp2, dp1, sizeof(dp2));
    }
    printf("%d", n - dp1[n]);
}
int main()
{
    solve();
    return 0;
}