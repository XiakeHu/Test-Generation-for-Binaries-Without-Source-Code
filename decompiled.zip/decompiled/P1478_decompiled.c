#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int xi;
    int yi;
} apple;

int n, s, a, b;
apple ap[1001];
int visit[1001 * 1001];
int mem[1001][1001];

int cmp(const void *a, const void *b);
int dfs(int num, int rest);
int main();

int cmp(const void *a, const void *b)
{
    const apple *apple_a = (const apple *)a;
    const apple *apple_b = (const apple *)b;
    return apple_a->xi - apple_b->xi;
}

int dfs(int num, int rest)
{
    int temp_result;
    int max_count;

    if (num > n || ap[num].xi > a + b)
        return 0;
    if (visit[1001 * num + rest])
        return mem[num][rest];
    visit[1001 * num + rest] = 1;
    max_count = dfs(num + 1, rest);
    if (ap[num].xi <= a + b && rest >= ap[num].yi)
    {
        temp_result = dfs(num + 1, rest - ap[num].yi) + 1;
        if (max_count < temp_result)
            max_count = temp_result;
    }
    mem[num][rest] = max_count;
    return mem[num][rest];
}

int main()
{
    int i;
    int result;

    scanf("%d %d %d %d", &n, &s, &a, &b);
    for (i = 1; i <= n; ++i)
        scanf("%d %d", &ap[i].xi, &ap[i].yi);
    qsort(&ap[1], n, sizeof(apple), cmp);
    result = dfs(1, s);
    printf("%d", result);
    return 0;
}