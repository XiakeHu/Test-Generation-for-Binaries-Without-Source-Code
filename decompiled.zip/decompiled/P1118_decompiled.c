#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n, sum;
int ans[100];
int visited[100];
int pc[100];

int dfs(int i, int num, int v) ;
int main() ;
int dfs(int i, int num, int v)
{
    int j;

    if (v > sum)
        return 0;
    if (i == n)
    {
        if (v == sum)
        {
            ans[i] = num;
            return 1;
        }
        else
        {
            return 0;
        }
    }
    else
    {
        visited[num] = 1;
        for (j = 1; j <= n; ++j)
        {
            if (!visited[j] && dfs(i + 1, j, v + j * pc[i]))
            {
                ans[i] = num;
                return 1;
            }
        }
        visited[num] = 0;
        return 0;
    }
}
int main()
{
    int temp_index;
    int i;
    int j;

    scanf("%d%d", &n, &sum);
    temp_index = n - 1;
    pc[temp_index] = 1;
    pc[0] = pc[temp_index];
    if (n > 1)
    {
        for (i = 1; 2 * i < n; ++i)
        {
            j = n - 1 - i;
            pc[j] = (n - i) * pc[i - 1] / i;
            pc[i] = pc[j];
        }
    }
    if (dfs(0, 0, 0))
    {
        for (i = 1; i <= n; ++i)
        {
            printf("%d ", ans[i]);
        }
    }
    return 0;
}