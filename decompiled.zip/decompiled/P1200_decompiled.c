#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int turn(char c) ;
 int turn(char c) ;
int turn(char c)
{
    return c - 64;
}
int main()
{
    char s[32];
    char t[32];
    int len_s;
    int len_t;
    int i;
    int j;
    long long a;
    long long b;
    const char *result;

    scanf("%s", s);
    scanf("%s", t);
    len_s = strlen(s);
    len_t = strlen(t);
    a = 1LL;
    b = 1LL;

    for (i = 0; i < len_s; ++i)
    {
        a *= turn(s[i]);
    }

    for (j = 0; j < len_t; ++j)
    {
        b *= turn(t[j]);
    }

    if (a % 47 == b % 47)
    {
        result = "GO";
    }
    else
    {
        result = "STAY";
    }

    printf("%s", result);
    return 0;
}
