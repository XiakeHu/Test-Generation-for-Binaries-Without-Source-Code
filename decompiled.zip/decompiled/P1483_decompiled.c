#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef int64_t llt;
typedef uint32_t uint;

llt A[100005];
llt Lazy[1005];

int main()
{
    uint n, m;
    scanf("%u%u", &n, &m);

    for (uint i = 1; i <= n; ++i)
    {
        scanf("%ld", &A[i]);
    }

    for (uint i = 1; i <= m; ++i)
    {
        uint op, x;
        scanf("%u%u", &op, &x);

        if (op == 1)
        {
            llt y;
            scanf("%ld", &y);

            if (x > 1000)
            {
                for (uint j = x; j <= n; j += x)
                {
                    A[j] += y;
                }
            }
            else
            {
                Lazy[x] += y;
            }
        }
        else
        {
            if (x != 0)
            {
                llt ans = A[x];
                for (uint divisor = 1; divisor <= 1000; ++divisor)
                {
                    if (x % divisor == 0)
                    {
                        ans += Lazy[divisor];
                    }
                }
                printf("%ld\n", ans);
            }
            else
            {
                printf("0\n");
            }
        }
    }

    return 0;
}