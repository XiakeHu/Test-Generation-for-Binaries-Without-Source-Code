#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define MAXN 1005
#define INF 1215752192

struct edge {
    int to;
    int nex;
} e[MAXN * 2];
int d[MAXN];
int siz[MAXN];
int f[MAXN][MAXN];
int cnt;
int n, p, ans;
int x, y;

void add(int x, int y);
long long read();
void dfs1(int u, int fa);
void dfs2(int u, int fa);
int main();

void add(int x, int y)
{
    cnt = cnt + 1;
    e[cnt].to = y;
    e[cnt].nex = d[x];
    d[x] = cnt;
}

long long read()
{
    long long result = 0;
    long long sign = 1;
    char ch = getchar();
    
    while (ch > '9' || ch <= '0')
    {
        if (ch == '-')
            sign = -sign;
        ch = getchar();
    }
    
    while (ch <= '9' && ch > '0')
    {
        result = 10 * result + ch - '0';
        ch = getchar();
    }
    
    return sign * result;
}

void dfs1(int u, int fa)
{
    int v;
    int i;

    ++siz[u];
    for (i = d[u]; i; i = e[i].nex)
    {
        v = e[i].to;
        if (v != fa)
        {
            dfs1(v, u);
            siz[u] += siz[v];
        }
    }
    f[u][0] = 0;
    f[u][siz[u]] = 1;
}

void dfs2(int u, int fa)
{
    int child_node;
    int k;
    int j;
    int i;
    int temp_value;

    for (i = d[u]; i != 0; i = e[i].nex)
    {
        child_node = e[i].to;
        if (child_node != fa)
        {
            dfs2(child_node, u);
            for (j = siz[u] - 1; j > 0; --j)
            {
                for (k = 0; k <= j; ++k)
                {
                    temp_value = f[child_node][k] + f[u][j - k];
                    if (temp_value > f[u][j])
                    {
                        temp_value = f[u][j];
                    }
                    f[u][j] = temp_value;
                }
            }
        }
    }
    if (siz[u] >= p)
    {
        int candidate = f[u][siz[u] - p] + f[u][siz[u]];
        if (candidate < ans)
        {
            ans = candidate;
        }
    }
}

int main()
{
    int j;
    int i_outer;
    int i;

    n = read();
    p = read();
    ans = INF;
    cnt = 0;
    for (i = 1; i <= n; ++i) {
        d[i] = 0;
        siz[i] = 0;
        for (j = 0; j <= n; ++j) {
            f[i][j] = INF;
        }
    }
    for (i = 1; i < n; ++i)
    {
        x = read();
        y = read();
        add(x, y);
        add(y, x);
    }
    dfs1(1, 1);
    f[1][siz[1]] = 0;
    dfs2(1, 1);
    printf("%d", ans);
    return 0;
}