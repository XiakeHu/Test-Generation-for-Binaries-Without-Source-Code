#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n, m;
int dp[1005][1005];
int temp[1005][1005];
int ans;

void cal();
void spin120();
int main();

void cal()
{
    int row, col;
    int row_up, col_up;
    int row_down, col_down;
    int i, j, k;
    int max_upper, max_lower;
    int temp_val;

    for (row = n - 1; row > 0; --row)
    {
        for (col = 1; col < 2 * row; col += 2)
        {
            if (dp[row][col] > 0 && dp[row + 1][col] > 0 && dp[row + 1][col + 1] > 0 && dp[row + 1][col + 2] > 0)
            {
                temp_val = dp[row + 1][col];
                if (dp[row + 1][col + 2] < temp_val)
                    temp_val = dp[row + 1][col + 2];
                dp[row][col] = temp_val + 1;
            }
        }
    }

    for (row_up = 2; row_up <= n; ++row_up)
    {
        for (col_up = 4; col_up < 2 * (row_up - 1); col_up += 2)
        {
            if (dp[row_up][col_up] > 0 && dp[row_up - 1][col_up - 2] > 0 && dp[row_up - 1][col_up - 1] > 0 && dp[row_up - 1][col_up] > 0)
            {
                temp_val = dp[row_up - 1][col_up - 2];
                if (dp[row_up - 1][col_up] < temp_val)
                    temp_val = dp[row_up - 1][col_up];
                dp[row_up][col_up] = temp_val + 1;
            }
        }
    }

    for (i = 1; i <= n; ++i)
    {
        max_upper = 0;
        max_lower = 0;

        for (j = 1; j <= i; ++j)
        {
            for (k = 1; k < 2 * j; k += 2)
            {
                temp_val = dp[j][k];
                if (temp_val > i - j + 1)
                    temp_val = i - j + 1;
                if (max_upper < temp_val)
                    max_upper = temp_val;
            }
            for (k = 2; k < 2 * j; k += 2)
            {
                temp_val = dp[j][k];
                if (max_upper < temp_val)
                    max_upper = temp_val;
            }
        }

        for (j = i + 1; j <= n; ++j)
        {
            for (k = 1; k < 2 * j; k += 2)
            {
                temp_val = dp[j][k];
                if (max_lower < temp_val)
                    max_lower = temp_val;
            }
            for (k = 2; k < 2 * j; k += 2)
            {
                temp_val = dp[j][k];
                if (temp_val > j - i)
                    temp_val = j - i;
                if (max_lower < temp_val)
                    max_lower = temp_val;
            }
        }

        if (max_upper > 0 && max_lower > 0)
        {
            int candidate = max_lower * max_lower + max_upper * max_upper;
            if (candidate > ans)
                ans = candidate;
        }
    }
}
void spin120()
{
    int row_idx_1;
    int col_idx_1;
    int row_idx_2;
    int col_idx_2;
    int row_idx_3;
    int col_idx_3;

    memset(temp, 0, sizeof(temp));

    for (row_idx_1 = 1; row_idx_1 <= n; ++row_idx_1)
    {
        for (col_idx_1 = 1; col_idx_1 < 2 * row_idx_1; col_idx_1 += 2)
        {
            int temp_row = (col_idx_1 + 1) / -2 + 1;
            int temp_col = 205 * n + 2 * row_idx_1 - col_idx_1;
            temp[temp_row][temp_col] = (dp[row_idx_1][col_idx_1] != 0);
        }
    }

    for (row_idx_2 = 1; row_idx_2 <= n; ++row_idx_2)
    {
        for (col_idx_2 = 2; col_idx_2 < 2 * row_idx_2; col_idx_2 += 2)
        {
            int temp_row = col_idx_2 / -2 + 1;
            int temp_col = 205 * n + 2 * row_idx_2 - col_idx_2;
            temp[temp_row][temp_col] = (dp[row_idx_2][col_idx_2] != 0);
        }
    }

    for (row_idx_3 = 1; row_idx_3 <= n; ++row_idx_3)
    {
        for (col_idx_3 = 1; col_idx_3 < 2 * row_idx_3; ++col_idx_3)
        {
            dp[row_idx_3][col_idx_3] = temp[row_idx_3][col_idx_3];
        }
    }
}
int main()
{
    int y;
    int x;
    int i_0;
    int j;
    int i;

    ans = 0;
    scanf("%d%d", &n, &m);
    for (i = 1; i <= n; ++i)
    {
        for (j = 1; j < 2 * i; ++j)
            dp[i][j] = 1;
    }
    for (i_0 = 1; i_0 <= m; ++i_0)
    {
        scanf("%d%d", &x, &y);
        dp[x][y] = 0;
    }
    cal();
    spin120();
    cal();
    spin120();
    cal();
    printf("%d", ans);
    return 0;
}