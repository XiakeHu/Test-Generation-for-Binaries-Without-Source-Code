#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int first;
    int second;
}pair;

void swap(int *a, int *b) ;
 void solve(int n, int m) ;
   void solve(int n, int m); void swap(int *a, int *b);  int main() ;
void swap(int *a, int *b)
{
    int temp_value;

    temp_value = *a;
    *a = *b;
    *b = temp_value;
}
void solve(int n, int m)
{
    int length_str1;
    int length_str2;
    char *str1;
    char *str2;

    str1 = (char *)malloc(n + 1);
    str2 = (char *)malloc(m + 1);
    scanf("%s", str1);
    scanf("%s", str2);
    length_str1 = strlen(str1);
    length_str2 = strlen(str2);
    printf("Length of string 1: %d\n", length_str1);
    printf("Length of string 2: %d\n", length_str2);
    free(str1);
    free(str2);
}
int main()
{
    int n;
    int m;
    pair p;
    int a;
    int b;
    int min_value;
    int max_value;

    n = 5;
    m = 6;
    solve(n, m);

    p.first = 3;
    p.second = 4;
    printf("Pair: (%d, %d)\n", p.first, p.second);

    swap(&p.first, &p.second);
    printf("Swapped Pair: (%d, %d)\n", p.first, p.second);

    a = 5;
    b = 6;

    max_value = (a > b) ? a : b;
    printf("Max of %d and %d is %d\n", a, b, max_value);

    min_value = (a < b) ? a : b;
    printf("Min of %d and %d is %d\n", a, b, min_value);

    return 0;
}
