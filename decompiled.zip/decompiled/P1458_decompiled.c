#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int x;
    int y;
    double zzz;
}ujj;

int n;
int vis[1005][1005];
ujj ans[1000005];
int sum;
double ZZZ;

int gcd(int x, int y) ;
int cmp(const void *a, const void *b) ;
void dfs(int x) ;
int main() ;
int gcd(int x, int y)
{
    if (y != 0)
    {
        return gcd(y, x % y);
    }
    else
    {
        return x;
    }
}
int cmp(const void *a, const void *b)
{
    const ujj *first = (const ujj *)a;
    const ujj *second = (const ujj *)b;
    double value_a = first->zzz;
    double value_b = second->zzz;
    
    int greater = (value_a > value_b) ? 1 : 0;
    int less = (value_b > value_a) ? 1 : 0;
    
    return greater - less;
}
void dfs(int x)
{
    int i;
    int gcd_result;
    int reduced_x;
    int reduced_y;
    double ratio;

    if (x <= n)
    {
        for (i = n; i >= x; --i)
        {
            if (x < i)
            {
                gcd_result = gcd(x, i);
                reduced_x = x / gcd_result;
                reduced_y = i / gcd_result;

                if (!vis[reduced_x][reduced_y])
                {
                    vis[reduced_x][reduced_y] = 1;
                    ratio = (double)reduced_x / (double)reduced_y;
                    ZZZ = ratio;
                    ++sum;
                    ans[sum].x = reduced_x;
                    ans[sum].y = reduced_y;
                    ans[sum].zzz = ratio;
                }
            }
        }
        dfs(x + 1);
    }
}
int main()
{
    int i;

    scanf("%d", &n);
    sum = 0;
    dfs(1);
    qsort(&ans[1], sum, sizeof(ujj), cmp);
    printf("0/1");
    for (i = 1; i <= sum; ++i)
        printf("\n%d/%d", ans[i].x, ans[i].y);
    printf("\n1/1");
    return 0;
}