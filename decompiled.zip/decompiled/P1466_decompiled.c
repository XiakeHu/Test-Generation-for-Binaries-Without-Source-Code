#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n;
int sum;
long long f[41][820];

void solve()
{
    freopen("subset.in", "r", stdin);
    freopen("subset.out", "w", stdout);
    
    scanf("%d", &n);
    
    sum = (n + 1) * n / 2;
    
    if (sum % 2 == 1)
    {
        putchar('0');
    }
    else
    {
        memset(f, 0, sizeof(f));
        f[1][0] = 1;
        f[1][1] = 1;
        
        for (int i = 2; i <= n; ++i)
        {
            for (int j = 0; j <= sum; ++j)
            {
                if (j <= i)
                {
                    f[i][j] = f[i - 1][j];
                }
                else
                {
                    f[i][j] = f[i - 1][j] + f[i - 1][j - i];
                }
            }
        }
        
        printf("%lld", f[n][sum / 2] / 2);
    }
}
int main()
{
    solve();
    return 0;
}