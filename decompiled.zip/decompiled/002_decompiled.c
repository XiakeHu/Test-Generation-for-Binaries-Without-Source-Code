#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

const char *format = "Line count: %u\n";
const char *byte_2086 = "Word count: %u\n";
const char *byte_2095 = "Character count: %u\n";
const char *byte_20A7 = "Letter count: %u\n";
const char *byte_20BC = "Space count: %u\n";
const char *byte_20D0 = "Shortest word: %s (length: %u)\n";
const char *byte_20F0 = "Longest word: %s (length: %u)\n";
const char *s = "Enter text (end with empty line):\n";
const char *asc_2058 = "Analysis results:\n";
const char *byte_2039 = "No input provided.\n";

int is_word_char(char c) ;
int read_text_lines(char (*lines)[200], int max_lines) ;
void analyze_text(const char (*lines)[200], int line_count, const char (*words)[50], int word_count) ;
int extract_words(const char (*lines)[200], int line_count, char (*words)[50], int max_words) ;
int main() ;
int is_word_char(char c) {
    const unsigned short **ctype_b_loc = __ctype_b_loc();
    return ((*ctype_b_loc)[(unsigned char)c] & 0x400) != 0 || c == 39;
}
int read_text_lines(char (*lines)[200], int max_lines) {
    int count;
    int is_empty;
    int i;

    for (count = 0; count < max_lines && fgets(&(*lines)[200 * count], 200, stdin); ++count) {
        (*lines)[200 * count + strcspn(&(*lines)[200 * count], "\n")] = 0;
        is_empty = 1;
        for (i = 0; (*lines)[200 * count + i]; ++i) {
            if (((*__ctype_b_loc())[(unsigned char)(*lines)[200 * count + i]] & 0x2000) == 0) {
                is_empty = 0;
                break;
            }
        }
        if (is_empty) {
            break;
        }
    }
    return count;
}
void analyze_text(const char (*lines)[200], int line_count, const char (*words)[50], int word_count)
{
    unsigned int total_chars;
    int i;
    unsigned int letter_count;
    int i_0;
    int j;
    unsigned int space_count;
    int i_1;
    int j_0;
    int min_len;
    int max_len;
    int i_2;
    int len;
    char shortest_word[64];
    char longest_word[56];
    unsigned long v20;

    total_chars = 0;
    for (i = 0; i < line_count; ++i)
        total_chars += strlen(&(*lines)[200 * i]);
    letter_count = 0;
    for (i_0 = 0; i_0 < line_count; ++i_0)
    {
        for (j = 0; (*lines)[200 * i_0 + j]; ++j)
        {
            if (((*__ctype_b_loc())[(unsigned char)(*lines)[200 * i_0 + j]] & 0x400) != 0)
                ++letter_count;
        }
    }
    space_count = 0;
    for (i_1 = 0; i_1 < line_count; ++i_1)
    {
        for (j_0 = 0; (*lines)[200 * i_1 + j_0]; ++j_0)
        {
            if (((*__ctype_b_loc())[(unsigned char)(*lines)[200 * i_1 + j_0]] & 0x2000) != 0)
                ++space_count;
        }
    }
    min_len = 50;
    max_len = 0;
    memset(shortest_word, 0, 50);
    memset(longest_word, 0, 50);
    if (word_count > 0)
    {
        max_len = strlen((const char *)words);
        min_len = max_len;
        strcpy(shortest_word, (const char *)words);
        strcpy(longest_word, (const char *)words);
        for (i_2 = 1; i_2 < word_count; ++i_2)
        {
            len = strlen(&(*words)[50 * i_2]);
            if (len < min_len)
            {
                min_len = len;
                strcpy(shortest_word, &(*words)[50 * i_2]);
            }
            if (len > max_len)
            {
                max_len = len;
                strcpy(longest_word, &(*words)[50 * i_2]);
            }
        }
    }
    printf(format, (unsigned int)line_count);
    printf(byte_2086, (unsigned int)word_count);
    printf(byte_2095, total_chars);
    printf(byte_20A7, letter_count);
    printf(byte_20BC, space_count);
    if (word_count > 0)
    {
        printf(byte_20D0, shortest_word, (unsigned int)min_len);
        printf(byte_20F0, longest_word, (unsigned int)max_len);
    }
}
int extract_words(const char (*lines)[200], int line_count, char (*words)[50], int max_words) {
    char temp_char;
    int word_count = 0;
    int current_word_len = 0;
    int i;
    int j;
    
    word_count = 0;
    current_word_len = 0;
    for (i = 0; i < line_count && word_count < max_words; ++i) {
        for (j = 0; (*lines)[200 * i + j] && word_count < max_words; ++j) {
            char c = (*lines)[200 * i + j];
            if (is_word_char(c)) {
                if (current_word_len <= 48) {
                    temp_char = tolower(c);
                    (*words)[50 * word_count + current_word_len] = temp_char;
                    current_word_len++;
                }
            } else if (current_word_len > 0) {
                (*words)[50 * word_count + current_word_len] = 0;
                word_count++;
                current_word_len = 0;
            }
        }
        if (current_word_len > 0 && word_count < max_words) {
            (*words)[50 * word_count + current_word_len] = 0;
            word_count++;
            current_word_len = 0;
        }
    }
    return word_count;
}
int main() {
    int line_count;
    int word_count;
    char lines[50][200];
    char words[500][50];
    unsigned long v8;

    puts(s);
    line_count = read_text_lines(lines, 50);
    if (line_count) {
        word_count = extract_words(lines, line_count, words, 500);
        puts(asc_2058);
        analyze_text(lines, line_count, words, word_count);
    } else {
        puts(byte_2039);
    }
    return 0;
}