#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

#define MAX_N 105

int n;
int vis[MAX_N + 1][MAX_N + 1];
int negmap[MAX_N + 1][MAX_N + 1];
int edge[MAX_N + 1][MAX_N + 1];
int color[MAX_N + 1];
bool fail;
int dp[MAX_N + 1][MAX_N + 1];
int l[MAX_N + 1];
int ret[MAX_N + 1][MAX_N + 1];
int cur[MAX_N + 1][MAX_N + 1];
int team[MAX_N + 1][2][MAX_N + 1];
int white[MAX_N + 1];
int black[MAX_N + 1];

int compare(const void *a, const void *b);
void paint(int x, int Map, bool c);

int compare(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;
    return value_a - value_b;
}

void paint(int x, int Map, bool c)
{
    if (!fail)
    {
        if (color[x] == 1000000000 || color[x] == c)
        {
            if (color[x] == 1000000000)
            {
                int index = team[Map][c][0];
                team[Map][c][0] = index + 1;
                team[Map][c][index + 1] = x;
                color[x] = c;
                int delta = c ? 1 : -1;
                l[Map] += delta;
                for (int i = 0; i < edge[x][0]; ++i)
                {
                    int neighbor = edge[x][i + 1];
                    paint(neighbor, Map, !c);
                }
            }
        }
        else
        {
            fail = 1;
        }
    }
}

int main()
{
    int to;
    int i, j, k;
    int cnt = 0;
    int current_index;
    int delta;
    int abs_value;
    int temp_value;
    int current_group;
    int current_diff;
    int white_index;
    int black_index;

    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
    {
        while (1)
        {
            scanf("%d", &to);
            if (!to)
                break;
            if (vis[to][i])
            {
                negmap[to][i] = 1;
                negmap[i][to] = negmap[to][i];
            }
            else
            {
                vis[i][to] = 1;
            }
        }
    }
    for (i = 1; i <= n; ++i)
    {
        for (j = 1; j <= n; ++j)
        {
            if (i != j && !negmap[i][j])
                edge[i][++edge[i][0]] = j;
        }
    }
    for (i = 1; i <= n; ++i)
        color[i] = 1000000000;
    for (i = 1; i <= n; ++i)
    {
        if (color[i] == 1000000000)
        {
            paint(i, ++cnt, 1);
            if (fail)
            {
                printf("No solution");
                return 0;
            }
        }
    }
    dp[0][0] = 1;
    for (i = 0; i < cnt; ++i)
    {
        for (j = 0; j <= n; ++j)
        {
            if (dp[i][j])
            {
                if (j)
                {
                    temp_value = l[i + 1] + j;
                    abs_value = temp_value <= 0 ? -temp_value : temp_value;
                    ret[i + 1][abs_value] = j;
                    temp_value = j - l[i + 1];
                    abs_value = l[i + 1] - j >= 0 ? l[i + 1] - j : temp_value;
                    ret[i + 1][abs_value] = j;
                    temp_value = l[i + 1] + j;
                    abs_value = temp_value <= 0 ? -temp_value : temp_value;
                    dp[i + 1][abs_value] = 1;
                    temp_value = -(l[i + 1] + j);
                    abs_value = l[i + 1] + j > 0 ? l[i + 1] + j : temp_value;
                    cur[i + 1][abs_value] = cur[i][j];
                    if (l[i + 1] < 0)
                    {
                        temp_value = -(l[i + 1] + j);
                        abs_value = l[i + 1] + j > 0 ? l[i + 1] + j : temp_value;
                        cur[i + 1][abs_value] = !cur[i][j];
                    }
                    temp_value = j - l[i + 1];
                    abs_value = l[i + 1] - j >= 0 ? l[i + 1] - j : temp_value;
                    dp[i + 1][abs_value] = 1;
                    temp_value = l[i + 1] - j;
                    abs_value = temp_value < 0 ? j - l[i + 1] : temp_value;
                    cur[i + 1][abs_value] = cur[i][j];
                    if (l[i + 1] < 0)
                    {
                        temp_value = l[i + 1] - j;
                        abs_value = temp_value < 0 ? j - l[i + 1] : temp_value;
                        cur[i + 1][abs_value] = !cur[i][j];
                    }
                }
                else
                {
                    temp_value = l[i + 1];
                    abs_value = temp_value <= 0 ? -temp_value : temp_value;
                    ret[i + 1][abs_value] = 0;
                    temp_value = l[i + 1];
                    abs_value = temp_value <= 0 ? -temp_value : temp_value;
                    dp[i + 1][abs_value] = 1;
                    temp_value = -l[i + 1];
                    abs_value = l[i + 1] > 0 ? l[i + 1] : temp_value;
                    cur[i + 1][abs_value] = cur[i][0];
                    if (l[i + 1] < 0)
                    {
                        temp_value = -l[i + 1];
                        abs_value = l[i + 1] > 0 ? l[i + 1] : temp_value;
                        cur[i + 1][abs_value] = !cur[i][0];
                    }
                }
            }
        }
    }
    for (k = 0; k <= n; ++k)
    {
        if (dp[cnt][k])
            break;
    }
    if (k > n)
        return 0;
    current_diff = k;
    for (current_group = cnt; current_group > 0; --current_group)
    {
        if (cur[current_group][current_diff])
        {
            for (i = 0; i < team[current_group][1][0]; ++i)
            {
                white_index = white[0]++;
                white[white_index + 1] = team[current_group][1][i + 1];
            }
            for (i = 0; i < team[current_group][0][0]; ++i)
            {
                black_index = black[0]++;
                black[black_index + 1] = team[current_group][0][i + 1];
            }
        }
        else
        {
            for (i = 0; i < team[current_group][0][0]; ++i)
            {
                white_index = white[0]++;
                white[white_index + 1] = team[current_group][0][i + 1];
            }
            for (i = 0; i < team[current_group][1][0]; ++i)
            {
                black_index = black[0]++;
                black[black_index + 1] = team[current_group][1][i + 1];
            }
        }
        current_diff = ret[current_group][current_diff];
    }
    qsort(white + 1, white[0], sizeof(int), compare);
    qsort(black + 1, black[0], sizeof(int), compare);
    printf("%d ", white[0]);
    for (i = 1; i <= white[0]; ++i)
        printf("%d ", white[i]);
    putchar('\n');
    printf("%d ", black[0]);
    for (i = 1; i <= black[0]; ++i)
        printf("%d ", black[i]);
    return 0;
}