#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int first;
    int second;
}Pair;

int compare(const void *a, const void *b) ;
   int compare(const void *a, const void *b) ;
int compare(const void *a, const void *b)
{
    const Pair *pairA = (const Pair *)a;
    const Pair *pairB = (const Pair *)b;

    if (pairA->second > pairB->second)
        return -1;
    if (pairA->second < pairB->second)
        return 1;
    if (pairA->first < pairB->first)
        return -1;
    if (pairA->first > pairB->first)
        return 1;
    return 0;
}
int main(int argc, const char **argv, const char **envp) {
    int n;
    int m;
    Pair *arr;
    int i;
    int count;
    int currentIndex;

    scanf("%d %d", &n, &m);
    arr = (Pair *)malloc(sizeof(Pair) * n);
    for (i = 0; i < n; ++i) {
        scanf("%d %d", &arr[i].first, &arr[i].second);
    }
    qsort(arr, n, sizeof(Pair), compare);
    m = (int)floor((double)m * 1.5);
    count = 0;
    for (currentIndex = 0; currentIndex < n; ++currentIndex) {
        if (currentIndex > 0 && arr[currentIndex].second != arr[currentIndex - 1].second) {
            count += currentIndex;
        }
        if (count >= m) {
            printf("%d %d\n", arr[currentIndex].second, n - currentIndex);
            while (currentIndex < n) {
                printf("%d %d\n", arr[currentIndex].first, arr[currentIndex].second);
                ++currentIndex;
            }
            break;
        }
    }
    free(arr);
    return 0;
}
