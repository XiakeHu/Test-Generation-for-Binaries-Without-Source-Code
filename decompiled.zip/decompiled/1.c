#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// 1. 将 N 稍微开大，防止越界
#define N 10050 
#define ll long long

// 2. 宏定义加括号，保证安全
#define MAX(a,b) (((a) > (b)) ? (a) : (b))

typedef struct {
    int u, v, w, nex;
} Edge;

int n, tot, head[N], son[N], ms[N];
Edge e[N << 1];

// 3. 将 char 改为 int，解决 EOF 潜在死循环问题
// 4. 使用 static inline 确保链接安全
static inline ll read() {
    ll f = 1, x = 0;
    int c = getchar(); 
    while(c < '0' || c > '9') {
        if(c == '-') f = -1;
        c = getchar();
    }
    while('0' <= c && c <= '9') {
        x = (x << 3) + (x << 1) + (ll)(c - '0');
        c = getchar();
    }
    return x * f;
}

static inline void write(ll x) {
    if(x < 0) {
        putchar('-');
        x = -x;
    }
    if(x > 9) write(x / 10);
    putchar(x % 10 + '0');
}

static inline void add(int u, int v) {
    e[++tot].u = u;
    e[tot].v = v;
    e[tot].w = 1;
    e[tot].nex = head[u];
    head[u] = tot;
}

void DFS(int u, int fr) {
    son[u] = 1;
    ms[u] = 0; // 5. 显式初始化 ms[u]，防止多测数据残留（虽然此题可能只有单测）
    for(int i = head[u]; i; i = e[i].nex) {
        int v = e[i].v;
        if(v == fr) continue;
        DFS(v, u);
        son[u] += son[v];
        ms[u] = MAX(ms[u], son[v]);
    }
    ms[u] = MAX(ms[u], n - son[u]);
}

int main() {
    n = (int)read();
    if (n <= 0) return 0;

    for(int i = 1, u, v; i < n; ++i) {
        u = (int)read();
        v = (int)read();
        add(u, v);
        add(v, u);
    }
    
    DFS(1, 0);
    
    bool found = false;
    for(int i = 1; i <= n; ++i) {
        if(ms[i] <= (n / 2)) {
            found = true;
            write(i);
            putchar('\n');
        }
    }
    
    if(!found) {
        printf("NONE\n");
    }
    return 0;
}
