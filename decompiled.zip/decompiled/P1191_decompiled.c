#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int map[152][152];
int leftscan[152];

int count(int x, int y) ;
int main(int argc, const char **argv, const char **envp) ;
int count(int x, int y)
{
    int ans = 0;
    int M = 0x7FFFFFFF;
    int l;
    int j;

    for (l = x; !map[l][y]; --l)
    {
        for (j = 0; !map[l][y - j]; ++j)
            ;
        int temp_j = j;
        if (j > M)
            temp_j = M;
        leftscan[l] = temp_j;
        int temp_M = j;
        if (M <= j)
            temp_M = M;
        M = temp_M;
    }

    int i;
    int ja;
    for (i = y; !map[x][i]; --i)
    {
        for (ja = 0; !map[x - ja][i]; ++ja)
        {
            if (y - i < leftscan[x - ja])
                ++ans;
        }
    }

    int la;
    for (la = x; !map[la][y]; --la)
        leftscan[la] = 0;

    return ans;
}
int main(int argc, const char **argv, const char **envp)
{
    int temp_sum;
    char input_char;
    int dp[151][151];
    int n;
    int j_outer;
    int i_outer;
    int j_inner;
    int i_inner;

    memset(map, 0, sizeof(map));
    memset(dp, 0, sizeof(dp));
    scanf("%d", &n);
    for (i_inner = 1; i_inner <= n; ++i_inner)
    {
        for (j_inner = 1; j_inner <= n; ++j_inner)
        {
            scanf(" %c", &input_char);
            map[i_inner][j_inner] = input_char != 'W';
        }
    }
    for (i_outer = 1; i_outer <= n; ++i_outer)
    {
        for (j_outer = 1; j_outer <= n; ++j_outer)
        {
            temp_sum = dp[i_outer - 1][j_outer] + dp[i_outer][j_outer - 1] - dp[i_outer - 1][j_outer - 1];
            dp[i_outer][j_outer] = temp_sum + count(i_outer, j_outer);
        }
    }
    printf("%d", dp[n][n]);
    return 0;
}