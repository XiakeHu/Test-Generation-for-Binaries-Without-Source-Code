#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#define MAX 1005
typedef struct {
    int x;
    int y;
    int step;
}Point;

int head, tail;
Point q[MAX * MAX];
int a[MAX][MAX];
int vis[MAX][MAX];
int n, m, X, Y;
int xx[9] = {0, -2, -1, 1, 2, 2, 1, -1, -2};
int yy[9] = {0, 1, 2, 2, 1, -1, -2, -2, -1};

void bfs() ;
void Print(int x) ;
int main() ;
void bfs() {
    while (head < tail) {
        int current_head = head;
        head++;

        Point current_point = q[current_head];
        int current_step = current_point.step;

        a[current_point.x][current_point.y] = current_step;

        for (int direction = 1; direction <= 8; ++direction) {
            int next_x = current_point.x + xx[direction];
            int next_y = current_point.y + yy[direction];

            if (next_x > 0 && next_x <= n && next_y > 0 && next_y <= m && !vis[next_x][next_y]) {
                vis[next_x][next_y] = 1;

                q[tail].x = next_x;
                q[tail].y = next_y;
                q[tail].step = current_step + 1;

                tail++;
            }
        }
    }
}
void Print(int x)
{
    int temp_x;
    int space_count;
    int digit_count;

    temp_x = x;
    digit_count = 0;
    if (x)
    {
        while (temp_x > 0)
        {
            ++digit_count;
            temp_x /= 10;
        }
        for (space_count = 1; space_count <= 5 - digit_count; ++space_count)
            putchar(32);
    }
    else
    {
        printf("      ");
    }
}
int main()
{
    int j;
    int i;

    scanf("%d%d%d%d", &n, &m, &X, &Y);
    head = 0;
    tail = 1;
    q[0].x = X;
    q[0].y = Y;
    q[0].step = 0;
    vis[X][Y] = 1;
    bfs();
    for (i = 1; i <= n; ++i)
    {
        for (j = 1; j <= m; ++j)
        {
            if (!vis[i][j])
            {
                printf("-1   ");
            }
            else
            {
                printf("%d", a[i][j]);
                Print(a[i][j]);
            }
        }
        putchar(10);
    }
    return 0;
}