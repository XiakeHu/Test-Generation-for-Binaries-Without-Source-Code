#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef long long ll;

ll Pow(ll a, ll b, ll p);

int main();

ll Pow(ll a, ll b, ll p)
{
    ll result = 1;
    ll base = a;

    while (b > 0)
    {
        if ((b & 1) != 0)
        {
            result = (base * result) % p;
        }
        base = (base * base) % p;
        b >>= 1;
    }

    return result;
}
int main()
{
    int a, b;
    scanf("%d %d", &a, &b);

    ll tt = 1;
    ll temp = b;
    ll cnt = 0;

    while ((temp & 1) == 0)
    {
        ++cnt;
        temp >>= 1;
    }

    ll v3 = Pow(2, cnt - 1, b);
    tt = (tt * v3) % b;

    for (int i = 3; (ll)i * i <= b; i += 2)
    {
        cnt = 0;
        while (temp % i == 0)
        {
            ++cnt;
            temp /= i;
        }
        if (cnt > 0)
        {
            ll v4 = (tt * (i - 1)) % b;
            ll v5 = (v4 * Pow(i, cnt - 1, b)) % b;
            tt = v5;
        }
    }

    if (temp != 1)
    {
        tt = (tt * (temp - 1)) % b;
    }

    ll v6 = Pow(a, tt - 1, b);
    printf("%lld\n", v6 % b);

    return 0;
}