#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

typedef struct {
    int ans[7];
} Answer;

bool isLeapYear(int year);
void solve(Answer *a, int year);
Answer *new_answer();

bool isLeapYear(int year)
{
    if (year == 1900 || year == 2000 || year == 2100 || year == 2200 || year == 2300 || year == 2400 || year == 2500)
    {
        if (year % 400 == 0)
            return true;
    }
    else if ((year & 3) == 0)
    {
        return true;
    }
    return false;
}
void solve(Answer *a, int year)
{
    int currentDayOfWeek = 1;
    int currentMonth;
    int currentDayOfMonth;
    int daysInCurrentMonth;

    for (currentMonth = 1; currentMonth <= 12; ++currentMonth)
    {
        if (currentMonth == 2 && isLeapYear(year))
        {
            daysInCurrentMonth = 29;
        }
        else if ((currentMonth & 1) != 0)
        {
            daysInCurrentMonth = 31;
        }
        else
        {
            daysInCurrentMonth = 30;
        }

        if (currentMonth == 4 || currentMonth == 6 || currentMonth == 9 || currentMonth == 11)
        {
            daysInCurrentMonth = 30;
        }

        for (currentDayOfMonth = 1; currentDayOfMonth <= daysInCurrentMonth; ++currentDayOfMonth)
        {
            if (currentDayOfMonth == 13)
            {
                ++a->ans[currentDayOfWeek - 1];
            }

            currentDayOfWeek = (currentDayOfWeek % 7) + 1;
        }
    }
}
Answer *new_answer()
{
    Answer *answer_ptr;
    int i;

    answer_ptr = (Answer *)malloc(sizeof(Answer));
    for (i = 0; i <= 6; ++i)
        answer_ptr->ans[i] = 0;
    return answer_ptr;
}
int main()
{
    int n;
    Answer *ans;
    int year;

    scanf("%d", &n);
    ans = new_answer();
    for (year = 1900; year <= n + 1899; ++year)
        solve(ans, year);
    printf("%d %d %d %d %d %d %d",
           ans->ans[6],
           ans->ans[0],
           ans->ans[1],
           ans->ans[2],
           ans->ans[3],
           ans->ans[4],
           ans->ans[5]);
    free(ans);
    return 0;
}