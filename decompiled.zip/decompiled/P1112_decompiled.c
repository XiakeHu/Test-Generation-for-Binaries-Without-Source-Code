#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int v[4000000];
char s[100] = "";

void write(int x) ;
int read() ;
int main() ;
void write(int x)
{
    int abs_value = x;
    
    if (x < 0)
    {
        putchar('-');
        abs_value = -x;
    }
    
    if (abs_value > 9)
    {
        write(abs_value / 10);
    }
    
    putchar(abs_value % 10 + '0');
}
int read()
{
    char current_char;
    int sign;
    int value;

    value = 0;
    sign = 1;
    for ( current_char = getchar(); current_char <= 47 || current_char > 57; current_char = getchar() )
    {
        if ( current_char == 45 )
            sign = -1;
    }
    while ( current_char > 47 && current_char <= 57 )
    {
        value = 10 * value + current_char - 48;
        current_char = getchar();
    }
    return sign * value;
}
int main()
{
    int base_start, base_end;
    int range_start, range_end;
    int target_count;
    int base, coeff_a, coeff_b;
    int current_value;
    char toggle_flag;
    int i, j, idx;

    memset(v, 0, sizeof(v));
    base_start = read();
    base_end = read();
    range_start = read();
    range_end = read();
    target_count = read();

    for (base = base_start; base <= base_end; ++base)
    {
        for (coeff_a = 1; coeff_a < base; ++coeff_a)
        {
            for (coeff_b = 0; coeff_b < base; ++coeff_b)
            {
                if (coeff_a != coeff_b)
                {
                    current_value = 0;
                    toggle_flag = 0;
                    while (current_value <= range_end)
                    {
                        if (toggle_flag & 1)
                        {
                            current_value = base * current_value + coeff_b;
                        }
                        else
                        {
                            current_value = base * current_value + coeff_a;
                        }
                        ++toggle_flag;
                        if (current_value >= range_start && current_value <= range_end)
                        {
                            ++v[current_value];
                        }
                    }
                }
            }
        }
    }

    for (idx = range_start; idx <= range_end; ++idx)
    {
        if (target_count == v[idx])
        {
            write(idx);
            puts(s);
        }
    }
    return 0;
}