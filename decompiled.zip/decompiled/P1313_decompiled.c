#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef long long ll;

ll my_power(ll x, ll y);
ll dfs(ll n, ll m);
int main();

ll a, b, k, n, m;
ll c[1001][1001];

ll my_power(ll x, ll y)
{
    ll result = 1LL;
    ll base_mod = x % 10007;
    
    while (y)
    {
        if (y & 1)
        {
            result = (result * base_mod) % 10007;
        }
        base_mod = (base_mod * base_mod) % 10007;
        y >>= 1;
    }
    
    return result % 10007;
}
ll dfs(ll n, ll m)
{
    ll temp_ma;
    ll recursive_result;

    temp_ma = m;
    if (m)
    {
        if (m == 1)
        {
            c[n][1] = n;
            return c[n][1];
        }
        else if (c[n][m])
        {
            return c[n][m];
        }
        else
        {
            if (m > n - m)
                temp_ma = n - m;
            recursive_result = dfs(n - 1, temp_ma);
            c[n][temp_ma] = (recursive_result + dfs(n - 1, temp_ma - 1)) % 10007;
            return c[n][temp_ma];
        }
    }
    else
    {
        c[n][0] = 1LL;
        return c[n][0];
    }
}
int main()
{
    ll power_a_n;
    ll power_b_m;
    ll combination_result;
    ll answer;
    ll tn, tm;

    scanf("%lld%lld%lld%lld%lld", &a, &b, &k, &n, &m);
    a %= 10007LL;
    b %= 10007LL;
    power_a_n = my_power(a, n);
    power_b_m = my_power(b, m);
    answer = (power_b_m * power_a_n) % 10007;
    tn = n;
    tm = m;
    if (tn > tm)
    {
        tn = tm;
    }
    combination_result = dfs(k, tn) % 10007;
    answer = (answer * combination_result) % 10007;
    printf("%lld", answer);
    return 0;
}