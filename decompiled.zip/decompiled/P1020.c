#include <stdio.h>

#define MAX(a,b) (((a) > (b)) ? (a) : (b))

int tree[4000005], dp1[1000005], dp2[1000005], n, a[1000005], maxi, maxj;

void push_up(int cur) {
    tree[cur] = MAX(tree[cur * 2], tree[cur * 2 + 1]);
}

void build(int cur, int lt, int rt) {
    if(lt == rt) {
        tree[cur] = 1;
        return;
    }
    int mid = (lt + rt) >> 1;
    build(cur * 2, lt, mid);
    build(cur * 2 + 1, mid + 1, rt);
    push_up(cur);
}

void update(int cur, int lt, int rt, int qx, int val) {
    if(lt > qx || rt < qx) return;
    if(lt == rt) {
        tree[cur] = val;
        return;
    }
    int mid = (lt + rt) >> 1;
    update(cur * 2, lt, mid, qx, val);
    update(cur * 2 + 1, mid + 1, rt, qx, val);
    push_up(cur);
}

int query(int cur, int lt, int rt, int qx, int qy) {
    if(lt > qy || rt < qx) return -1;
    if(lt >= qx && rt <= qy) return tree[cur];
    int mid = (lt + rt) >> 1;
    return MAX(query(cur * 2, lt, mid, qx, qy), query(cur * 2 + 1, mid + 1, rt, qx, qy));
}

int main() {
    int x;
    while(scanf("%d", &x) != EOF) {
        a[++n] = x;
        maxi = MAX(maxi, x);
    }
    if (n == 0) return 0;
    build(1, 1, maxi);
    for(int i = 1; i <= n; i++) {
        dp1[i] = query(1, 1, maxi, a[i], maxi) + 1;
        maxj = MAX(maxj, dp1[i]);
        update(1, 1, maxi, a[i], dp1[i]);
    }
    printf("%d\n", maxj - 1);
    maxj = 0;
    build(1, 1, maxi);
    for(int i = 1; i <= n; i++) {
        dp2[i] = query(1, 1, maxi, 1, a[i] - 1) + 1;
        maxj = MAX(maxj, dp2[i]);
        update(1, 1, maxi, a[i], dp2[i]);
    }
    printf("%d", maxj - 1);
    return 0;
}