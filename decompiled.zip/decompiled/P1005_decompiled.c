#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int data[100];
    int len;
}BigInt;

   int main() ;
int main() {
    BigInt a;
    BigInt ans;
    char input_str[104];
    int m;
    int n;
    int str_len;
    int k;
    int j;
    int i;

    memset(&ans, 0, sizeof(ans));
    ans.len = 1;
    scanf("%d%d", &n, &m);
    for (i = 1; i <= n; ++i) {
        for (j = 1; j <= m; ++j) {
            scanf("%s", &input_str[1]);
            str_len = strlen(&input_str[1]);
            memset(&a, 0, sizeof(a));
            for (k = str_len; k > 0; --k) {
                int digit_char = input_str[k];
                a.data[++a.len] = digit_char - '0';
            }
        }
    }
    return 0;
}
