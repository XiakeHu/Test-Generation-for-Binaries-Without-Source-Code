#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int shu[505][505];
int ok[505][505];
int r[505];

int main()
{
    int n, m;
    scanf("%d %d", &n, &m);
    
    for (int i = 1; i <= n; ++i) {
        r[i] = 0;
        for (int j = 0; j < m; ++j) {
            scanf("%d %d", &ok[i][j], &shu[i][j]);
            if (ok[i][j] == 1) {
                ++r[i];
            }
        }
    }
    
    int x;
    scanf("%d", &x);
    
    int answer = 0;
    for (int i = 1; i <= n; ++i) {
        int current_value = shu[i][x];
        int count = 0;
        int j = x;
        
        while (1) {
            j %= m;
            if (ok[i][j] == 1) {
                ++count;
            }
            if (count - 1 == (current_value - 1) % r[i]) {
                break;
            }
            ++j;
        }
        
        answer = (answer + current_value) % 20123;
        x = j;
    }
    
    printf("%d", answer);
    return 0;
}