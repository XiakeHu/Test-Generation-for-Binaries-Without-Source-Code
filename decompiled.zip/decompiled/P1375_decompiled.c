#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define MAXN 2000005

int num;
int prime[MAXN];
int tot[MAXN];
int notprime[MAXN];

int times(int n, int t);
int Times(int n, int t);
long long power(int base, int exponent);
void solve(int n, int m);
int main();

int times(int n, int t)
{
    int ans = 0;
    while (n)
    {
        ans += n / t;
        n /= t;
    }
    return ans;
}

int Times(int n, int t)
{
    int count = 0;
    while (n != 0 && n % t == 0)
    {
        ++count;
        n /= t;
    }
    return count;
}

long long power(int base, int exponent)
{
    long long result = 1LL;
    const long long MOD = 1000000007LL;

    while (exponent)
    {
        if (exponent & 1)
        {
            result = (result * base) % MOD;
        }
        base = ((long long)base * base) % MOD;
        exponent >>= 1;
    }

    return result;
}

void solve(int n, int m)
{
    int prime_exponent_for_n_minus_m;
    int prime_exponent_for_m;
    int prime_exponent_for_n;
    int prime_index;

    for (prime_index = 1; prime_index <= num && n >= prime[prime_index]; ++prime_index)
    {
        prime_exponent_for_n = times(n, prime[prime_index]);
        prime_exponent_for_n_minus_m = times(n - m, prime[prime_index]);
        prime_exponent_for_m = times(m, prime[prime_index]);
        tot[prime[prime_index]] = prime_exponent_for_n - (prime_exponent_for_n_minus_m + prime_exponent_for_m);
    }
}

int main()
{
    int n;
    long long ans = 1LL;
    memset(notprime, 0, sizeof(notprime));
    num = 0;
    for (int i = 2; i <= 2000000; ++i)
    {
        if (!notprime[i])
            prime[++num] = i;
        for (int j = 1; j <= num; ++j)
        {
            if (i * prime[j] > 2000000)
                break;
            notprime[i * prime[j]] = 1;
            if (i % prime[j] == 0)
                break;
        }
    }
    scanf("%d", &n);
    solve(2 * n, n);
    for (int i = 1; i <= num && prime[i] <= n + 1; ++i)
        tot[prime[i]] -= Times(n + 1, prime[i]);
    for (int i = 1; i <= num; ++i)
    {
        if (tot[prime[i]])
            ans = ans * power(prime[i], tot[prime[i]]) % 1000000007;
    }
    printf("%lld", ans);
    return 0;
}