#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n, m1, m2, minx;
int S[1005];
int tot, m, s, flag, t, gcdd, q, ans, totq, tots;

int read() ;
int gcd(int a, int b) ;
int main() ;
int read()
{
    int sign;
    int value;
    char ch;

    ch = getchar();
    value = 0;
    sign = 1;
    while ( ch <= 47 || ch > 57 )
    {
        if ( ch == 45 )
            sign = -sign;
        ch = getchar();
    }
    while ( ch > 47 && ch <= 57 )
    {
        value = 10 * value + ch - 48;
        ch = getchar();
    }
    return sign * value;
}
int gcd(int a, int b)
{
    if (b != 0)
    {
        return gcd(b, a % b);
    }
    else
    {
        return a;
    }
}
int main()
{
    int gc;
    int outer_index;
    int inner_index;

    n = read();
    m1 = read();
    m2 = read();
    minx = 1000000000;
    if (m1 == 1)
    {
        putchar('0');
        return 0;
    }
    else
    {
        for (inner_index = 1; inner_index <= n; ++inner_index)
            S[inner_index] = read();
        for (outer_index = 1; outer_index <= n; ++outer_index)
        {
            tot = 0;
            m = m1;
            s = S[outer_index];
            flag = 1;
            t = 0;
            while (m != 1)
            {
                gcdd = gcd(m, s);
                if (gcdd == 1)
                {
                    flag = 0;
                    break;
                }
                m /= gcdd;
                q = s / gcdd;
                s = gcdd;
                ++t;
            }
            if (flag)
            {
                gc = gcd(q, s);
                if (gc == 1 || gc == s)
                {
                    while (q % s == 0)
                    {
                        ++tot;
                        q /= s;
                    }
                    if ((m2 * t + tot * (t - 1) * m2) % (tot + 1) != 0)
                        ans = (m2 * t + tot * (t - 1) * m2) / (tot + 1) + 1;
                    else
                        ans = (m2 * t + tot * (t - 1) * m2) / (tot + 1);
                }
                else
                {
                    totq = 0;
                    tots = 0;
                    while (q % gc == 0)
                    {
                        ++totq;
                        q /= gc;
                    }
                    while (s % gc == 0)
                    {
                        ++tots;
                        s /= gc;
                    }
                    if ((tots * m2 * t + totq * (t - 1) * m2) % (totq + tots) != 0)
                        ans = (tots * m2 * t + totq * (t - 1) * m2) / (totq + tots) + 1;
                    else
                        ans = (tots * m2 * t + totq * (t - 1) * m2) / (totq + tots);
                }
                if (ans < minx)
                    minx = ans;
            }
        }
        if (minx == 1000000000)
            printf("-1");
        else
            printf("%d", minx);
        return 0;
    }
}