#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int check(int val) ;
int Digit(int num) ;
void change(long long *n) ;
void decontor(int n, int p) ;
 long long val_fac[20]; long long val_pow[20]; int step_1[20];  int check(int val); void decontor(int n, int p); int Digit(int num); void change(long long *n);  int main() ;
int check(int val)
{
    while (val != 0)
    {
        int last_digit = val % 10;
        if (last_digit != 4 && last_digit != 7)
        {
            return 0;
        }
        val = val / 10;
    }
    return 1;
}
int Digit(int num)
{
    int digit_count = 0;
    while (num != 0)
    {
        num /= 10;
        ++digit_count;
    }
    return digit_count;
}
void change(long long *n)
{
    int digit_position;
    long long temp_value;

    temp_value = *n;
    digit_position = 0;
    while (temp_value % 10 == 7)
    {
        temp_value /= 10;
        *n = (long long)((double)(long long)*n - 3.0 * pow(10.0, (double)digit_position++));
    }
    *n = (long long)((double)(long long)*n + 3.0 * pow(10.0, (double)digit_position));
}
void decontor(int n, int p)
{
    int remaining_index;
    int *ans;
    int *available_numbers;
    int output_index;
    int current_remainder;
    int factorial_index;
    int init_index;

    available_numbers = (int *)malloc(sizeof(int) * n);
    for (init_index = 0; init_index < n; ++init_index)
        available_numbers[init_index] = init_index + 1;

    ans = (int *)malloc(sizeof(int) * n);
    factorial_index = n - 1;
    current_remainder = p - 1;

    while (factorial_index >= 0)
    {
        int quotient = current_remainder / val_fac[factorial_index];
        current_remainder %= val_fac[factorial_index];
        ans[factorial_index] = available_numbers[quotient];
        memmove(&available_numbers[quotient], &available_numbers[quotient + 1], sizeof(int) * (n - quotient - 1));
        --factorial_index;
    }

    for (output_index = 0; output_index < n; ++output_index)
        step_1[output_index + 1] = ans[output_index];

    free(ans);
    free(available_numbers);
}
int main()
{
    long long answer = 0LL;
    int n, p;
    scanf("%d %d", &n, &p);

    val_fac[0] = 1LL;
    val_pow[0] = 1LL;
    for (int i = 1; i <= 15; ++i)
        val_fac[i] = i * val_fac[i - 1];

    int digit_count = Digit(n);
    for (int i = 1; i <= digit_count; ++i)
        val_pow[i] = 2 * val_pow[i - 1];

    int limit_n = (n > 13) ? 13 : n;
    if (p > val_fac[limit_n])
    {
        printf("-1");
        return 0;
    }

    int decontor_n = (n > 13) ? 13 : n;
    decontor(decontor_n, p);

    if (n <= 13)
    {
        if (step_1[4] == 4 || step_1[4] == 7)
            ++answer;
        if (step_1[7] == 4 || step_1[7] == 7)
            ++answer;
    }
    else
    {
        if (n > 19)
        {
            for (int i = 1; i < digit_count; ++i)
                answer += val_pow[i];
        }
        if (n > 16 && n <= 19)
            ++answer;

        for (int i = 1; i <= 13; ++i)
            step_1[i] = step_1[i] + n - 13;

        long long current = 0LL;
        long long max_number = 0LL;
        for (int i = 1; i <= digit_count; ++i)
            current = 10 * current + 4;
        for (int i = 1; i <= digit_count; ++i)
            max_number = 10 * max_number + 7;

        if (max_number <= n - 13)
        {
            answer += val_pow[digit_count];
            current = n - 2;
        }

        while (n - 13 >= current && max_number != current)
        {
            ++answer;
            change(&current);
        }

        if (n - 13 >= current && max_number == current)
            ++answer;

        for (int i = 1; i <= 13; ++i)
        {
            if (check(n + i - 13))
            {
                if (check(step_1[i]))
                    ++answer;
            }
        }
    }

    printf("%lld", answer);
    return 0;
}
