#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    long long coef;
} Pair;

int compare(const void *a, const void *b) ;
int compare(const void *a, const void *b)
{
    const Pair *pairA = (const Pair *)a;
    const Pair *pairB = (const Pair *)b;

    if (pairA->coef < pairB->coef)
    {
        return -1;
    }
    else if (pairA->coef > pairB->coef)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int main() {
    long long n;
    Pair *coefficients;
    long long i;

    scanf("%lld", &n);
    coefficients = (Pair *)malloc(sizeof(Pair) * (n + 2));

    for (i = 1; i <= n + 1; ++i) {
        scanf("%lld", &coefficients[i].coef);
    }

    qsort(coefficients, n + 2, sizeof(Pair), compare);

    for (i = n; i >= 0; --i) {
        long long index = n - i + 1;
        long long abs_coef;

        if (coefficients[index].coef == 0) {
            continue;
        }

        if (i == 1 && n != 1) {
            abs_coef = coefficients[index].coef;
            if (abs_coef < 0) {
                abs_coef = -abs_coef;
            }

            if (abs_coef == 1) {
                if (coefficients[index].coef > 0) {
                    printf("+x");
                } else {
                    printf("-x");
                }
                continue;
            }

            if (coefficients[index].coef > 0) {
                printf("+%lldx", coefficients[index].coef);
            } else {
                printf("%lldx", coefficients[index].coef);
            }
            continue;
        }

        if (i == 1) {
            abs_coef = coefficients[index].coef;
            if (abs_coef < 0) {
                abs_coef = -abs_coef;
            }

            if (abs_coef == 1) {
                if (coefficients[index].coef > 0) {
                    putchar('x');
                } else {
                    printf("-x");
                }
                continue;
            }

            if (coefficients[index].coef > 0) {
                printf("+%lldx", coefficients[index].coef);
            } else {
                printf("%lldx", coefficients[index].coef);
            }
            continue;
        }

        if (i == n && i != 0) {
            abs_coef = coefficients[index].coef;
            if (abs_coef < 0) {
                abs_coef = -abs_coef;
            }

            if (abs_coef == 1) {
                if (coefficients[index].coef > 0) {
                    printf("x^%lld", i);
                } else {
                    printf("-x^%lld", i);
                }
                continue;
            }

            printf("%lldx^%lld", coefficients[index].coef, i);
            continue;
        }

        if (i != 0) {
            abs_coef = coefficients[index].coef;
            if (abs_coef < 0) {
                abs_coef = -abs_coef;
            }

            if (abs_coef == 1) {
                if (coefficients[index].coef > 0) {
                    printf("+x^%lld", i);
                } else {
                    printf("-x^%lld", i);
                }
                continue;
            }

            if (coefficients[index].coef > 0) {
                printf("+%lldx^%lld", coefficients[index].coef, i);
            } else {
                printf("%lldx^%lld", coefficients[index].coef, i);
            }
            continue;
        }

        if (coefficients[n + 1].coef >= 0) {
            if (n != 0) {
                printf("+%lld", coefficients[index].coef);
            } else {
                printf("%lld", coefficients[1].coef);
            }
        } else {
            printf("%lld", coefficients[index].coef);
        }
    }

    free(coefficients);
    return 0;
}