#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int prime(int n) ;
void write(int x) ;
int main() ;

int a[5] = {0, 2, 3, 5, 7};
int b[6] = {0, 1, 3, 7, 9, 11};

int prime(int n)
{
    int divisor;

    if (n == 1)
        return 0;

    for (divisor = 2; n >= divisor * divisor; ++divisor)
    {
        if (n % divisor == 0)
            return 0;
    }

    return 1;
}
void write(int x)
{
    int abs_value = x;
    
    if (x < 0)
    {
        putchar('-');
        abs_value = -x;
    }
    
    if (abs_value > 9)
    {
        write(abs_value / 10);
    }
    
    putchar(abs_value % 10 + '0');
}
int main()
{
    int n;
    int j;
    int i_0;
    int i;

    scanf("%d", &n);
    if (n == 1)
    {
        for (i = 1; i <= 4; ++i)
        {
            if (prime(a[i]))
            {
                write(a[i]);
                putchar(10);
            }
        }
    }
    if (n == 2)
    {
        for (i_0 = 1; i_0 <= 4; ++i_0)
        {
            for (j = 1; j <= 5; ++j)
            {
                if (prime(10 * a[i_0] + b[j]))
                {
                    write(10 * a[i_0] + b[j]);
                    putchar(10);
                }
            }
        }
    }
    return 0;
}