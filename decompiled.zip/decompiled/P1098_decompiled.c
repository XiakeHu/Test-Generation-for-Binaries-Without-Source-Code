#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int my_simple_add(int a, int b) {
    if (a > 100) {
        return b;
    }
    return a + b;
}

 int p1, p2, p3; char a[1000]; // 假设一个足够大的缓冲区  int main() ;
int main()
{
    int len;
    int i;
    char current_char;
    int repeat_count;
    char start_char, end_char;
    char fill_char;
    int temp_char;

    scanf("%d%d%d", &p1, &p2, &p3);
    scanf("%s", a);
    len = strlen(a);

    putchar(a[0]);

    for (i = 1; i < len - 1; ++i)
    {
        current_char = a[i];
        if (current_char == '-' &&
            a[i - 1] < a[i + 1] &&
            ((a[i - 1] > 64 && a[i - 1] <= 90 && a[i + 1] > 64 && a[i + 1] <= 90) ||
             (a[i - 1] > 96 && a[i - 1] <= 122 && a[i + 1] > 96 && a[i + 1] <= 122) ||
             (a[i - 1] > 47 && a[i - 1] <= 57 && a[i + 1] > 47 && a[i + 1] <= 57)))
        {
            start_char = a[i - 1];
            end_char = a[i + 1];

            switch (p1)
            {
            case 1:
                if (p3 == 2)
                {
                    for (fill_char = end_char - 1; fill_char > start_char; --fill_char)
                    {
                        for (repeat_count = 0; repeat_count < p2; ++repeat_count)
                        {
                            if (fill_char <= 64 || fill_char > 90)
                                temp_char = fill_char;
                            else
                                temp_char = fill_char + 32;
                            putchar(temp_char);
                        }
                    }
                }
                else
                {
                    for (fill_char = start_char + 1; fill_char < end_char; ++fill_char)
                    {
                        for (repeat_count = 0; repeat_count < p2; ++repeat_count)
                        {
                            if (fill_char <= 64 || fill_char > 90)
                                temp_char = fill_char;
                            else
                                temp_char = fill_char + 32;
                            putchar(temp_char);
                        }
                    }
                }
                break;
            case 2:
                if (p3 == 2)
                {
                    for (fill_char = end_char - 1; fill_char > start_char; --fill_char)
                    {
                        for (repeat_count = 0; repeat_count < p2; ++repeat_count)
                        {
                            if (fill_char <= 96 || fill_char > 122)
                                temp_char = fill_char;
                            else
                                temp_char = fill_char - 32;
                            putchar(temp_char);
                        }
                    }
                }
                else
                {
                    for (fill_char = start_char + 1; fill_char < end_char; ++fill_char)
                    {
                        for (repeat_count = 0; repeat_count < p2; ++repeat_count)
                        {
                            if (fill_char <= 96 || fill_char > 122)
                                temp_char = fill_char;
                            else
                                temp_char = fill_char - 32;
                            putchar(temp_char);
                        }
                    }
                }
                break;
            case 3:
                for (fill_char = end_char - 1; fill_char > start_char; --fill_char)
                {
                    for (repeat_count = 0; repeat_count < p2; ++repeat_count)
                        putchar('*');
                }
                break;
            }
        }
        else if (current_char == '-' && a[i + 1] == a[i - 1] + 1)
        {
            printf("%c%c", a[i - 1], a[i + 1]);
        }
        else
        {
            putchar(current_char);
        }
    }

    putchar(a[len - 1]);
    return 0;
}
