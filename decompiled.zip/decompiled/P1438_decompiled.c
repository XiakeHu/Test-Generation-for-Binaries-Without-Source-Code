#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef long long ll;
#define MAXN 100010

int n, m;
int a[MAXN];
typedef struct {
    int initval[MAXN];
    ll sumv[MAXN * 4];
    ll addv[MAXN * 4];
    int left;
    int right;
    ll val;
} SGT;

SGT sgt;

void maintain(SGT *sgt, int o, int L, int R) ;
void buildtree(SGT *sgt, int o, int L, int R) ;
void addtree(SGT *sgt, int o, int L, int R) ;
void querytree(SGT *sgt, int o, int L, int R, ll addval) ;
void build(SGT *sgt) ;
void add(SGT *sgt, int L, int R, ll v) ;
ll query(SGT *sgt, int L, int R) ;
int main() ;
void maintain(SGT *sgt, int o, int L, int R)
{
    sgt->sumv[o] = (R - L + 1) * sgt->addv[o];
    if (L != R)
    {
        int left_child = 2 * o;
        int right_child = 2 * o + 1;
        sgt->sumv[o] += sgt->sumv[left_child] + sgt->sumv[right_child];
    }
}
void buildtree(SGT *sgt, int o, int L, int R)
{
    if (L == R)
    {
        sgt->addv[o] = sgt->initval[L];
        sgt->sumv[o] = sgt->addv[o];
    }
    else
    {
        int mid = L + (R - L) / 2;
        int left_child = 2 * o;
        int right_child = left_child | 1;

        buildtree(sgt, left_child, L, mid);
        buildtree(sgt, right_child, mid + 1, R);

        sgt->addv[o] = 0LL;
        sgt->sumv[o] = sgt->sumv[left_child] + sgt->sumv[right_child];
    }
}
void addtree(SGT *sgt, int o, int L, int R)
{
    int mid;

    if (sgt->left > R || sgt->right < L)
        return;
    if (sgt->left <= L && R <= sgt->right)
    {
        sgt->addv[o] += sgt->val;
        maintain(sgt, o, L, R);
    }
    else
    {
        mid = (R + L) / 2;
        if (sgt->left <= mid)
            addtree(sgt, 2 * o, L, mid);
        if (sgt->right > mid)
            addtree(sgt, (2 * o) | 1, mid + 1, R);
        maintain(sgt, o, L, R);
    }
}
void querytree(SGT *sgt, int o, int L, int R, ll addval)
{
    int mid;

    if (sgt->left > R || sgt->right < L)
        return;
    if (sgt->left <= L && R <= sgt->right)
    {
        sgt->val += addval * (R - L + 1) + sgt->sumv[o];
    }
    else
    {
        mid = (R + L) / 2;
        if (sgt->left <= mid)
            querytree(sgt, 2 * o, L, mid, sgt->addv[o] + addval);
        if (sgt->right > mid)
            querytree(sgt, (2 * o) | 1, mid + 1, R, sgt->addv[o] + addval);
    }
}
void build(SGT *sgt)
{
    buildtree(sgt, 1, 1, n);
}
void add(SGT *sgt, int L, int R, ll v)
{
    sgt->left = L;
    sgt->right = R;
    sgt->val = v;
    addtree(sgt, 1, 1, n);
}
ll query(SGT *sgt, int L, int R)
{
    sgt->left = L;
    sgt->right = R;
    sgt->val = 0LL;
    querytree(sgt, 1, 1, n, 0LL);
    return sgt->val;
}
int main()
{
    int p;
    int d;
    int k;
    int r;
    int l;
    int order;
    int i_0;
    int i;
    ll query_result;

    scanf("%d%d", &n, &m);
    for (i = 1; i <= n; ++i)
    {
        scanf("%d", &a[i]);
        sgt.initval[i] = a[i] - a[i - 1];
    }
    build(&sgt);
    for (i_0 = 0; i_0 < m; ++i_0)
    {
        scanf("%d", &order);
        if (order == 1)
        {
            scanf("%d%d%d%d", &l, &r, &k, &d);
            add(&sgt, l, l, k);
            if (l != r)
                add(&sgt, l + 1, r, d);
            if (r != n)
                add(&sgt, r + 1, r + 1, -k - (ll)d * (r - l));
        }
        else
        {
            scanf("%d", &p);
            query_result = query(&sgt, 1, p);
            printf("%lld\n", query_result);
        }
    }
    return 0;
}