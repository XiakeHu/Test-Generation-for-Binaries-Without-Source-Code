#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    float x;
    float y;
    int flag;
}Point;

int n, d;
float x, y, z;
int sum;
Point point[1000];

int cmp(const void *a, const void *b) ;
void work() ;
void init() ;
int main(int argc, const char **argv, const char **envp) ;

int cmp(const void *a, const void *b)
{
    const Point *point_a = (const Point *)a;
    const Point *point_b = (const Point *)b;

    if (point_b->y <= point_a->y)
    {
        return 1;
    }
    else
    {
        return -1;
    }
}
void work()
{
    int j;
    int i;
    sum = 0;
    for (i = 0; i < n; ++i)
    {
        if (!point[i].flag)
        {
            point[i].flag = 1;
            ++sum;
            for (j = i + 1; j < n; ++j)
            {
                if (!point[j].flag && point[i].y >= point[j].x)
                    point[j].flag = 1;
            }
        }
    }
    printf("%d", sum);
}
void init()
{
    float temp_sqrt_result;
    int i;

    scanf("%d", &n);
    scanf("%d", &d);
    for (i = 0; i < n; ++i)
    {
        scanf("%f%f", &x, &y);
        if (y > (float)d)
        {
            printf("-1");
            return;
        }
        temp_sqrt_result = sqrtf((float)(d * d) - (y * y));
        z = temp_sqrt_result;
        point[i].x = x - temp_sqrt_result;
        point[i].y = temp_sqrt_result + x;
        point[i].flag = 0;
    }
    qsort(point, n, sizeof(Point), cmp);
    work();
}
int main(int argc, const char **argv, const char **envp)
{
    init();
    return 0;
}