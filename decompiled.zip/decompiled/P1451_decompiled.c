#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

char map[1000 * 1000];
int qx[1000000];
int qy[1000000];
int gx[4] = {0, 0, 1, -1};
int gy[4] = {1, -1, 0, 0};

int BFS_IAA_(int x, int y) ;
int main(int argc, const char **argv, const char **envp) ;
int BFS_IAA_(int x, int y)
{
    int head = 1;
    int tail = 0;
    int count = 0;
    int current_x;
    int current_y;
    int neighbor_x;
    int neighbor_y;
    int direction_index;

    map[1000 * x + y] = '0';
    qx[head] = x;
    qy[head] = y;

    do
    {
        ++count;
        current_x = qx[++tail];
        current_y = qy[tail];

        for (direction_index = 0; direction_index <= 3; ++direction_index)
        {
            neighbor_x = gx[direction_index] + current_x;
            neighbor_y = gy[direction_index] + current_y;

            if (map[1000 * neighbor_x + neighbor_y] != '0')
            {
                map[1000 * neighbor_x + neighbor_y] = '0';
                qx[++head] = neighbor_x;
                qy[head] = neighbor_y;
            }
        }
    } while (head != tail);

    return count;
}
int main(int argc, const char **argv, const char **envp)
{
    int rows;
    int cols;
    int inner_loop_j;
    int inner_loop_i;
    int outer_loop_j;
    int outer_loop_i;
    int island_count;

    island_count = 0;
    scanf("%d%d", &rows, &cols);
    memset(map, '0', sizeof(map));
    for (outer_loop_i = 1; outer_loop_i <= rows; ++outer_loop_i)
    {
        for (outer_loop_j = 1; outer_loop_j <= cols; ++outer_loop_j)
        {
            scanf(" %c", &map[1000 * outer_loop_i + outer_loop_j]);
        }
    }
    for (inner_loop_i = 1; inner_loop_i <= rows; ++inner_loop_i)
    {
        for (inner_loop_j = 1; inner_loop_j <= cols; ++inner_loop_j)
        {
            if (map[1000 * inner_loop_i + inner_loop_j] != '0')
            {
                BFS_IAA_(inner_loop_i, inner_loop_j);
                ++island_count;
            }
        }
    }
    printf("%d", island_count);
    return 0;
}