#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct node {
    int n;
    int v;
    struct node *next;
} Node;

int used[100005];
int dis[100005];
int q[100005];
int front, rear;
Node head[100005];
Node *tail[100005];

void spfa(int s) ;
int main() ;
void spfa(int s)
{
    int current_node_index;
    Node *current_edge;
    int front_index;

    memset(used, 0, sizeof(used));
    memset(dis, 0, sizeof(dis));
    front = rear = 0;
    q[++rear] = s;
    used[s] = 1;

    while (front <= rear)
    {
        front_index = front++;
        current_node_index = q[front_index];
        used[current_node_index] = 0;
        current_edge = &head[current_node_index];

        while (current_edge->next)
        {
            current_edge = current_edge->next;
            if (current_edge->v + dis[current_node_index] > dis[current_edge->n])
            {
                dis[current_edge->n] = dis[current_node_index] + current_edge->v;
                if (!used[current_edge->n])
                {
                    used[current_edge->n] = 1;
                    if (front <= rear && dis[current_edge->n] >= dis[q[front]])
                    {
                        q[++rear] = current_edge->n;
                    }
                    else
                    {
                        q[++rear] = current_edge->n;
                    }
                }
            }
        }
    }
}
int main()
{
    Node *current_tail_node;
    Node *new_edge_node;
    int constraint_c;
    int constraint_b;
    int constraint_a;
    int edge_count_m;
    int node_count_n;
    int loop_index_i1;
    int loop_index_i0;
    int loop_index_i;
    int t_value;
    int s_value;

    scanf("%d%d", &node_count_n, &edge_count_m);
    s_value = node_count_n;
    t_value = 1;
    tail[0] = &head[0];
    for (loop_index_i = 1; loop_index_i <= node_count_n + 1; ++loop_index_i)
    {
        tail[loop_index_i] = &head[loop_index_i];
        if (loop_index_i == node_count_n + 1)
            break;
        current_tail_node = tail[loop_index_i];
        current_tail_node->next = (Node *)malloc(sizeof(Node));
        new_edge_node = tail[loop_index_i]->next;
        new_edge_node->n = loop_index_i - 1;
        new_edge_node->v = -1;
        new_edge_node->next = 0;
        current_tail_node = tail[loop_index_i - 1];
        current_tail_node->next = (Node *)malloc(sizeof(Node));
        new_edge_node = tail[loop_index_i - 1]->next;
        new_edge_node->n = loop_index_i;
        new_edge_node->v = 0;
        new_edge_node->next = 0;
        tail[loop_index_i] = tail[loop_index_i]->next;
        tail[loop_index_i - 1] = tail[loop_index_i - 1]->next;
    }
    for (loop_index_i0 = 0; loop_index_i0 <= node_count_n; ++loop_index_i0)
    {
        current_tail_node = tail[node_count_n + 1];
        current_tail_node->next = (Node *)malloc(sizeof(Node));
        new_edge_node = tail[node_count_n + 1]->next;
        new_edge_node->n = loop_index_i0;
        new_edge_node->v = 123456789;
        new_edge_node->next = 0;
        tail[node_count_n + 1] = tail[node_count_n + 1]->next;
    }
    for (loop_index_i1 = 1; loop_index_i1 <= edge_count_m; ++loop_index_i1)
    {
        scanf("%d%d%d", &constraint_a, &constraint_b, &constraint_c);
        if (s_value >= constraint_a)
            s_value = constraint_a - 1;
        if (t_value < constraint_b)
            t_value = constraint_b;
        current_tail_node = tail[constraint_a - 1];
        current_tail_node->next = (Node *)malloc(sizeof(Node));
        new_edge_node = tail[constraint_a - 1]->next;
        new_edge_node->n = constraint_b;
        new_edge_node->v = constraint_c;
        new_edge_node->next = 0;
        tail[constraint_a - 1] = tail[constraint_a - 1]->next;
    }
    spfa(node_count_n + 1);
    printf("%d", dis[node_count_n] - 123456789);
    return 0;
}