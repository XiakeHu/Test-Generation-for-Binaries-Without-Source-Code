#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int compare(const void *a, const void *b) ;
 int compare(const void *a, const void *b) ;
int compare(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;
    return value_a - value_b;
}
int main(int argc, const char **argv, const char **envp)
{
    int s;
    int m;
    int n;
    int *b;
    int *a;
    int i;
    int i_1;
    int i_0;
    int ans;
    int long1;

    long1 = 0;
    ans = 0;
    scanf("%d %d %d", &n, &m, &s);
    a = (int *)malloc(4LL * (s + 1));
    for (i_0 = 1; i_0 <= s; ++i_0)
        scanf("%d", &a[i_0]);
    qsort(a, s + 1, 4uLL, (int (*)(const void *, const void *))compare);
    b = (int *)malloc(4LL * (s + 1));
    for (i_1 = 2; i_1 <= s; ++i_1)
        b[i_1] = a[i_1] - a[i_1 - 1] - 1;
    qsort(b + 2, s - 1, 4uLL, (int (*)(const void *, const void *))compare);
    ans = s;
    long1 = s;
    i = 2;
    while (ans > n)
    {
        --ans;
        long1 += b[i++];
    }
    printf("%d\n", long1);
    free(a);
    free(b);
    return 0;
}
