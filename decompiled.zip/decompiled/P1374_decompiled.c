#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int a_x;
    int a_y;
    int s_x;
    int s_y;
    int devil_x;
    int devil_y;
    int t;
    int t1;
}info;

 int n, m; int x, y, x2, y2; char mark[105][105]; char sal[100]; char devil[100]; info point;  int main(int argc, const char **argv, const char **envp) ;
int main(int argc, const char **argv, const char **envp) {
    int row_index;
    int col_index;

    freopen("code.in", "r", stdin);
    freopen("code.out", "w", stdout);

    scanf("%d %d %d %d", &n, &m, &x, &y);

    for (row_index = 1; row_index <= n; ++row_index) {
        for (col_index = 1; col_index <= m; ++col_index) {
            scanf(" %c", &mark[row_index][col_index]);
        }
    }

    scanf("%d %d %d %d", &x, &y, &x2, &y2);

    mark[x][y] = 1;
    getchar();
    fgets(sal, 100, stdin);
    fgets(devil, 100, stdin);

    point.s_x = x;
    point.a_x = x;
    point.s_y = y;
    point.a_y = y;
    point.devil_x = x2;
    point.devil_y = y2;
    point.t1 = 0;
    point.t = 0;

    return 0;
}