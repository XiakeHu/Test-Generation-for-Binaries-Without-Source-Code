#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

char* mul(char* a, const char* b);

int main(int argc, const char **argv, const char **envp)
{
    int n;
    int i;
    char *ans;
    size_t len;
    char last_char;

    scanf("%d", &n);
    ans = (char *)malloc(2);
    *(short *)ans = 50;
    for (i = 1; i <= n; ++i)
        ans = mul(ans, "2");
    len = strlen(ans);
    last_char = ans[len - 1] - 2;
    len = strlen(ans);
    ans[len - 1] = last_char;
    printf("%s", ans);
    free(ans);
    return 0;
}

char* mul(char* a, const char* b) {
    int len_a = strlen(a);
    int len_b = strlen(b);
    int result_len = len_a + len_b;
    char* result = (char*)calloc(result_len + 1, sizeof(char));
    if (result == NULL) {
        return NULL;
    }
    for (int i = 0; i < result_len; i++) {
        result[i] = '0';
    }

    for (int i = len_a - 1; i >= 0; i--) {
        int carry = 0;
        int digit_a = a[i] - '0';
        for (int j = len_b - 1; j >= 0; j--) {
            int digit_b = b[j] - '0';
            int pos = i + j + 1;
            int product = digit_a * digit_b + (result[pos] - '0') + carry;
            carry = product / 10;
            result[pos] = (product % 10) + '0';
        }
        result[i] += carry;
    }

    int start = 0;
    while (start < result_len && result[start] == '0') {
        start++;
    }
    if (start == result_len) {
        start = result_len - 1;
    }

    char* final_result = strdup(result + start);
    free(result);
    return final_result;
}