#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int a[32][32];
}mat;

int n, m, k;
int ok[1 << 6];
mat s;
long long ans;

mat* mat_mul(mat* retstr, mat a, mat b) ;
void work(int zt, int num) ;
mat* fastpow(mat* retstr, mat a, long long b) ;
void dfs(int x, int num, int zt) ;
int main() ;
mat* mat_mul(mat* retstr, mat a, mat b) {
    mat c;
    int i, j, k;

    memset(&c, 0, sizeof(c));

    for (i = 0; i < 32; ++i) {
        for (j = 0; j < 32; ++j) {
            for (k = 0; k < 32; ++k) {
                c.a[i][j] = (int)(((long long)a.a[i][k] * b.a[k][j] + c.a[i][j]) % 1000000007);
            }
        }
    }

    memcpy(retstr, &c, sizeof(mat));
    return retstr;
}
void work(int zt, int num)
{
    ok[zt] = 1;
    s.a[zt][zt >> 1] = 1;
    if (num != k || (zt & 1) != 0)
    {
        int shift_amount = m - 1;
        int base_index = (1 << shift_amount) + (zt >> 1);
        s.a[zt][base_index] = 1;
    }
}
mat* fastpow(mat* retstr, mat a, long long b)
{
    mat* result_ptr = retstr;
    long long exponent = b;
    mat res;
    int i;

    memset(&res, 0, sizeof(res));
    for (i = 0; i <= 31; ++i) {
        res.a[i][i] = 1;
    }

    while (exponent) {
        if (exponent & 1) {
            mat temp_res;
            mat temp_a;
            mat mul_result;

            memcpy(&temp_a, &a, sizeof(temp_a));
            memcpy(&temp_res, &res, sizeof(temp_res));
            mat_mul(&mul_result, temp_res, temp_a);
            memcpy(&res, &mul_result, sizeof(res));
        }

        mat temp_a1;
        mat temp_a2;
        mat mul_result;

        memcpy(&temp_a1, &a, sizeof(temp_a1));
        memcpy(&temp_a2, &a, sizeof(temp_a2));
        mat_mul(&a, temp_a1, temp_a2);

        exponent >>= 1;
    }

    memcpy(result_ptr, &res, sizeof(mat));
    return result_ptr;
}
void dfs(int x, int num, int zt)
{
    if (x == m + 1)
    {
        work(zt, num);
    }
    else
    {
        dfs(x + 1, num, zt);
        if (num < k)
        {
            int bit_position = x - 1;
            int new_zt = zt | (1 << bit_position);
            dfs(x + 1, num + 1, new_zt);
        }
    }
}
int main()
{
    mat temp_matrix1;
    mat temp_matrix2;
    int i;
    long long n_input;

    scanf("%lld %d %d", &n_input, &m, &k);
    n = (int)n_input;
    memset(ok, 0, sizeof(ok));
    memset(&s, 0, sizeof(s));
    ans = 0;
    dfs(1, 0, 0);
    memcpy(&temp_matrix1, &s, sizeof(temp_matrix1));
    fastpow(&temp_matrix2, temp_matrix1, n);
    memcpy(&s, &temp_matrix2, sizeof(s));
    for (i = 0; i < (1 << m); ++i)
    {
        if (ok[i])
        {
            int matrix_index = i;
            long long sum = s.a[0][matrix_index] + ans;
            long long mod_value = 1000000007LL;
            ans = sum % mod_value;
        }
    }
    printf("%lld", ans);
    return 0;
}