#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n, cnt;
int *cattle;
int *vis;
int *cha;

int compare(const void *a, const void *b) ;
 int compare(const void *a, const void *b) ;
int compare(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;
    return value_a - value_b;
}
int main()
{
    cattle = malloc(0x3D0914);
    vis = calloc(0xF4245, sizeof(int));
    cha = malloc(0x3D0914);

    while (scanf("%d", &n) != EOF)
    {
        cnt = 0;
        memset(cattle, 0, n * sizeof(int));
        for (int i = 0; i < n; ++i)
        {
            scanf("%d", &cattle[i]);
        }

        qsort(cattle, n, sizeof(int), compare);

        for (int i = 0; i < n - 1; ++i)
        {
            for (int j = i + 1; j < n; ++j)
            {
                int diff = cattle[j] - cattle[i];
                if (vis[diff] == 0)
                {
                    vis[diff] = 1;
                    cha[cnt++] = diff;
                }
            }
        }

        int max_value = cattle[n - 1];
        for (int candidate = 2; candidate <= max_value; ++candidate)
        {
            if (vis[candidate] == 0)
            {
                int is_valid = 1;
                for (int k = 0; k < cnt; ++k)
                {
                    if (cha[k] % candidate == 0)
                    {
                        is_valid = 0;
                        break;
                    }
                }
                if (is_valid)
                {
                    printf("%d\n", candidate);
                    break;
                }
            }
        }
    }

    free(cattle);
    free(vis);
    free(cha);
    return 0;
}