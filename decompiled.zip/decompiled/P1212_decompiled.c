#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int length;
    int width;
} rectangle;

typedef struct {
    int first;
    int second;
} pair_t;

rectangle rec[4];
int order[4] = {0, 1, 2, 3};
pair_t mp[100];
int mpSize = 0;
int ans = 0x7fffffff;
pair_t res[100];
int resSize = 0;

void update(int length, int width);
void part2();
void part3();
void part5();
void part1();
void part4();
void do_it();
void work(int depth);
int next_permutation(int *first, int *last);
void init();
void solve();
int main();

void update(int length, int width)
{
    int normalized_length = length;
    int normalized_width = width;

    if (length > width)
    {
        normalized_length = width;
        normalized_width = length;
    }

    for (int i = 0; i < mpSize; ++i)
    {
        if (normalized_length == mp[i].first && normalized_width == mp[i].second)
            return;
    }

    int area = normalized_width * normalized_length;
    if (area < ans)
    {
        ans = area;
        resSize = 0;
    }

    mp[mpSize].first = normalized_length;
    mp[mpSize].second = normalized_width;
    ++mpSize;

    res[resSize].first = normalized_length;
    res[resSize].second = normalized_width;
    ++resSize;
}

void part2()
{
    int max_width_1_2 = (int)fmax((double)rec[order[1]].width, (double)rec[order[2]].width);
    int max_width_0_1_2 = (int)fmax((double)rec[order[0]].width, (double)max_width_1_2);
    int total_width = max_width_0_1_2 + rec[order[3]].width;

    int sum_length_0_1_2 = rec[order[0]].length + rec[order[1]].length + rec[order[2]].length;
    int max_length = (int)fmax((double)sum_length_0_1_2, (double)rec[order[3]].length);

    update(max_length, total_width);
}

void part3()
{
    int max_width_01 = (int)fmax((double)rec[order[0]].width, (double)rec[order[1]].width);
    int total_width = (int)fmax((double)rec[order[3]].width, (double)max_width_01 + (double)rec[order[2]].width);
    int max_length_012 = (int)fmax((double)(rec[order[0]].length + rec[order[1]].length), (double)rec[order[2]].length);
    int total_length = (int)((double)max_length_012 + (double)rec[order[3]].length);
    update(total_length, total_width);
}

void part5()
{
    double y = (double)rec[order[3]].width;
    double v0 = fmax((double)(rec[order[0]].width + rec[order[1]].width), (double)rec[order[2]].width);
    int v1 = (int)fmax(v0, y);
    double v2 = fmax((double)rec[order[0]].length, (double)rec[order[1]].length);
    int length = (int)((double)rec[order[3]].length + (double)rec[order[2]].length + v2);
    update(length, v1);
}

void part1()
{
    int max_width_01;
    int max_width_23;
    int max_width_final;
    int total_length;

    max_width_23 = rec[order[3]].width > rec[order[2]].width ? rec[order[3]].width : rec[order[2]].width;
    max_width_01 = rec[order[1]].width > rec[order[0]].width ? rec[order[1]].width : rec[order[0]].width;
    max_width_final = max_width_01 > max_width_23 ? max_width_01 : max_width_23;

    total_length = rec[order[0]].length + rec[order[1]].length + rec[order[2]].length + rec[order[3]].length;

    update(total_length, max_width_final);
}

void part4()
{
    int width1 = rec[order[0]].width;
    int width2 = rec[order[1]].width;
    int width3 = rec[order[2]].width;
    int width4 = rec[order[3]].width;

    int max_width_temp = (width2 + width3) > width1 ? (width2 + width3) : width1;
    int final_width = width4 > max_width_temp ? width4 : max_width_temp;

    int length1 = rec[order[0]].length;
    int length2 = rec[order[1]].length;
    int length3 = rec[order[2]].length;
    int length4 = rec[order[3]].length;

    int max_length_temp = length2 > length3 ? length2 : length3;
    int total_length = length4 + length1 + max_length_temp;

    update(total_length, final_width);
}

void do_it()
{
    part1();
    part2();
    part3();
    part4();
    part5();
}

void work(int depth)
{
    int temp;
    int i;

    if (depth == 5)
    {
        do_it();
    }
    else
    {
        for (i = 0; i <= 3; ++i)
        {
            temp = rec[order[i]].length;
            rec[order[i]].length = rec[order[i]].width;
            rec[order[i]].width = temp;
            work(depth + 1);
            temp = rec[order[i]].length;
            rec[order[i]].length = rec[order[i]].width;
            rec[order[i]].width = temp;
            work(depth + 1);
        }
    }
}

int next_permutation(int *first, int *last)
{
    int *i;
    int *j;
    int temp;

    if (first == last || first == last - 1)
        return 0;

    for (i = last - 1; i > first && *i >= *(i - 1); --i)
        ;

    if (i == first)
        return 0;

    for (j = last - 1; *i >= *j; --j)
        ;

    temp = *i;
    *i = *j;
    *j = temp;

    i = i + 1;
    j = last - 1;
    while (i < j)
    {
        temp = *i;
        *i = *j;
        *j = temp;
        ++i;
        --j;
    }

    return 1;
}

void init()
{
    int i;
    for (i = 0; i <= 3; ++i)
        scanf("%d%d", &rec[i].length, &rec[i].width);
}

void solve()
{
    int i;

    do
    {
        work(1);
    } while (next_permutation(order, order + 4));

    printf("%d\n", ans);
    for (i = 0; i < resSize; ++i)
    {
        printf("%d %d\n", res[i].first, res[i].second);
    }
}

int main()
{
    init();
    solve();
    return 0;
}