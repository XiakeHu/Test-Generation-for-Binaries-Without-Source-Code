#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int t;
    int f;
    int h;
}Trash;

int compare(const void *a, const void *b) ;
   int compare(const void *a, const void *b) ;
int compare(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;
    return value_a - value_b;
}
int main() {
    Trash trash_list[101];
    int dp[101][1001];
    int total_distance, trash_count;
    int i, j, current_index, next_index;
    int remaining_time, total_time;

    memset(dp, -1, sizeof(dp));
    scanf("%d%d", &total_distance, &trash_count);
    for (i = 1; i <= trash_count; ++i) {
        scanf("%d%d%d", &trash_list[i].t, &trash_list[i].f, &trash_list[i].h);
    }
    qsort(&trash_list[1], trash_count, sizeof(Trash), compare);
    dp[0][0] = 10;
    trash_list[0].f = 0;
    trash_list[0].h = 0;
    trash_list[0].t = 0;

    for (current_index = 0; current_index < trash_count; ++current_index) {
        for (j = 0; j <= total_distance; ++j) {
            if (dp[current_index][j] >= 0) {
                next_index = current_index + 1;
                if (j + trash_list[next_index].h >= total_distance &&
                    dp[current_index][j] >= trash_list[next_index].t - trash_list[current_index].t) {
                    printf("%d", trash_list[next_index].t);
                    return 0;
                }
                if (dp[current_index][j] - trash_list[next_index].t + trash_list[current_index].t >= 0) {
                    dp[next_index][trash_list[next_index].h + j] =
                        dp[current_index][j] - trash_list[next_index].t + trash_list[current_index].t;
                }
                if (dp[current_index][j] - trash_list[next_index].t + trash_list[current_index].t >= 0) {
                    int new_value = dp[next_index][j];
                    int candidate = trash_list[current_index].t + dp[current_index][j] -
                                    trash_list[next_index].t + trash_list[next_index].f;
                    if (candidate > new_value) {
                        new_value = candidate;
                    }
                    dp[next_index][j] = new_value;
                }
            }
        }
    }

    remaining_time = 10;
    total_time = 0;
    for (i = 1; i <= trash_count && remaining_time >= trash_list[i].t - trash_list[i - 1].t; ++i) {
        int time_diff = trash_list[i].t - trash_list[i - 1].t;
        total_time += time_diff;
        remaining_time -= time_diff;
        remaining_time += trash_list[i].f;
    }
    printf("%d", total_time + remaining_time);
    return 0;
}
