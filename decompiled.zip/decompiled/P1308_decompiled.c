#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

typedef struct {
    char *str;
} String;

bool check(char a, char b) ;
   bool check(char a, char b) ;
bool check(char a, char b)
{
    return a == b;
}
int main() {
    size_t buffer_size = 0;
    String pattern = {0};
    String text = {0};

    pattern.str = NULL;
    text.str = NULL;
    buffer_size = 0;
    getline(&pattern.str, &buffer_size, stdin);
    getline(&text.str, &buffer_size, stdin);

    pattern.str = (char *)realloc(pattern.str, strlen(pattern.str) + 3);
    text.str = (char *)realloc(text.str, strlen(text.str) + 3);

    sprintf(pattern.str, " %s ", pattern.str);
    sprintf(text.str, " %s ", text.str);

    for (size_t i = 0; i < strlen(pattern.str); ++i) {
        if (pattern.str[i] >= 'A' && pattern.str[i] <= 'Z') {
            pattern.str[i] += 32;
        }
    }

    for (size_t i = 0; i < strlen(text.str); ++i) {
        if (text.str[i] >= 'A' && text.str[i] <= 'Z') {
            text.str[i] += 32;
        }
    }

    int match_count = 0;
    int first_match_index = -1;

    for (size_t text_index = 0; text_index < strlen(text.str); ++text_index) {
        bool is_match = true;
        size_t pattern_index = 0;
        size_t text_offset = text_index;

        while (pattern_index < strlen(pattern.str)) {
            if (!check(pattern.str[pattern_index], text.str[text_offset])) {
                is_match = false;
                break;
            }
            ++pattern_index;
            ++text_offset;
        }

        if (is_match) {
            ++match_count;
            if (first_match_index == -1) {
                first_match_index = (int)text_index;
            }
        }
    }

    if (match_count > 0) {
        printf("%d %d", match_count, first_match_index);
    } else {
        printf("%d", first_match_index);
    }

    free(pattern.str);
    free(text.str);

    return 0;
}