#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

unsigned long long a[10];
unsigned long long f[1024];

int main(int argc, const char **argv, const char **envp)
{
    unsigned long long n;
    unsigned long long k;
    int size;
    int j;
    int i;

    scanf("%llu %llu", &k, &n);
    a[0] = 1ULL;
    size = 1;
    for (i = 1; i <= 9; ++i)
        a[i] = k * a[i - 1];
    for (i = 0; i <= 9; ++i)
    {
        f[size] = a[i];
        for (j = 1; j <= size; ++j)
            f[size + j] = f[size] + f[j];
        size *= 2;
        if (f[n])
        {
            printf("%llu", f[n]);
            return 0;
        }
    }
    return 0;
}