#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>
typedef long long ll;

#define MAX_FACTORS 100
#define MAX_DIGITS 10000

int px[MAX_FACTORS];
int c[MAX_FACTORS];
int cnt;
int n, m;
int a[MAX_FACTORS];
ll p[MAX_FACTORS];
ll s[MAX_DIGITS];
int h;
ll fa[MAX_DIGITS];
int ha;
ll fb[MAX_DIGITS];
int hb;

void mul(ll b, ll *s, int *h) ;
bool compare(ll *fa, ll *fb, int ha, int hb) ;
void print(ll *s, int *h) ;
void spow(ll p, ll a, ll *s, int *h) ;
void resolve(int n) ;
void reuse(ll *s, int *h) ;
int main() ;

void mul(ll b, ll *s, int *h)
{
    int i;
    int j;

    for (i = 0; i <= *h; ++i)
    {
        s[i] *= b;
    }

    for (j = 0; j <= *h; ++j)
    {
        while (s[j] >= 10)
        {
            s[j + 1] += s[j] / 10;
            s[j] %= 10;
            if (j == *h)
            {
                ++(*h);
            }
        }
    }
}
bool compare(ll *fa, ll *fb, int ha, int hb)
{
    int i;

    if (ha > hb)
        return 1;
    if (ha < hb)
        return 0;

    for (i = ha; i >= 0; --i)
    {
        if (fa[i] > fb[i])
            return 1;
        if (fa[i] < fb[i])
            return 0;
    }

    return 0;
}
void print(ll *s, int *h)
{
    int index;
    
    for (index = *h; index >= 0; --index)
        printf("%lld", s[index]);
    putchar('\n');
}
void spow(ll p, ll a, ll *s, int *h)
{
    while (a != 0 && (double)p <= 1000000000.0)
    {
        if ((a & 1) != 0)
        {
            mul(p, s, h);
        }
        a >>= 1;
        p *= p;
    }
}
void resolve(int n)
{
    int divisor;
    cnt = 0;
    for (divisor = 2; n >= divisor * divisor; ++divisor)
    {
        if (n % divisor == 0)
        {
            px[++cnt] = divisor;
            c[cnt] = 0;
            while (n % divisor == 0)
            {
                ++c[cnt];
                n /= divisor;
            }
        }
    }
    
    if (n > 1)
    {
        px[++cnt] = n;
        c[cnt] = 1;
    }
}
void reuse(ll *s, int *h)
{
    int i;
    for (i = 0; i <= *h; ++i)
        s[i] = 0LL;
    *h = 0;
    *s = 1LL;
}
int main()
{
    int i;
    int j;
    int x;
    bool cmp;
    int outer_loop_index;
    int inner_loop_index;
    int final_loop_index;

    scanf("%d", &n);
    if (n > 1)
    {
        resolve(n);
        m = 0;
        for (i = cnt; i > 0; --i)
        {
            for (j = 1; j <= c[i]; ++j)
                a[++m] = px[i];
        }
        for (i = 1; i <= m; ++i) {
            p[i] = a[i];
        }
        h = 0;
        s[0] = 1;
        ha = 0;
        hb = 0;
        while (m != 1)
        {
            cmp = 0;
            x = m;
            reuse(fb, &hb);
            spow(p[m], a[m] - 1, fb, &hb);
            for (inner_loop_index = 1; inner_loop_index < m; ++inner_loop_index)
            {
                reuse(fa, &ha);
                spow(p[inner_loop_index], a[inner_loop_index] * (a[m] - 1), fa, &ha);
                if (compare(fb, fa, hb, ha))
                {
                    reuse(fb, &hb);
                    spow(p[inner_loop_index], a[inner_loop_index] * (a[m] - 1), fb, &hb);
                    x = inner_loop_index;
                }
            }
            reuse(fa, &ha);
            spow(p[m], a[m] - 1, fa, &ha);
            if (compare(fa, fb, ha, hb))
            {
                a[x] *= a[m];
                a[m--] = 0;
                cmp = 1;
            }
            if (!cmp)
                break;
            reuse(fa, &ha);
            reuse(fb, &hb);
        }
        reuse(s, &h);
        s[0] = 1;
        for (final_loop_index = 1; final_loop_index <= m; ++final_loop_index)
            spow(p[final_loop_index], a[final_loop_index] - 1, s, &h);
        print(s, &h);
        return 0;
    }
    else
    {
        printf("%d", n);
        return 0;
    }
}