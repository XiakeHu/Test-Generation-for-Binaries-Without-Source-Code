#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

char zhuan_h(int x) ;
int zhuan(char x) ;
void bian() ;
bool hw() ;
 int n; char m[1000]; int ans = 0; int p = 0;  bool hw(); void bian();  int main() ;
char zhuan_h(int x)
{
    if (x >= 0 && x <= 9)
        return (char)(x + '0');
    
    switch (x)
    {
        case 10: return 'A';
        case 11: return 'B';
        case 12: return 'C';
        case 13: return 'D';
        case 14: return 'E';
        case 15: return 'F';
        default: return 0;
    }
}
int zhuan(char x)
{
    int result = x;
    
    if (x > 47 && x <= 57)
        return x - 48;
    
    switch (x)
    {
        case 'A':
            return 10;
        case 'B':
            return 11;
        case 'C':
            return 12;
        case 'D':
            return 13;
        case 'E':
            return 14;
        case 'F':
            return 15;
    }
    
    return result;
}
void bian()
{
    char temp_char;
    char buffer[115];
    int carry;
    int digit1;
    int digit2;
    int current_result;
    int length;
    int inner_index;
    int outer_index;
    int i;

    length = strlen(m);
    for (i = 0; i < length / 2; ++i)
    {
        temp_char = m[i];
        m[i] = m[length - i - 1];
        m[length - i - 1] = temp_char;
    }

    memset(buffer, 0, sizeof(buffer));
    carry = 0;
    digit1 = 0;
    digit2 = 0;
    current_result = 0;

    for (outer_index = strlen(m) - 1; outer_index >= 0; --outer_index)
    {
        digit1 = zhuan(m[outer_index]);
        digit2 = zhuan(m[outer_index]);
        current_result = (digit2 + digit1 + carry) % n;
        carry = (digit2 + digit1 + carry) >= n;
        sprintf(buffer, "%c%s", zhuan_h(current_result), buffer);
    }

    if (carry == 1)
    {
        sprintf(buffer, "1%s", buffer);
    }

    strcpy(m, buffer);
}
bool hw()
{
    int length;
    int i;

    length = strlen(m);
    for (i = 0; i < length / 2; ++i)
    {
        if (m[i] != m[length - 1 - i])
            return false;
    }
    return true;
}
int main()
{
    scanf("%d", &n);
    scanf("%s", m);

    p = hw();
    while (!p)
    {
        if (ans > 30)
        {
            printf("Impossible!");
            exit(0);
        }
        ++ans;
        bian();
        p = hw();
    }

    printf("STEP=%d", ans);
    return 0;
}