#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

void goldbach(int num) ;
int main() ;
void goldbach(int num)
{
    int prime_j;
    int prime_i;
    int prime[1300];

    for (int i = 0; i <= 1298; ++i)
    {
        for (int j = 0; j <= 1298; ++j)
        {
            if (num == prime[i] + prime[j])
            {
                printf("%d=%d+%d", num, prime[i], prime[j]);
                return;
            }
        }
    }
}
int main()
{
    int i;
    int n;
    scanf("%d", &n);
    for (i = 4; i <= n; i += 2)
        goldbach(i);
    return 0;
}