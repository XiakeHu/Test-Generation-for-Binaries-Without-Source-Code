#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    double d[2];
    double minn[2];
    double maxn[2];
    int ch[2];
} node;

node t[200005];
int D, n, rt;
double nowx, nowy, minn, ansmin;

double gmin(int x);
double dis(int x);
int cmp(const void *a, const void *b);
void pushup(int x);
int Cmp(const void *a, const void *b);
void qmin(int now);
void build(int *root, int l, int r, int d);
int main();

double gmin(int x)
{
    double sum = 0.0;
    
    if (nowx > t[x].maxn[0])
        sum += (nowx - t[x].maxn[0]) * (nowx - t[x].maxn[0]);
    
    if (t[x].minn[0] > nowx)
        sum += (nowx - t[x].minn[0]) * (nowx - t[x].minn[0]);
    
    if (nowy > t[x].maxn[1])
        sum += (nowy - t[x].maxn[1]) * (nowy - t[x].maxn[1]);
    
    if (t[x].minn[1] > nowy)
        sum += (nowy - t[x].minn[1]) * (nowy - t[x].minn[1]);
    
    return sum;
}
double dis(int x)
{
    double dx = t[x].d[0] - nowx;
    double dy = t[x].d[1] - nowy;
    return dx * dx + dy * dy;
}
int cmp(const void *a, const void *b)
{
    const node *point_a = (const node *)a;
    const node *point_b = (const node *)b;
    
    if (point_b->d[D] <= point_a->d[D])
    {
        return point_a->d[D] != point_b->d[D];
    }
    else
    {
        return -1;
    }
}
void pushup(int x)
{
    int left_child = t[x].ch[0];
    int right_child = t[x].ch[1];

    if (left_child)
    {
        t[x].maxn[0] = fmax(t[x].maxn[0], t[left_child].maxn[0]);
        t[x].maxn[1] = fmax(t[x].maxn[1], t[left_child].maxn[1]);
        t[x].minn[0] = fmin(t[x].minn[0], t[left_child].minn[0]);
        t[x].minn[1] = fmin(t[x].minn[1], t[left_child].minn[1]);
    }

    if (right_child)
    {
        t[x].maxn[0] = fmax(t[x].maxn[0], t[right_child].maxn[0]);
        t[x].maxn[1] = fmax(t[x].maxn[1], t[right_child].maxn[1]);
        t[x].minn[0] = fmin(t[x].minn[0], t[right_child].minn[0]);
        t[x].minn[1] = fmin(t[x].minn[1], t[right_child].minn[1]);
    }
}
int Cmp(const void *a, const void *b)
{
    const node *point_a = (const node *)a;
    const node *point_b = (const node *)b;

    if (point_b->d[0] > point_a->d[0])
        return -1;

    if (fabs(point_a->d[0] - point_b->d[0]) > 0.000001 || point_b->d[1] <= point_a->d[1])
        return 0;

    return -1;
}
void qmin(int now)
{
    double right_subtree_min_distance;
    double left_subtree_min_distance;
    double current_node_distance;

    if (now)
    {
        current_node_distance = dis(now);
        left_subtree_min_distance = gmin(t[now].ch[0]);
        right_subtree_min_distance = gmin(t[now].ch[1]);

        if (current_node_distance >= 0.000001)
            minn = fmin(minn, current_node_distance);

        if (right_subtree_min_distance <= left_subtree_min_distance)
        {
            if (minn > right_subtree_min_distance)
                qmin(t[now].ch[1]);
            if (minn > left_subtree_min_distance)
                qmin(t[now].ch[0]);
        }
        else
        {
            if (minn > left_subtree_min_distance)
                qmin(t[now].ch[0]);
            if (minn > right_subtree_min_distance)
                qmin(t[now].ch[1]);
        }
    }
}
void build(int *root, int l, int r, int d)
{
    int mid;

    if (l <= r)
    {
        mid = (l + r) >> 1;
        D = d;
        *root = mid;
        qsort((void *)(t + l), r - l + 1, sizeof(node), cmp);
        build(&t[mid].ch[0], l, mid - 1, d ^ 1);
        build(&t[mid].ch[1], mid + 1, r, d ^ 1);
        pushup(mid);
    }
    else
    {
        *root = 0;
    }
}
int main()
{
    int i;
    int j;
    int k;
    double sqrt_result;

    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
    {
        scanf("%lf%lf", &t[i].d[0], &t[i].d[1]);
        t[i].maxn[0] = t[i].d[0];
        t[i].minn[0] = t[i].d[0];
        t[i].maxn[1] = t[i].d[1];
        t[i].minn[1] = t[i].d[1];
    }
    qsort(&t[1], n, sizeof(node), Cmp);
    ansmin = 1.0e100;
    for (j = 2; j <= n; ++j)
    {
        if (fabs(t[j].d[0] - t[j - 1].d[0]) <= 0.000001 && fabs(t[j].d[1] - t[j - 1].d[1]) <= 0.000001)
            ansmin = 0.0;
    }
    build(&rt, 1, n, 1);
    for (k = 1; k <= n; ++k)
    {
        nowx = t[k].d[0];
        nowy = t[k].d[1];
        minn = 1.0e100;
        qmin(rt);
        ansmin = fmin(ansmin, minn);
    }
    sqrt_result = sqrt(ansmin);
    printf("%.4lf", sqrt_result);
    return 0;
}