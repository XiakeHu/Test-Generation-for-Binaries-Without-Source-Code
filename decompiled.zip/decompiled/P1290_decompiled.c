#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

 int main() ;
int main()
{
    int test_case_count;
    double n, m;
    int i;

    scanf("%d", &test_case_count);
    for (i = 1; i <= test_case_count; ++i)
    {
        scanf("%lf %lf", &m, &n);
        if (m == n)
        {
            puts("Stan wins");
            continue;
        }
        if (n <= m)
        {
            if (m / n > 1.618033988749895)
            {
                puts("Stan wins");
                continue;
            }
        }
        else if (n / m > 1.618033988749895)
        {
            puts("Stan wins");
            continue;
        }
        puts("Ollie wins");
    }
    return 0;
}
