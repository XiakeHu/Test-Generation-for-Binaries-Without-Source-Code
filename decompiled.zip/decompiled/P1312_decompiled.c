#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int compare(const void *a, const void *b) ;
 void solve_double(double *x) ;
void solve_int(int *x) ;
 int main() ;
int compare(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;
    return value_a - value_b;
}
void solve_double(double *x)
{
    printf("Enter a double: ");
    scanf("%lf", x);
}
void solve_int(int *x)
{
    printf("Enter an integer: ");
    scanf("%d", x);
}
int main()
{
    double max_value;
    double min_value;
    double double_input;
    int integer_input;
    int *array;
    int i;

    solve_int(&integer_input);
    array = (int *)malloc(sizeof(int) * integer_input);
    for (i = 0; i < integer_input; ++i)
    {
        scanf("%d", &array[i]);
    }
    qsort(array, integer_input, sizeof(int), compare);
    solve_double(&double_input);

    if ((double)integer_input <= double_input)
    {
        max_value = double_input;
    }
    else
    {
        max_value = (double)integer_input;
    }
    printf("Max of integer and double: %.2lf\n", max_value);

    if (double_input <= (double)integer_input)
    {
        min_value = double_input;
    }
    else
    {
        min_value = (double)integer_input;
    }
    printf("Min of integer and double: %.2lf\n", min_value);

    free(array);
    return 0;
}
