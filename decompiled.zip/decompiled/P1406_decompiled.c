#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

int n;
int excel[10][10];
int num_sum;
int cnt;
bool used[101];
int num[101];

int sum_hang();
int sum_djs_2();
int sum_lie();
int sum_djs_1();
int cut_tree(int x);
bool can_put();
int compare(const void *a, const void *b);
void dfs(int x, int y);
int main();

int sum_hang()
{
    int j;
    int row_sum;
    int i;
    int total_sum;

    for (i = 1; i <= n; ++i)
    {
        row_sum = 0;
        for (j = 1; j <= n; ++j)
            row_sum += excel[i][j];
        if (i == 1)
        {
            total_sum = row_sum;
        }
        else if (total_sum != row_sum)
        {
            return 1000000000;
        }
    }
    return total_sum;
}
int sum_djs_2()
{
    int i;
    int sum;

    sum = 0;
    for (i = 1; i <= n; ++i)
        sum += excel[i][n + 1 - i];
    return sum;
}
int sum_lie()
{
    int j;
    int sum;
    int i;
    int all_sum;

    for ( i = 1; i <= n; ++i )
    {
        sum = 0;
        for ( j = 1; j <= n; ++j )
            sum += excel[j][i];
        if ( i == 1 )
        {
            all_sum = sum;
        }
        else if ( all_sum != sum )
        {
            return 100000000;
        }
    }
    return all_sum;
}
int sum_djs_1()
{
    int i;
    int sum;

    sum = 0;
    for (i = 1; i <= n; ++i)
        sum += excel[i][i];
    return sum;
}
int cut_tree(int x)
{
    int i;
    int all_sum;

    all_sum = 0;
    for (i = 1; i <= n; ++i)
        all_sum += excel[x][i];
    return all_sum;
}
bool can_put()
{
    int row_sum = sum_hang();
    int col_sum = sum_lie();
    int diag1_sum = sum_djs_1();
    int diag2_sum = sum_djs_2();

    if (row_sum == col_sum && row_sum == diag1_sum && row_sum == diag2_sum &&
        col_sum == diag1_sum && col_sum == diag2_sum &&
        diag1_sum == diag2_sum)
    {
        return true;
    }
    return false;
}
int compare(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;
    return value_a - value_b;
}
void dfs(int x, int y)
{
    int row_sum;
    int i;
    int j;
    int k;

    if (x <= 1 || y != 1 || cut_tree(x - 1) == num_sum / n)
    {
        if (x <= n)
        {
            if (!cnt)
            {
                for (k = 1; k <= n * n; ++k)
                {
                    if (!used[k])
                    {
                        excel[x][y] = num[k];
                        used[k] = 1;
                        if (y == n)
                        {
                            dfs(x + 1, 1);
                        }
                        else
                        {
                            dfs(x, y + 1);
                        }
                        used[k] = 0;
                    }
                }
            }
        }
        else if (can_put() && !cnt)
        {
            row_sum = sum_hang();
            printf("%d\n", row_sum);
            for (i = 1; i <= n; ++i)
            {
                for (j = 1; j <= n; ++j)
                {
                    printf("%d ", excel[i][j]);
                }
                putchar('\n');
            }
            ++cnt;
        }
    }
}
int main()
{
    int i;

    scanf("%d", &n);
    for (i = 1; i <= n * n; ++i)
    {
        scanf("%d", &num[i]);
        num_sum += num[i];
    }
    qsort(num + 1, n * n, sizeof(int), compare);
    dfs(1, 1);
    return 0;
}