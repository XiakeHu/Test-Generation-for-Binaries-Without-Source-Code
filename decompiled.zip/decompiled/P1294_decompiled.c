#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#define MAXN 1005
#define MAXM 2005
typedef struct {
    int nxt;
    int to;
    int w;
} node;
node e[MAXM];
int head[MAXN];
int cnt;
int vis[MAXN];
int ans;
int sum;
int n, m;
int read();
void add(int x, int y, int z);
void dfs(int x);
int main();
int read()
{
    char current_char;
    int sign = 1;
    int value = 0;
    current_char = getchar();
    while (!isdigit(current_char) && current_char != '-')
    {
        current_char = getchar();
    }
    if (current_char == '-')
    {
        sign = -1;
        current_char = getchar();
    }
    while (isdigit(current_char))
    {
        value = value * 10 + (current_char - '0');
        current_char = getchar();
    }
    return sign * value;
}
void add(int x, int y, int z)
{
    e[++cnt].nxt = head[x];
    e[cnt].to = y;
    e[cnt].w = z;
    head[x] = cnt;
}
void dfs(int x)
{
    int current_edge_index;
    int next_node;
    int edge_weight;
    int temp_max;
    for (current_edge_index = head[x]; current_edge_index != 0; current_edge_index = e[current_edge_index].nxt)
    {
        next_node = e[current_edge_index].to;
        if (!vis[next_node])
        {
            vis[next_node] = 1;
            edge_weight = e[current_edge_index].w;
            ans += edge_weight;
            temp_max = sum;
            if (ans >= sum)
            {
                temp_max = ans;
            }
            sum = temp_max;
            dfs(next_node);
            ans -= edge_weight;
            vis[next_node] = 0;
        }
    }
}
int main()
{
    int edge_weight;
    int node_y;
    int node_x;
    int node_index;
    cnt = 0;
    ans = 0;
    sum = 0;
    memset(head, 0, sizeof(head));
    memset(vis, 0, sizeof(vis));
    n = read();
    m = read();
    while ( m-- )
    {
        node_x = read();
        node_y = read();
        edge_weight = read();
        add(node_x, node_y, edge_weight);
        add(node_y, node_x, edge_weight);
    }
    for ( node_index = 1; node_index <= n; ++node_index )
    {
        vis[node_index] = 1;
        dfs(node_index);
        vis[node_index] = 0;
    }
    printf("%d\n", sum);
    return 0;
}