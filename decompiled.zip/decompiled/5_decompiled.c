#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int id;
    char date[20];
    char type[20];
    float amount;
    char category[30];
} Transaction;

Transaction transactions[100];
int transactionCount = 0;

void monthlyAnalysis();
void displayTransactions();
void inputFinancialData();
void spendingAnalysis();
void financialSummary();

void monthlyAnalysis()
{
    int monthCount;
    int i;
    int found;
    int j;
    int i_0;
    float monthAmount[100];
    char months[100][8];
    char month[8];

    puts("\n=== Monthly Analysis ===");
    memset(monthAmount, 0, sizeof(monthAmount));
    monthCount = 0;
    for (i = 0; i < transactionCount; ++i)
    {
        strncpy(month, transactions[i].date, 7);
        month[7] = 0;
        found = 0;
        for (j = 0; j < monthCount; ++j)
        {
            if (!strcmp(months[j], month))
            {
                monthAmount[j] = transactions[i].amount + monthAmount[j];
                found = 1;
                break;
            }
        }
        if (!found)
        {
            strcpy(months[monthCount], month);
            monthAmount[monthCount] = transactions[i].amount;
            monthCount++;
        }
    }
    for (i_0 = 0; i_0 < monthCount; ++i_0)
    {
        printf("%s: %.2f\n", months[i_0], monthAmount[i_0]);
    }
}

void displayTransactions() {
    int i;
    int i_0;
    
    puts("=== Transaction List ===");
    printf("%-4s %-12s %-8s %-12s %-10s\n", "ID", "Date", "Type", "Category", "Amount");
    for (i = 0; i <= 59; ++i)
        putchar(61);
    putchar(10);
    for (i_0 = 0; i_0 < transactionCount; ++i_0)
        printf("%-4d %-12s %-8s %-12s %-10.2f\n", 
               transactions[i_0].id,
               transactions[i_0].date,
               transactions[i_0].type,
               transactions[i_0].category,
               transactions[i_0].amount);
}

void inputFinancialData() {
    char line[200];

    puts("=== Input Financial Data ===");
    puts("Enter transactions in format: ID Date Type Amount Category");
    puts("Press Enter on empty line to finish");
    while (fgets(line, 200, stdin) && line[0] != 10) {
        if (transactionCount <= 99 && sscanf(line, "%d %s %s %f %s", &transactions[transactionCount].id, transactions[transactionCount].date, transactions[transactionCount].type, &transactions[transactionCount].amount, transactions[transactionCount].category) == 5) {
            ++transactionCount;
        }
    }
}

void spendingAnalysis()
{
    float totalSpend;
    int spendCount;
    int i;
    int found;
    int j;
    int i_0;
    float spendAmount[100];
    char spendCategories[100][30];

    puts("\n=== Spending Analysis ===");
    totalSpend = 0.0;
    memset(spendAmount, 0, sizeof(spendAmount));
    spendCount = 0;
    for (i = 0; i < transactionCount; ++i)
    {
        if (!strcmp(transactions[i].type, "Spending"))
        {
            totalSpend = transactions[i].amount + totalSpend;
            found = 0;
            for (j = 0; j < spendCount; ++j)
            {
                if (!strcmp(spendCategories[j], transactions[i].category))
                {
                    spendAmount[j] = transactions[i].amount + spendAmount[j];
                    found = 1;
                    break;
                }
            }
            if (!found)
            {
                strcpy(spendCategories[spendCount], transactions[i].category);
                spendAmount[spendCount++] = transactions[i].amount;
            }
        }
    }
    printf("Total Spending: %.2f\n", totalSpend);
    puts("Top Spending Categories:");
    for (i_0 = 0; i_0 < spendCount && i_0 < 3; ++i_0)
        printf("%s: %.2f (%.1f%%)\n", spendCategories[i_0], spendAmount[i_0], (100.0 * (spendAmount[i_0] / totalSpend)));
}

void financialSummary() {
    float totalIncome;
    float totalExpense;
    int i;
    int categoryCount;
    int i_0;
    int found;
    int j;
    int i_1;
    float categoryAmount[100];
    char categories[100][30];

    puts("\n=== Financial Summary ===");
    totalIncome = 0.0;
    totalExpense = 0.0;
    for (i = 0; i < transactionCount; ++i) {
        if (!strcmp(transactions[i].type, "Income")) {
            totalIncome = transactions[i].amount + totalIncome;
        } else if (!strcmp(transactions[i].type, "Spending")) {
            totalExpense = transactions[i].amount + totalExpense;
        }
    }
    printf("Total Income: %.2f\n", totalIncome);
    printf("Total Expense: %.2f\n", totalExpense);
    printf("Net Income: %.2f\n", totalIncome - totalExpense);
    memset(categoryAmount, 0, sizeof(categoryAmount));
    categoryCount = 0;
    for (i_0 = 0; i_0 < transactionCount; ++i_0) {
        found = 0;
        for (j = 0; j < categoryCount; ++j) {
            if (!strcmp(categories[j], transactions[i_0].category)) {
                categoryAmount[j] = transactions[i_0].amount + categoryAmount[j];
                found = 1;
                break;
            }
        }
        if (!found) {
            strcpy(categories[categoryCount], transactions[i_0].category);
            categoryAmount[categoryCount++] = transactions[i_0].amount;
        }
    }
    puts("\nCategory Breakdown:");
    for (i_1 = 0; i_1 < categoryCount; ++i_1) {
        printf("%s: %.2f\n", categories[i_1], categoryAmount[i_1]);
    }
}

int main() {
    puts("=== Personal Finance Manager ===");
    inputFinancialData();
    printf("\nLoaded %d transactions\n", transactionCount);
    displayTransactions();
    financialSummary();
    monthlyAnalysis();
    spendingAnalysis();
    puts("\n=== Program Ended ===");
    return 0;
}