#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n;
double x[1000];
double y[1000];
double x1, yu, x2, y2;
double the_max_num;

void sc(int q, int i1, int i2, int i3, int i4, int i5, int i6);
int main();

void sc(int q, int i1, int i2, int i3, int i4, int i5, int i6)
{
    double max_diffs[7] = {0.0};
    double current_diff;
    double sum = 0.0;
    const double pi = 3.141592653589793;

    for (int i = 1; i <= q; ++i)
    {
        if (i == i1)
        {
            current_diff = fabs(x[i] - x1);
            if (max_diffs[1] < current_diff)
                max_diffs[1] = current_diff;
        }
        else if (i == i2)
        {
            current_diff = fabs(y[i] - yu);
            if (max_diffs[2] < current_diff)
                max_diffs[2] = current_diff;
        }
        else if (i == i3)
        {
            current_diff = fabs(x[i] - x2);
            if (max_diffs[3] < current_diff)
                max_diffs[3] = current_diff;
        }
        else if (i == i4)
        {
            current_diff = fabs(y[i] - y2);
            if (max_diffs[4] < current_diff)
                max_diffs[4] = current_diff;
        }
        else if (i == i5)
        {
            current_diff = fabs(x[i] - x1);
            if (max_diffs[5] < current_diff)
                max_diffs[5] = current_diff;
        }
        else if (i == i6)
        {
            current_diff = fabs(y[i] - yu);
            if (max_diffs[6] < current_diff)
                max_diffs[6] = current_diff;
        }
    }

    for (int i = 1; i <= q; ++i)
    {
        sum += pow(max_diffs[i], 2.0) * pi;
    }

    if (the_max_num < sum)
        the_max_num = sum;
}
int main()
{
    int i;
    double area_diff;
    double temp_diff;

    scanf("%d", &n);
    scanf("%lf %lf %lf %lf", &x1, &yu, &x2, &y2);
    for (i = 1; i <= n; ++i)
        scanf("%lf %lf", &x[i], &y[i]);

    if (n == 1)
        sc(1, 1, 0, 0, 0, 0, 0);

    temp_diff = fabs(yu - y2) * fabs(x1 - x2) - the_max_num;
    area_diff = round(temp_diff);
    printf("%d", (int)area_diff);
    return 0;
}