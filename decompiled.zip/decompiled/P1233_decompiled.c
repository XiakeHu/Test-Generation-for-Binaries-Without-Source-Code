#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int l;
    int r;
} p;

p a[100005];
int used[100005];
int n, tot, times;

int cmp(const void *a, const void *b);
void handle();
int main();

int cmp(const void *a, const void *b)
{
    const p *p1 = (const p *)a;
    const p *p2 = (const p *)b;

    if (p1->l == p2->l)
        return p2->r - p1->r;
    else
        return p2->l - p1->l;
}
void handle()
{
    int i_outer;
    int found_unused;
    int i_inner;
    int current_idx;
    int i;

    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
    {
        ++tot;
        scanf("%d %d", &a[tot].l, &a[tot].r);
    }
    current_idx = 1;
    qsort(&a[1], n, sizeof(p), cmp);
    do
    {
        ++times;
        for (i_inner = 1; i_inner <= n; ++i_inner)
        {
            used[current_idx] = 1;
            if (a[i_inner].l <= a[current_idx].l && a[i_inner].r <= a[current_idx].r && !used[i_inner])
            {
                used[i_inner] = 1;
                current_idx = i_inner;
            }
        }
        found_unused = 0;
        for (i_outer = 1; i_outer <= n; ++i_outer)
        {
            if (!used[i_outer])
            {
                if (!found_unused)
                    current_idx = i_outer;
                found_unused = 1;
            }
        }
    } while (found_unused);
    printf("%d", times);
}
int main()
{
    handle();
    return 0;
}