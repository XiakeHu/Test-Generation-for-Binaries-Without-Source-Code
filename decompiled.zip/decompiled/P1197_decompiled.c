#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int v;
    int nxt;
} edge;

edge e[200005];
int h[100005];
int p;
int vis[100005];
int not_alive[100005];

void add(int a, int b);
int main();
void dfs(int x);

void add(int a, int b)
{
    int new_edge_index = ++p;
    e[new_edge_index].nxt = h[a];
    h[a] = new_edge_index;
    e[new_edge_index].v = b;
}

int main()
{
    int node_count;
    int edge_count;
    int node_a;
    int node_b;
    int i;

    scanf("%d %d", &node_count, &edge_count);
    for (i = 1; i <= edge_count; ++i)
    {
        scanf("%d %d", &node_a, &node_b);
        add(node_a, node_b);
        add(node_b, node_a);
    }
    return 0;
}

void dfs(int x)
{
    int current_edge_index;

    if ( !vis[x] || not_alive[x] )
    {
        vis[x] = 1;
        for ( current_edge_index = h[x]; current_edge_index; current_edge_index = e[current_edge_index].nxt )
        {
            if ( !vis[e[current_edge_index].v] && !not_alive[e[current_edge_index].v] )
                dfs(e[current_edge_index].v);
        }
    }
}