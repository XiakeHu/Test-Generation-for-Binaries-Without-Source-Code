#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    char name[50];
    float price;
    int quantity;
    char category[30];
} Product;

Product inventory[100];
int itemCount = 0;

void categoryAnalysis();
void inputProducts();
void stockRecommendations();
void priceAnalysis();
void displayInventory();

void categoryAnalysis()
{
    int categoryCount;
    int i;
    int found;
    int j;
    float totalValue;
    int i_0;
    int i_1;
    float categoryValue[100];
    char categories[100][30];

    puts("=== 分类分析 ===");
    memset(categoryValue, 0, sizeof(categoryValue));
    categoryCount = 0;
    for (i = 0; i < itemCount; ++i)
    {
        found = 0;
        for (j = 0; j < categoryCount; ++j)
        {
            if (!strcmp(categories[j], inventory[i].category))
            {
                categoryValue[j] = (float)((float)inventory[i].quantity * inventory[i].price) + categoryValue[j];
                found = 1;
                break;
            }
        }
        if (!found)
        {
            strcpy(categories[categoryCount], inventory[i].category);
            categoryValue[categoryCount++] = (float)inventory[i].quantity * inventory[i].price;
        }
    }
    printf("%-15s %-12s %-10s\n", "分类", "总价值", "占比");
    puts("=================================");
    totalValue = 0.0;
    for (i_0 = 0; i_0 < categoryCount; ++i_0)
        totalValue = categoryValue[i_0] + totalValue;
    for (i_1 = 0; i_1 < categoryCount; ++i_1)
        printf(
            "%-15s %-12.2f %-10.1f%%\n",
            categories[i_1],
            categoryValue[i_1],
            (float)(100.0 * (float)(categoryValue[i_1] / totalValue)));
}

void inputProducts() {
    char line[200];
    
    puts("=== 商品输入 ===");
    puts("请输入商品信息：名称 价格 数量 分类");
    puts("输入空行结束");
    while (fgets(line, 200, stdin) && line[0] != '\n') {
        if (itemCount <= 99 && sscanf(line, "%s %f %d %s", inventory[itemCount].name, &inventory[itemCount].price, &inventory[itemCount].quantity, inventory[itemCount].category) == 4) {
            itemCount++;
        }
    }
}

void stockRecommendations() {
    int needsRestock;
    int i;

    puts("\n=== 库存建议 ===");
    needsRestock = 0;
    for (i = 0; i < itemCount; ++i) {
        if (inventory[i].quantity <= 4) {
            printf("需要补货: %s (当前库存: %d)\n", inventory[i].name, inventory[i].quantity);
            ++needsRestock;
        }
    }
    if (!needsRestock) {
        puts("所有商品库存充足");
    }
}

void priceAnalysis()
{
    float maxPrice;
    float minPrice;
    float totalValue;
    unsigned int lowStock;
    int i;

    puts("\n=== 价格分析 ===");
    maxPrice = 0.0;
    minPrice = 1000000000.0;
    totalValue = 0.0;
    lowStock = 0;
    for (i = 0; i < itemCount; ++i) {
        if (inventory[i].price > maxPrice)
            maxPrice = inventory[i].price;
        if (minPrice > inventory[i].price)
            minPrice = inventory[i].price;
        totalValue = (float)((float)inventory[i].quantity * inventory[i].price) + totalValue;
        if (inventory[i].quantity <= 9)
            ++lowStock;
    }
    printf("最高价格: %.2f\n", maxPrice);
    printf("最低价格: %.2f\n", minPrice);
    printf("平均价值: %.2f\n", (float)(totalValue / (float)itemCount));
    printf("低库存商品数量: %d\n", lowStock);
}

void displayInventory() {
    float totalValue;
    int i;
    float value;

    puts("=== 库存显示 ===");
    printf("%-20s %-10s %-8s %-15s %-12s\n", "名称", "价格", "数量", "分类", "总价值");
    puts("======================================================");
    totalValue = 0.0;
    for (i = 0; i < itemCount; ++i) {
        value = (float)inventory[i].quantity * inventory[i].price;
        printf("%-20s %-10.2f %-8d %-15s %-12.2f\n", inventory[i].name, inventory[i].price, inventory[i].quantity, inventory[i].category, value);
        totalValue = totalValue + value;
    }
    printf("库存总价值: %.2f\n", totalValue);
}

int main() {
    puts("=== 库存管理系统 ===");
    inputProducts();
    printf("\n已输入 %d 个商品\n", itemCount);
    displayInventory();
    categoryAnalysis();
    priceAnalysis();
    stockRecommendations();
    puts("\n");
    return 0;
}