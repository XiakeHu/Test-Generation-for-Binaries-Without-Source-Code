#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int x;
    int y;
} location;

typedef location Location;

void destroy_location(Location *loc) ;
Location* create_location(int xx, int yy) ;
int main(int argc, const char **argv, const char **envp) ;

void destroy_location(Location *loc)
{
    free(loc);
}
Location* create_location(int xx, int yy)
{
    Location* new_location = (Location*)malloc(sizeof(Location));
    new_location->x = xx;
    new_location->y = yy;
    return new_location;
}
int main(int argc, const char **argv, const char **envp)
{
    int rows, cols;
    int current_layer_count;
    int current_nodes_in_layer;
    int queue_front, queue_rear;
    int start_row, start_col;
    int current_row, current_col;
    int i, j;
    int ii, jj;
    Location *current_location;
    Location **queue_nodes;
    int answer = 0;
    int **mount;

    scanf("%d %d", &rows, &cols);
    mount = (int**)malloc(sizeof(int*) * rows);
    for (i = 0; i < rows; ++i)
    {
        mount[i] = (int*)malloc(sizeof(int) * cols);
        for (j = 0; j < cols; ++j)
        {
            scanf("%d", &mount[i][j]);
        }
    }

    for (ii = 0; ii < rows; ++ii)
    {
        for (jj = 0; jj < cols; ++jj)
        {
            if ((ii + 1 >= rows || mount[ii + 1][jj] <= mount[ii][jj]) &&
                (ii <= 0 || mount[ii - 1][jj] <= mount[ii][jj]) &&
                (jj + 1 >= cols || mount[ii][jj + 1] <= mount[ii][jj]) &&
                (jj <= 0 || mount[ii][jj - 1] <= mount[ii][jj]))
            {
                current_nodes_in_layer = 0;
                current_layer_count = 0;
                queue_nodes = (Location **)malloc(sizeof(Location *) * rows * cols);
                queue_front = 0;
                queue_rear = 0;

                queue_nodes[queue_rear++] = create_location(ii, jj);

                while (queue_front < queue_rear)
                {
                    if (current_nodes_in_layer == 0)
                    {
                        ++current_layer_count;
                        current_nodes_in_layer = queue_rear - queue_front;
                    }

                    current_location = queue_nodes[queue_front++];
                    current_row = current_location->x;
                    current_col = current_location->y;

                    if (current_row + 1 < rows && mount[current_row + 1][current_col] < mount[current_row][current_col])
                    {
                        queue_nodes[queue_rear++] = create_location(current_row + 1, current_col);
                    }
                    if (current_row > 0 && mount[current_row - 1][current_col] < mount[current_row][current_col])
                    {
                        queue_nodes[queue_rear++] = create_location(current_row - 1, current_col);
                    }
                    if (current_col + 1 < cols && mount[current_row][current_col + 1] < mount[current_row][current_col])
                    {
                        queue_nodes[queue_rear++] = create_location(current_row, current_col + 1);
                    }
                    if (current_col > 0 && mount[current_row][current_col - 1] < mount[current_row][current_col])
                    {
                        queue_nodes[queue_rear++] = create_location(current_row, current_col - 1);
                    }

                    destroy_location(current_location);
                    --current_nodes_in_layer;
                }
                free(queue_nodes);
                if (answer < current_layer_count)
                {
                    answer = current_layer_count;
                }
            }
        }
    }

    for (i = 0; i < rows; ++i) {
        free(mount[i]);
    }
    free(mount);
    printf("%d", answer);
    return 0;
}