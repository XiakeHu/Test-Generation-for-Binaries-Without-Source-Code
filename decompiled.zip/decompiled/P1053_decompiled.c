#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n;
int expect_person[1005][2];
int target_list[1005];
int initial_list[1005];
int plus_order[1005];
int minus_order[1005];
int ans;
int T;

void solve(int step);
int main(int argc, const char **argv, const char **envp);

void solve(int step)
{
    int i;
    int j;
    int k;
    int l;
    int m;
    int diff1;
    int diff2;

    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
        scanf("%d%d", &expect_person[i][0], &expect_person[i][1]);

    target_list[1] = 1;
    target_list[2] = expect_person[1][1];

    for (j = 2; j < n; ++j)
    {
        if (target_list[j - 1] == expect_person[target_list[j]][0])
        {
            target_list[j + 1] = expect_person[target_list[j]][1];
        }
        else
        {
            if (target_list[j - 1] != expect_person[target_list[j]][1])
            {
                printf("-1");
                return;
            }
            target_list[j + 1] = expect_person[target_list[j]][0];
        }
    }

    for (k = 1; k <= n; ++k)
        initial_list[k] = k;

    for (l = 1; l <= n; ++l)
    {
        diff1 = (target_list[l] - initial_list[l] + n) % n;
        ++plus_order[diff1];

        diff2 = (target_list[l] - initial_list[n - l + 1] + n) % n;
        ++minus_order[diff2];
    }

    ans = 0;
    for (m = 0; m < n; ++m)
    {
        if (plus_order[m] > ans)
            ans = plus_order[m];
        if (minus_order[m] > ans)
            ans = minus_order[m];
    }

    printf("%d", n - ans);
}
int main(int argc, const char **argv, const char **envp)
{
    int iteration_counter;
    scanf("%d", &T);
    for (iteration_counter = 0; iteration_counter < T; ++iteration_counter)
        solve(iteration_counter);
    return 0;
}