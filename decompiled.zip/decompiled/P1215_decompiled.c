#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int a, b, c;
int n[15626];
int ans[200];
int cc;

int compare(const void *a, const void *b) ;
void find(int x, int y, int z) ;
int main() ;
int compare(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;
    return value_a - value_b;
}
void find(int x, int y, int z)
{
    int index = 625 * x + 25 * y + z;
    if (!n[index])
    {
        n[index] = 1;
        if (x == 0)
        {
            ans[cc] = z;
            ++cc;
        }
        if (x < b - y)
        {
            find(0, y + x, z);
        }
        else
        {
            find(x - (b - y), b, z);
        }
        if (x < c - z)
        {
            find(0, y, x + z);
        }
        else
        {
            find(x - (c - z), y, c);
        }
        if (y < a - x)
        {
            find(x + y, 0, z);
        }
        else
        {
            find(a, y - (a - x), z);
        }
        if (y < c - z)
        {
            find(x, 0, y + z);
        }
        else
        {
            find(x, y - (c - z), c);
        }
        if (z < a - x)
        {
            find(x + z, y, 0);
        }
        else
        {
            find(a, y, z - (a - x));
        }
        if (z < b - y)
        {
            find(x, y + z, 0);
        }
        else
        {
            find(x, b, z - (b - y));
        }
    }
}
int main()
{
    int i;
    cc = 0;
    scanf("%d %d %d", &a, &b, &c);
    find(0, 0, c);
    qsort(ans, cc, sizeof(int), compare);
    for (i = 0; i < cc; ++i)
        printf("%d ", ans[i]);
    putchar('\n');
    return 0;
}