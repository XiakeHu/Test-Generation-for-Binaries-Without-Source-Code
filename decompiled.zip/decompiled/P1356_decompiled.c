#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int main(int argc, const char **argv, const char **envp) ;
int main(int argc, const char **argv, const char **envp)
{
    int nn, n, k, e, tmp;
    int inner_loop_j;
    int outer_loop_j;
    int inner_loop_i;
    int outer_loop_i;
    int f[1005];
    int opt[1005][2];

    scanf("%d", &nn);
    for (outer_loop_i = 1; outer_loop_i <= nn; ++outer_loop_i)
    {
        memset(f, -1, sizeof(f));
        scanf("%d %d", &n, &k);
        f[0] = 0;
        for (inner_loop_i = 1; inner_loop_i <= n; ++inner_loop_i)
        {
            scanf("%d", &tmp);
            tmp = (tmp % k + k) % k;
            e = 0;
            for (outer_loop_j = k - 1; outer_loop_j >= 0; --outer_loop_j)
            {
                if (f[outer_loop_j] == inner_loop_i - 1)
                {
                    opt[++e][0] = f[outer_loop_j];
                    opt[e][1] = outer_loop_j;
                }
            }
            for (inner_loop_j = e; inner_loop_j > 0; --inner_loop_j)
            {
                f[(opt[inner_loop_j][1] + tmp) % k] = opt[inner_loop_j][0] + 1;
                f[(opt[inner_loop_j][1] - tmp + k) % k] = opt[inner_loop_j][0] + 1;
            }
        }
        if (f[0] == n)
            puts("Divisible");
        else
            puts("Not divisible");
    }
    return 0;
}