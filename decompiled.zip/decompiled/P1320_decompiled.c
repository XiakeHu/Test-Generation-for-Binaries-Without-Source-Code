#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

 int main(int argc, const char **argv, const char **envp) ;
int main(int argc, const char **argv, const char **envp)
{
    char input_string[100];
    char concatenated_string[200005];
    char temp_buffer[112];
    int outer_loop_index;
    int run_length_count;
    int inner_loop_index;

    concatenated_string[0] = '\0';
    scanf("%s", input_string);
    strcat(concatenated_string, input_string);

    for (outer_loop_index = 1; ; ++outer_loop_index)
    {
        if ((size_t)outer_loop_index >= strlen(input_string))
            break;
        scanf("%s", temp_buffer);
        strcat(concatenated_string, temp_buffer);
    }

    printf("%lu ", strlen(input_string));

    run_length_count = 1;
    if (concatenated_string[0] == '1')
        printf("0 ");

    for (inner_loop_index = 1; ; ++inner_loop_index)
    {
        if ((size_t)inner_loop_index >= strlen(concatenated_string))
            break;
        if (concatenated_string[inner_loop_index - 1] == concatenated_string[inner_loop_index])
        {
            ++run_length_count;
        }
        else
        {
            printf("%d ", run_length_count);
            run_length_count = 1;
        }
    }
    printf("%d", run_length_count);
    return 0;
}
