#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct Node {
    int v;
    int w;
} Node;

int W;
int n;
Node a[1005];
int ans;

int cmp(const void *a, const void *b);
int get(int x);

int cmp(const void *a, const void *b)
{
    const Node *nodeA = (const Node *)a;
    const Node *nodeB = (const Node *)b;
    
    double leftValue = (double)nodeB->w * (double)nodeA->v;
    double rightValue = (double)nodeA->w * (double)nodeB->v;
    
    return leftValue > rightValue;
}
int get(int x)
{
    int random_value = rand() % 100;
    return x > random_value;
}
int main() {
    unsigned int seed;
    int outer_loop_counter;
    int g_value;
    int current_result;
    int remaining_weight;
    int inner_loop_counter;

    seed = (unsigned int)time(NULL);
    srand(seed);
    scanf("%d%d", &W, &n);
    for (inner_loop_counter = 1; inner_loop_counter <= n; ++inner_loop_counter) {
        scanf("%d%d", &a[inner_loop_counter].v, &a[inner_loop_counter].w);
        if (a[inner_loop_counter].w > W) {
            --inner_loop_counter;
            --n;
        }
    }
    qsort(&a[1], n, sizeof(Node), cmp);
    while ((double)clock() / 1000000.0 < 0.004) {
        remaining_weight = W;
        current_result = 0;
        g_value = 97;
        for (outer_loop_counter = 1; outer_loop_counter <= n; ++outer_loop_counter) {
            if (remaining_weight >= a[outer_loop_counter].w) {
                if (get(g_value)) {
                    remaining_weight -= a[outer_loop_counter].w;
                    current_result += a[outer_loop_counter].v;
                }
                g_value -= get(20);
            }
        }
        ans = (int)fmax((double)ans, (double)current_result);
    }
    printf("%d", ans);
    return 0;
}