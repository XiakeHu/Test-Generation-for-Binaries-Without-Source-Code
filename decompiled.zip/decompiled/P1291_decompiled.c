#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int64_t gcd(int64_t a, int64_t b);
int64_t num(int64_t x);
void write(int64_t x);
void w(int64_t x);
int64_t read();

int64_t gcd(int64_t a, int64_t b)
{
    if (b != 0)
    {
        return gcd(b, a % b);
    }
    else
    {
        return a;
    }
}

int64_t num(int64_t x)
{
    int64_t digit_count = 0;

    while (x != 0)
    {
        ++digit_count;
        x /= 10;
    }

    return digit_count;
}

void write(int64_t x)
{
    int64_t absolute_value = x;
    
    if (x < 0)
    {
        putchar('-');
        absolute_value = -x;
    }
    
    if (absolute_value > 9)
    {
        write(absolute_value / 10);
    }
    
    putchar((absolute_value % 10) + '0');
}

void w(int64_t x)
{
    write(x);
    putchar('\n');
}

int64_t read()
{
    char current_char;
    int64_t sign_factor;
    int64_t accumulated_value;

    accumulated_value = 0LL;
    sign_factor = 1LL;
    for ( current_char = getchar(); current_char <= 47 || current_char > 57; current_char = getchar() )
    {
        if ( current_char == 45 )
            sign_factor = -1LL;
    }
    while ( current_char > 47 && current_char <= 57 )
    {
        accumulated_value = 10 * accumulated_value + current_char - 48;
        current_char = getchar();
    }
    return sign_factor * accumulated_value;
}

int main()
{
    int64_t n = read();
    int64_t a = 0, b = 1, ans = 0, u;
    int64_t i, i_0, i_1, i_2, i_3;
    int64_t wi, wi1, wi2;

    for (i = n; i > 0; --i)
    {
        b *= i;
        a = i * a + n * b / i;
        u = gcd(a, b);
        a /= u;
        b /= u;
        ans += a / b;
        a %= b;
    }

    if (a)
    {
        if (ans)
        {
            wi1 = num(ans);
            wi2 = num(b);
            for (i_1 = 1; i_1 <= wi1; ++i_1)
                putchar(' ');
            w(a);
            write(ans);
            for (i_2 = 1; i_2 <= wi2; ++i_2)
                putchar('-');
            putchar('\n');
            for (i_3 = 1; i_3 <= wi1; ++i_3)
                putchar(' ');
            write(b);
        }
        else
        {
            wi = num(b);
            w(a);
            for (i_0 = 1; i_0 <= wi; ++i_0)
                putchar('-');
            putchar('\n');
            write(b);
        }
    }
    else
    {
        write(ans);
    }

    return 0;
}