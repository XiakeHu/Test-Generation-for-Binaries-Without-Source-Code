#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int first;
    int second;
}Pair;

int compare(const void *a, const void *b) ;
   int compare(const void *a, const void *b) ;
int compare(const void *a, const void *b)
{
    int first_value = *(const int *)a;
    int second_value = *(const int *)b;
    return first_value - second_value;
}
int main() {
    int n;
    Pair *array;
    int i, j;
    double sum = 0.0;

    scanf("%d", &n);
    array = (Pair *)malloc(sizeof(Pair) * n);

    for (i = 0; i < n; ++i) {
        scanf("%d", &array[i].first);
        array[i].second = i + 1;
    }

    qsort(array, n, sizeof(Pair), compare);

    for (j = 0; j < n; ++j) {
        sum += (double)(array[j].first * (n - j - 1));
        printf("%d ", array[j].second);
    }

    printf("%.2f", sum / (double)n);
    free(array);
    return 0;
}
