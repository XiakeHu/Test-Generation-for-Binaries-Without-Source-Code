#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n;
int arr[1000];
int len[1000];
long long p[1000];
int maxlen;
long long maxp;

void mydp();
void input();
void output();
int main();

void mydp()
{
    int outer_i;
    int inner_j;
    int inner_j_0;
    int i_0;

    for (outer_i = 0; outer_i < n; ++outer_i)
    {
        for (inner_j = 0; inner_j < outer_i; ++inner_j)
        {
            if (arr[outer_i] < arr[inner_j])
            {
                int candidate_len = len[inner_j] + 1;
                if (candidate_len > len[outer_i])
                {
                    len[outer_i] = candidate_len;
                }
            }
        }
        if (len[outer_i] > maxlen)
        {
            maxlen = len[outer_i];
        }
        for (inner_j_0 = 0; inner_j_0 < outer_i; ++inner_j_0)
        {
            if (arr[outer_i] == arr[inner_j_0] && len[outer_i] == len[inner_j_0])
            {
                p[inner_j_0] = 0;
            }
            else if (len[outer_i] == len[inner_j_0] + 1 && arr[outer_i] < arr[inner_j_0])
            {
                p[outer_i] += p[inner_j_0];
            }
        }
        if (p[outer_i] == 0)
        {
            p[outer_i] = 1;
        }
    }
    for (i_0 = maxlen - 1; i_0 < n; ++i_0)
    {
        if (len[i_0] == maxlen)
        {
            maxp += p[i_0];
        }
    }
}
void input()
{
    int i;
    scanf("%d", &n);
    for (i = 0; i < n; ++i)
    {
        scanf("%d", &arr[i]);
        len[i] = 1;
        p[i] = 0;
    }
    maxlen = 0;
    maxp = 0;
}
void output()
{
    printf("%d %lld\n", maxlen, maxp);
}
int main()
{
    input();
    mydp();
    output();
    return 0;
}