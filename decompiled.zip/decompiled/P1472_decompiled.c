#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

long long fac[205];
long long inv[205];
long long c[205][205];
long long dp[205][205][205];
int n, k;

int my_pow(int y, int x) ;
void init() ;
int read() ;
int main() ;
int my_pow(int y, int x)
{
    long long res = 1LL;
    int base = y;
    int exponent = x;

    while (exponent)
    {
        if ((exponent & 1) != 0)
            res = res * base % 9901;
        base = (long long)base * base % 9901;
        exponent >>= 1;
    }
    return (int)res;
}
void init()
{
    int j;
    int i_1;
    int i_0;
    int i;

    fac[0] = 1;
    for (i = 1; i <= 200; ++i)
        fac[i] = fac[i - 1] * (long long)i % 9901;
    inv[200] = my_pow(fac[200], 9899);
    for (i_0 = 200; i_0 > 0; --i_0)
        inv[i_0 - 1] = inv[i_0] * (long long)i_0 % 9901;
    for (i_1 = 1; i_1 <= 200; ++i_1)
    {
        for (j = i_1; j <= 200; ++j)
            c[i_1][j] = fac[j] * (long long)inv[i_1] % 9901 * inv[j - i_1] % 9901;
    }
}
int read()
{
    char current_char;
    char next_char;
    int result_value;

    do
    {
        do
        {
            current_char = getchar();
        } while (current_char > '9');
    } while (current_char <= '/');

    result_value = current_char - '0';

    while (1)
    {
        next_char = getchar();
        if (next_char <= '/' || next_char > '9')
            break;
        result_value = 10 * result_value + next_char - '0';
    }

    return result_value;
}
int main()
{
    int i_even;
    int answer;
    int v;
    int j;
    int i;
    int u;

    init();
    n = read();
    k = read();
    dp[1][1][1] = 1;
    dp[2][3][2] = 1;
    for (u = 2; u < k; ++u)
    {
        for (i = 2; i < n; i += 2)
        {
            for (j = 2 * u - 1; j < n; j += 2)
            {
                if (dp[u][j][i])
                {
                    for (v = 2; v <= 2 * i && v + j <= n; v += 2)
                        dp[u + 1][j + v][v] = (dp[u + 1][j + v][v] + dp[u][j][i] * (long long)c[v / 2][i] % 9901) % 9901;
                }
            }
        }
    }
    answer = 0;
    for (i_even = 2; i_even <= 200; i_even += 2)
    {
        if (dp[k][n][i_even])
            answer = (answer + (long long)dp[k][n][i_even]) % 9901;
    }
    printf("%d", answer);
    return 0;
}