#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int val;
}Pair;

int n, m;
int a[220];
Pair dp1[110][220][15];
Pair dp2[110][220][15];
int ans1 = 1000000000;
int ans2 = -1000000000;

void initDP();
void solve();
int main();

void initDP()
{
    for (int i = 0; i <= 109; ++i)
    {
        for (int j = 0; j <= 109; ++j)
        {
            for (int k = 0; k <= 14; ++k)
            {
                dp1[i][j][k].val = 1000000000;
                dp2[i][j][k].val = -1000000000;
            }
        }
    }
}
void solve() {
    int left, i_outer, j, q, k, right, len, i_mid, i;

    initDP();
    scanf("%d %d", &n, &m);
    for (i = 1; i <= n; ++i) {
        scanf("%d", &a[i]);
        dp2[0][i + 110][1].val = (a[i] + 100000) % 10;
        dp1[0][i + 110][1].val = dp2[0][i + 110][1].val;
    }
    for (i_mid = n + 1; i_mid < 2 * n; ++i_mid) {
        a[i_mid] = a[i_mid - n];
        dp2[0][i_mid + 110][1].val = (a[i_mid] + 100000) % 10;
        dp1[0][i_mid + 110][1].val = dp2[0][i_mid + 110][1].val;
    }
    for (len = 1; len < 2 * n; ++len) {
        for (right = len; right < 2 * n; ++right) {
            left = right - len + 1;
            for (k = left + 1; k <= right; ++k) {
                int temp_sum1 = (dp1[left - 1][k + 109][1].val + dp1[k][right][1].val + 100000) % 10;
                if (temp_sum1 < dp1[left][right][1].val) dp1[left][right][1].val = temp_sum1;
                int temp_sum2 = (dp2[left - 1][k + 109][1].val + dp2[k][right][1].val + 100000) % 10;
                if (temp_sum2 > dp2[left][right][1].val) dp2[left][right][1].val = temp_sum2;
                for (q = 2; q <= m; ++q) {
                    for (j = 1; j < q; ++j) {
                        if (dp1[left - 1][k + 109][j].val <= 999999999 && dp1[k][right][q - j].val <= 999999999) {
                            int temp_product1 = dp1[left - 1][k + 109][j].val * dp1[k][right][q - j].val;
                            if (temp_product1 < dp1[left][right][q].val) dp1[left][right][q].val = temp_product1;
                        }
                        if (dp2[left - 1][k + 109][j].val >= -999999999 && dp2[k][right][q - j].val >= -999999999) {
                            int temp_product2 = dp2[left - 1][k + 109][j].val * dp2[k][right][q - j].val;
                            if (temp_product2 > dp2[left][right][q].val) dp2[left][right][q].val = temp_product2;
                        }
                    }
                }
            }
        }
    }
    for (i_outer = 1; i_outer <= n; ++i_outer) {
        int end_index = i_outer + n - 1;
        if (dp1[i_outer - 1][end_index + 110][m].val < ans1) ans1 = dp1[i_outer - 1][end_index + 110][m].val;
        if (dp2[i_outer - 1][end_index + 110][m].val > ans2) ans2 = dp2[i_outer - 1][end_index + 110][m].val;
    }
    printf("%d\n%d", ans1, ans2);
}
int main()
{
    solve();
    return 0;
}