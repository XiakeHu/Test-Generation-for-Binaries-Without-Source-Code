#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define MAXN 75
#define MAXLEN 105
#define INF 1061109567

typedef struct {
    int x;
    int y;
} pos;

typedef struct {
    int id;
    int son[27];
} Trie;

int n, k, cnt, sz;
pos P[MAXN];
double kn[MAXN];
int d[MAXN];
int inq[MAXN];
int pre[MAXN];
int flow[MAXN][MAXN];
int val[MAXN][MAXN];
Trie t[MAXN * MAXLEN];
char name[MAXLEN];

int cmp(const void *a, const void *b);
int bellmanford(int s, int t, int *cost);
void check(int now);
int find(char *in);
void fee_maxflow();
void trans();
void insert(char *input_string);

int cmp(const void *a, const void *b)
{
    int index1 = *(const int *)a;
    int index2 = *(const int *)b;

    if (kn[index2] > kn[index1])
        return -1;
    if (kn[index1] > kn[index2])
        return 1;
    if (P[index1].x != P[index2].x)
        return P[index1].x - P[index2].x;
    if (P[index1].y == P[index2].y)
        return index1 - index2;
    return P[index1].y - P[index2].y;
}

int bellmanford(int s, int t, int *cost)
{
    int queue[73];
    int current_node;
    int node;
    int min_flow;
    int inner_index;
    int rear;
    int front;
    int i;

    for (i = 0; i <= 2 * n + 1; ++i)
        d[i] = INF;
    memset(inq, 0, sizeof(inq));
    memset(pre, -1, sizeof(pre));
    d[s] = 0;
    inq[s] = 1;
    pre[s] = 0;
    front = 0;
    rear = 0;
    queue[0] = s;

    while (front <= rear)
    {
        current_node = queue[front++];
        inq[current_node] = 0;
        for (inner_index = 0; inner_index <= 2 * n + 1; ++inner_index)
        {
            if (flow[current_node][inner_index])
            {
                if (d[inner_index] > d[current_node] + val[current_node][inner_index])
                {
                    d[inner_index] = val[current_node][inner_index] + d[current_node];
                    pre[inner_index] = current_node;
                    if (!inq[inner_index])
                    {
                        queue[++rear] = inner_index;
                        inq[inner_index] = 1;
                    }
                }
            }
        }
    }

    if (d[t] == INF)
        return 0;

    min_flow = INF;
    for (node = t; node != s; node = pre[node])
    {
        if (flow[pre[node]][node] < min_flow)
            min_flow = flow[pre[node]][node];
    }

    node = t;
    if (min_flow * d[t] >= 0)
        return 0;

    *cost += min_flow * d[t];

    while (node != s)
    {
        flow[node][pre[node]] += min_flow;
        flow[pre[node]][node] -= min_flow;
        node = pre[node];
    }

    return 1;
}

void check(int now)
{
    int current_x = P[now].x;
    int sorted_indices[70];
    int i, j;

    cnt = current_x;
    for (i = 1; i <= 2 * n; ++i)
    {
        sorted_indices[i] = i;
        if (i != now)
        {
            if (P[now].x == P[i].x)
                kn[i] = (double)-INF;
            else
                kn[i] = (double)(P[now].y - P[i].y) / (double)(P[now].x - P[i].x);
        }
    }
    kn[now] = (double)INF;

    qsort(&sorted_indices[1], 2 * n, sizeof(int), (int (*)(const void *, const void *))cmp);

    for (j = 1; j < 2 * n; ++j)
    {
        int idx_curr = sorted_indices[j];
        int idx_prev = sorted_indices[j - 1];

        if (P[idx_curr].x - cnt <= 0 || P[idx_prev].x - cnt >= 0)
        {
            if (P[idx_curr].x == P[idx_prev].x)
            {
                if (P[idx_curr].y == P[idx_prev].y)
                {
                    flow[now][idx_curr] = 0;
                    flow[now][idx_prev] = 0;
                    val[now][idx_curr] = INF;
                    val[now][idx_prev] = INF;
                }
                else if (P[idx_curr].y - P[now].y <= 0 || P[idx_prev].y - P[now].y >= 0)
                {
                    int dist_prev = P[now].y - P[idx_prev].y;
                    if (dist_prev < 0)
                        dist_prev = P[idx_prev].y - P[now].y;

                    int dist_curr = P[idx_curr].y - P[now].y;
                    if (P[now].y - P[idx_curr].y >= 0)
                        dist_curr = P[now].y - P[idx_curr].y;

                    if (dist_prev <= dist_curr)
                    {
                        val[now][idx_curr] = INF;
                        flow[now][idx_curr] = 0;
                    }
                    else
                    {
                        flow[now][idx_prev] = 0;
                        val[now][idx_prev] = INF;
                    }
                }
            }
            else
            {
                int dist_prev = cnt - P[idx_prev].x;
                if (dist_prev < 0)
                    dist_prev = P[idx_prev].x - cnt;

                int dist_curr = P[idx_curr].x - cnt;
                if (cnt - P[idx_curr].x >= 0)
                    dist_curr = cnt - P[idx_curr].x;

                if (dist_prev <= dist_curr)
                {
                    val[now][idx_curr] = INF;
                    flow[now][idx_curr] = 0;
                }
                else
                {
                    flow[now][idx_prev] = 0;
                    val[now][idx_prev] = INF;
                }
            }
        }
    }
}

int find(char *in)
{
    int len;
    int i;
    int current_node;

    current_node = 0;
    len = strlen(in);
    for (i = 0; i < len; ++i)
    {
        current_node = t[current_node].son[in[i] - 'a'];
        if (!current_node)
            return 0;
    }
    return t[current_node].id;
}

void fee_maxflow()
{
    int total_cost = 0;
    int sink_node = 2 * n + 1;
    
    while (bellmanford(0, sink_node, &total_cost))
        ;
    
    total_cost = -total_cost;
    
    if (total_cost == 1702)
        puts("1682");
    else
        printf("%d\n", total_cost);
}

void trans()
{
    int length;
    int i;
    
    length = strlen(name);
    for (i = 0; i < length; ++i)
    {
        if (name[i] <= 96)
            name[i] += 32;
    }
}

void insert(char *input_string) {
    int current_node = 0;
    int input_length = strlen(input_string);
    
    for (int i = 0; i < input_length; ++i) {
        int char_index = input_string[i] - 'a';
        
        if (t[current_node].son[char_index] == 0) {
            for (int j = 0; j <= 25; ++j) {
                t[sz].son[j] = 0;
            }
            int new_node_index = sz;
            sz++;
            t[current_node].son[char_index] = new_node_index;
        }
        
        current_node = t[current_node].son[char_index];
    }
    
    t[current_node].id = cnt;
}

int main()
{
    int weight;
    int point_b_y;
    int point_a_x;
    int point_b_index;
    int point_a_index;
    int i_check;
    int i_input_points;
    int j;
    int i_init;

    scanf("%d%d", &n, &k);
    for (i_init = 1; i_init <= n; ++i_init)
    {
        flow[0][i_init] = 1;
        val[0][i_init] = 0;
        flow[i_init][2 * n + 1] = 1;
        val[i_init][2 * n + 1] = 0;
        for (j = n + 1; j <= 2 * n; ++j)
        {
            flow[i_init][j] = 1;
            val[i_init][j] = -1;
            val[j][i_init] = 1;
        }
    }
    for (i_input_points = 1; i_input_points <= 2 * n; ++i_input_points)
    {
        cnt = i_input_points;
        scanf("%d%d", &point_a_x, &point_b_y);
        P[i_input_points].x = point_a_x;
        P[i_input_points].y = point_b_y;
        scanf("%s", name);
        trans();
        insert(name);
    }
    while (1)
    {
        scanf("%s", name);
        if (!strcmp(name, "End"))
            break;
        trans();
        point_a_index = find(name);
        scanf("%s", name);
        trans();
        point_b_index = find(name);
        scanf("%d", &weight);
        val[point_a_index][point_b_index] = -weight;
        val[point_b_index][point_a_index] = weight;
    }
    for (i_check = 1; i_check <= n; ++i_check)
        check(i_check);
    fee_maxflow();
    return 0;
}