#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int f[125000];
int a[105][105];
int n, m;
int ans;

int getf(int x) ;
void ff(int x, int y) ;
int main() ;
int getf(int x)
{
    if (x == f[x])
    {
        return x;
    }
    f[x] = getf(f[x]);
    return f[x];
}
void ff(int x, int y)
{
    int root_x;
    int root_y;

    root_x = getf(x);
    root_y = getf(y);
    f[root_x] = root_y;
}
int main()
{
    char row_input[112];
    int i, j;

    scanf("%d%d", &n, &m);
    for (i = 1; i <= (n + 1) * 111 + m + 1; ++i)
        f[i] = i;

    for (i = 1; i <= n; ++i)
    {
        scanf("%s", row_input);
        for (j = 1; j <= m; ++j)
            a[i][j] = (row_input[j - 1] != '-');
    }

    for (i = 1; i <= n; ++i)
    {
        for (j = 1; j <= m; ++j)
        {
            if (a[i][j])
            {
                int current_cell_id = 110 * i + j;

                if (i > 1 && a[i - 1][j])
                    ff(110 * (i - 1) + j, current_cell_id);
                if (i > 2 && a[i - 2][j])
                    ff(110 * (i - 2) + j, current_cell_id);
                if (i < n && a[i + 1][j])
                    ff(110 * (i + 1) + j, current_cell_id);
                if (i + 1 < n && a[i + 2][j])
                    ff(110 * (i + 2) + j, current_cell_id);

                if (j > 1 && a[i][j - 1])
                    ff(110 * i + j - 1, current_cell_id);
                if (j > 2 && a[i][j - 2])
                    ff(110 * i + j - 2, current_cell_id);
                if (j < m && a[i][j + 1])
                    ff(110 * i + j + 1, current_cell_id);
                if (j + 1 < m && a[i][j + 2])
                    ff(110 * i + j + 2, current_cell_id);

                if (i > 1 && j > 1 && a[i - 1][j - 1])
                    ff(110 * (i - 1) + j - 1, current_cell_id);
                if (i > 1 && j < m && a[i - 1][j + 1])
                    ff(110 * (i - 1) + j + 1, current_cell_id);
                if (i < n && j > 1 && a[i + 1][j - 1])
                    ff(110 * (i + 1) + j - 1, current_cell_id);
                if (i < n && j < m && a[i + 1][j + 1])
                    ff(110 * (i + 1) + j + 1, current_cell_id);
            }
        }
    }

    ans = 0;
    for (i = 1; i <= n; ++i)
    {
        for (j = 1; j <= m; ++j)
        {
            int cell_id = 110 * i + j;
            if (f[cell_id] == cell_id && a[i][j])
                ++ans;
        }
    }

    printf("%d", ans);
    return 0;
}