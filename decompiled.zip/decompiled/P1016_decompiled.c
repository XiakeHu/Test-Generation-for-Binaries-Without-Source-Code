#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    double dist;
    double price;
} station;

int compare(const void *a, const void *b)
{
    const station *stationA = (const station *)a;
    const station *stationB = (const station *)b;

    if (stationB->dist > stationA->dist)
    {
        return -1;
    }
    else if (stationA->dist > stationB->dist)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int main() {
    station stations[154];
    int stationCount;
    double unitPrice;
    double tankCapacity;
    double distancePerUnit;
    double totalDistance;
    double currentDistance;
    int nextStationIndex;
    double currentOil;
    int currentStationIndex;
    int inputLoopIndex;
    double totalFee;

    totalFee = 0.0;
    scanf("%lf %lf %lf %lf %d", &totalDistance, &tankCapacity, &distancePerUnit, &unitPrice, &stationCount);
    for (inputLoopIndex = 1; inputLoopIndex <= stationCount; ++inputLoopIndex) {
        scanf("%lf %lf", &stations[inputLoopIndex].dist, &stations[inputLoopIndex].price);
    }
    stations[0].dist = 0.0;
    stations[0].price = unitPrice;
    stations[stationCount + 1].dist = totalDistance;
    stations[stationCount + 1].price = -1.0;
    qsort(stations, stationCount + 2, sizeof(station), compare);
    currentStationIndex = 0;
    currentOil = 0.0;
    while (currentStationIndex <= stationCount) {
        nextStationIndex = currentStationIndex;
        do {
            if (distancePerUnit * tankCapacity + stations[currentStationIndex].dist < stations[nextStationIndex + 1].dist) {
                break;
            }
            if (nextStationIndex > stationCount + 1) {
                break;
            }
            ++nextStationIndex;
        } while (stations[currentStationIndex].price < stations[nextStationIndex].price);
        if (nextStationIndex == currentStationIndex) {
            printf("No Solution");
            return 0;
        }
        currentDistance = stations[nextStationIndex].dist - stations[currentStationIndex].dist;
        if (stations[currentStationIndex].price >= stations[nextStationIndex].price) {
            if (currentDistance / distancePerUnit < currentOil) {
                currentOil = currentOil - currentDistance / distancePerUnit;
            } else {
                totalFee = stations[currentStationIndex].price * (currentDistance / distancePerUnit - currentOil) + totalFee;
                currentOil = 0.0;
            }
        }
        if (stations[nextStationIndex].price > stations[currentStationIndex].price) {
            if (currentDistance / distancePerUnit < currentOil) {
                totalFee = stations[currentStationIndex].price * (tankCapacity - currentOil + currentDistance / distancePerUnit) + totalFee;
                currentOil = tankCapacity - currentDistance / distancePerUnit;
            } else {
                totalFee = stations[currentStationIndex].price * (currentDistance / distancePerUnit - currentOil) + totalFee;
                currentOil = tankCapacity - currentDistance / distancePerUnit;
                totalFee = stations[currentStationIndex].price * currentOil + totalFee;
            }
        }
        currentStationIndex = nextStationIndex;
    }
    printf("%.2lf", totalFee);
    return 0;
}