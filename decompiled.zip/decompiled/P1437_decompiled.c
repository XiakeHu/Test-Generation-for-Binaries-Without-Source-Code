#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

void maxx(int *a, int b) ;
void in(int *a) ;
 int n, m; int a[55][55]; int f[55][55][55]; int ans;  void in(int *a); void maxx(int *a, int b);  int main() ;
void maxx(int *a, int b)
{
    if (b > *a)
        *a = b;
}
void in(int *a)
{
    int sign;
    int value;
    char c;

    c = getchar();
    value = 0;
    sign = 1;
    while ((unsigned int)(c - '0') > 9)
    {
        if (c == '-')
            sign = -1;
        c = getchar();
    }
    while ((unsigned int)(c - '0') <= 9)
    {
        value = 10 * value + c - '0';
        c = getchar();
    }
    *a = sign * value;
}
int main()
{
    int j_outer;
    int i_outer;
    int l;
    int k;
    int sum;
    int i_inner;
    int j_inner;
    int j;
    int i;

    in(&n);
    in(&m);
    memset(f, -127, sizeof(f));
    f[n + 1][0][0] = 0;
    for (i = 1; i <= n; ++i)
    {
        for (j = 1; j <= n - i + 1; ++j)
        {
            in(&a[i][j]);
        }
    }
    for (j_inner = n; j_inner > 0; --j_inner)
    {
        i_inner = 0;
        sum = 0;
        while (i_inner <= n - j_inner + 1)
        {
            for (k = i_inner; k <= m; ++k)
            {
                for (l = (int)fmax(0.0, (double)(i_inner - 1)); l <= n - j_inner; ++l)
                {
                    maxx(&f[j_inner][i_inner][k], sum + f[j_inner + 1][l][k - i_inner]);
                }
            }
            sum += a[++i_inner][j_inner];
        }
    }
    for (i_outer = 1; i_outer <= n; ++i_outer)
    {
        for (j_outer = 1; j_outer <= n - i_outer + 1; ++j_outer)
        {
            maxx(&ans, f[i_outer][j_outer][m]);
        }
    }
    printf("%d", ans);
    return 0;
}
