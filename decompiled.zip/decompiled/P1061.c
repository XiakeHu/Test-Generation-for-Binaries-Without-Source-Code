#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> 

typedef long long int64;

int64 read_int() {
    int64 r = 0, f = 1; char c = getchar();
    while (!isdigit(c)) { if (c == '-') f = -1; c = getchar(); }
    while (isdigit(c)) r = (r << 1) + (r << 3) + (c ^ 48), c = getchar();
    return f * r;
}

char* read_string() {
    char c = getchar();
    char *s = malloc(sizeof(char) * 50); // 假设字符串长度不会超过 50
    int i = 0;
    while (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))) c = getchar();
    while ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) s[i++] = c, c = getchar();
    s[i] = '\0'; // 在字符串末尾添加空字符
    return s;
}

int64 s, t, w;
char* jam;

void increment_jam() {
    for (int j = w - 1; j >= 0; j--) {
        if (jam[j] - 'a' + 1 < t - (w - 1 - j)) {
            jam[j]++;
            for (int k = j + 1; k < w; k++) {
                jam[k] = jam[k - 1] + 1;
              }
            printf("%s\n", jam);
            break;
          }
      }
}

int main() {
    s = read_int(), t = read_int(), w = read_int();
    jam = read_string();
    
    for (int i = 1; i <= 5; i++) {
        increment_jam();
      }

    free(jam); // 释放动态分配的内存
    return 0;
}