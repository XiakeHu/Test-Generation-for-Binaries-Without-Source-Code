#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

void convert_base(int num, int base) ;
 int m, n;  void convert_base(int num, int base) ;
void convert_base(int num, int base)
{
    int a[200]; // Assuming a global array 'a' exists. Size is estimated from context.
    int jl;     // Length of the representation
    int o;      // Negative base
    int p;      // Temporary value for division/modulo
    int js;     // Accumulated value for verification
    int jk;     // Power of base for verification
    int i;      // Loop counter

    if (num > 0)
    {
        jl = 0;
        o = -base;
        p = num;
        while (p > 0)
        {
            ++jl;
            a[jl] = p % o;
            p = p / o;
        }
        for (i = 1; i <= jl; ++i)
        {
            a[i + 1] += a[i] / o;
            a[i] = a[i] % o;
            if ((i & 1) == 0 && a[i] > 0)
            {
                ++a[i + 1];
                a[i] = o - a[i];
            }
            if (a[jl + 1] > 0)
            {
                ++jl;
            }
        }
        js = 1;
        jk = 1;
        for (i = 1; i <= jl; ++i)
        {
            js += jk * a[i];
            jk *= base;
            if (num == js)
            {
                break;
            }
        }
        printf("%d=", num);
        for (i = jl; i > 0; --i)
        {
            if (a[i] > 9)
            {
                putchar(a[i] + 55);
            }
            else
            {
                printf("%d", a[i]);
            }
        }
    }
    else
    {
        jl = 0;
        o = -base;
        p = -num;
        js = -base;
        jk = 2;
        for (i = 1; i <= 100 && js <= p; ++i)
        {
            js = js * o * o;
            jk += 2;
        }
        p = js - p;
        while (p > 0)
        {
            ++jl;
            a[jl] = p % o;
            p = p / o;
        }
        ++a[jk];
        for (i = 1; i <= jl; ++i)
        {
            a[i + 1] += a[i] / o;
            a[i] = a[i] % o;
            if ((i & 1) == 0 && a[i] > 0 && i != jk)
            {
                ++a[i + 1];
                a[i] = o - a[i];
            }
            if (a[jl + 1] > 0)
            {
                ++jl;
            }
        }
        if (jl < jk)
        {
            jl = jk;
        }
        js = 1;
        jk = 1;
        for (i = 1; i <= jl; ++i)
        {
            js += jk * a[i];
            jk *= base;
            if (num == js)
            {
                break;
            }
        }
        printf("%d=", num);
        for (i = jl; i > 0; --i)
        {
            if (a[i] > 9)
            {
                putchar(a[i] + 55);
            }
            else
            {
                printf("%d", a[i]);
            }
        }
    }
    printf("(base%d)", base);
}
int main()
{
    scanf("%d%d", &m, &n);
    convert_base(m, n);
    return 0;
}
