#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef long long LL;

typedef struct qwq {
    LL val;
    struct qwq* left;
    struct qwq* right;
    int if_del;
} qwq;

typedef struct pwp {
    qwq* p;
} pwp;

int compare(const void *a, const void *b);
void push(qwq *node);
qwq* pop();

#define MAX_SIZE 200005
pwp h[MAX_SIZE];
int h_size = 0;

int compare(const void *a, const void *b)
{
    const qwq *ptr_a = ((const pwp *)a)->p;
    const qwq *ptr_b = ((const pwp *)b)->p;
    LL value_a = ptr_a->val;
    LL value_b = ptr_b->val;
    if (value_a < value_b) return 1;
    if (value_a > value_b) return -1;
    return 0;
}

void push(qwq *node)
{
    h[h_size].p = node;
    ++h_size;
    qsort(h, h_size, sizeof(pwp), compare);
}

qwq* pop()
{
    while (h_size > 0 && h[h_size - 1].p->if_del)
    {
        --h_size;
    }
    if (h_size == 0) return NULL;
    qwq* popped_node = h[--h_size].p;
    return popped_node;
}

int main() {
    LL input_value;
    LL k;
    LL n;
    qwq *new_node;
    qwq *merged_node;
    qwq *current_node;
    LL iteration_counter;
    LL total_sum;
    LL index;
    qwq *last_node;

    scanf("%lld %lld", &n, &k);
    last_node = (qwq *)malloc(sizeof(qwq));
    scanf("%lld", &input_value);
    last_node->val = input_value;
    last_node->left = NULL;
    last_node->right = NULL;
    last_node->if_del = 0;
    push(last_node);

    for (index = 2; index <= n; ++index) {
        scanf("%lld", &input_value);
        new_node = (qwq *)malloc(sizeof(qwq));
        new_node->val = input_value;
        new_node->left = last_node;
        new_node->right = NULL;
        new_node->if_del = 0;
        last_node->right = new_node;
        last_node = new_node;
        push(new_node);
    }

    total_sum = 0;
    for (iteration_counter = 1; iteration_counter <= k; ++iteration_counter) {
        current_node = pop();
        if (current_node == NULL || current_node->val <= 0) {
            break;
        }
        total_sum += current_node->val;

        merged_node = (qwq *)malloc(sizeof(qwq));
        merged_node->val = -current_node->val;

        if (current_node->left) {
            current_node->left->if_del = 1;
            merged_node->val += current_node->left->val;
            merged_node->left = current_node->left->left;
            if (merged_node->left) {
                merged_node->left->right = merged_node;
            }
        } else {
            merged_node->left = NULL;
        }

        if (current_node->right) {
            current_node->right->if_del = 1;
            merged_node->val += current_node->right->val;
            merged_node->right = current_node->right->right;
            if (merged_node->right) {
                merged_node->right->left = merged_node;
            }
        } else {
            merged_node->right = NULL;
        }

        merged_node->if_del = 0;
        push(merged_node);
    }

    printf("%lld", total_sum);
    return 0;
}