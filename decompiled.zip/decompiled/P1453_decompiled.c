#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#define N 100010
#define M 200010
struct Edge {
    int to;
    int nxt;
};
struct Edge e[M * 2];
int head[N];
int b[N];
int rd[N];
int tot;
int c[N];
int cnt;
int f[N][2];
int g[N][2];
double k;
void dfs0(int u, int fa) ;
int qread() ;
void tppx() ;
void mr(int u, int v) ;
void dfs(int u, int fa) ;
int main() ;
void dfs0(int u, int fa)
{
    int v;
    int i;

    for (i = head[u]; i != 0; i = e[i].nxt)
    {
        v = e[i].to;
        if (v != fa && b[v] == 0 && rd[v] == 2)
        {
            b[v] = 1;
            tot = tot + 1;
            c[tot] = v;
            dfs0(v, u);
            return;
        }
    }
}
int qread()
{
    char current_char;
    int sign = 1;
    int value = 0;

    current_char = getchar();
    while (current_char <= 47 || current_char > 57) {
        if (current_char == '-') {
            sign = -1;
        }
        current_char = getchar();
    }

    while (current_char > 47 && current_char <= 57) {
        value = 10 * value + (current_char ^ 0x30);
        current_char = getchar();
    }

    return sign * value;
}
void tppx()
{
    int i;

    for (i = 1; i <= N; ++i)
    {
        if (rd[i] == 2)
        {
            b[i] = 1;
            tot = tot + 1;
            c[tot] = i;
            dfs0(i, 0);
            return;
        }
    }
}
void mr(int u, int v)
{
    cnt = cnt + 1;
    e[cnt].to = v;
    e[cnt].nxt = head[u];
    head[u] = cnt;
}
void dfs(int u, int fa)
{
    double temp_sum;
    int v;
    int i;

    for (i = head[u]; i != 0; i = e[i].nxt)
    {
        v = e[i].to;
        if (v != fa && b[v] == 0)
        {
            dfs(v, u);
            temp_sum = (double)f[u][0];
            f[u][0] = (int)(fmax((double)f[v][1], (double)f[v][0]) + temp_sum);
            f[u][1] += f[v][0];
        }
    }
}
int main()
{
    int v;
    int u;
    int ans;
    int ansa;
    int n;
    int i_3;
    int i_2;
    int i_1;
    int i_0;
    int i;

    n = qread();
    for (i = 1; i <= n; ++i)
        f[i][1] = qread();
    for (i_0 = 1; i_0 <= n; ++i_0)
    {
        u = qread() + 1;
        v = qread() + 1;
        ++rd[u];
        ++rd[v];
        mr(u, v);
        mr(v, u);
    }
    tppx();
    for (i_1 = 1; i_1 <= tot; ++i_1)
        dfs(c[i_1], 0);
    memset(g, -63, sizeof(g));
    g[1][0] = f[c[1]][0];
    for (i_2 = 2; i_2 <= tot; ++i_2)
    {
        g[i_2][1] = f[c[i_2]][1] + g[i_2 - 1][0];
        g[i_2][0] = (int)(fmax((double)g[i_2 - 1][0], (double)g[i_2 - 1][1]) + (double)f[c[i_2]][0]);
    }
    ans = (int)fmax((double)g[tot][0], (double)g[tot][1]);
    memset(g, -63, sizeof(g));
    g[1][1] = f[c[1]][1];
    for (i_3 = 2; i_3 <= tot; ++i_3)
    {
        g[i_3][1] = f[c[i_3]][1] + g[i_3 - 1][0];
        g[i_3][0] = (int)(fmax((double)g[i_3 - 1][0], (double)g[i_3 - 1][1]) + (double)f[c[i_3]][0]);
    }
    ansa = (int)fmax((double)ans, (double)g[tot][0]);
    scanf("%lf", &k);
    printf("%.1lf", (double)ansa * k);
    return 0;
}