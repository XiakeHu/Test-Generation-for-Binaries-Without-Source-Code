#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n, m;
int num_block, num_ceng, num_ceng1, cdm;
int mapp[1006][1006];
char room[1006][1006][1006];

int main()
{
    int i, j, k;
    int temp_max_ceng;

    memset(room, 0, sizeof(room));
    scanf("%d%d", &n, &m);

    num_block = 0;
    num_ceng = 0;
    for (i = 1; i <= n; ++i)
    {
        for (j = 1; j <= m; ++j)
        {
            scanf("%1d", &mapp[i][j]);
            num_block += mapp[i][j];
            if (mapp[i][j] > num_ceng)
            {
                num_ceng = mapp[i][j];
            }
        }
    }

    num_ceng1 = num_ceng;
    while (num_ceng > 0)
    {
        for (i = 1; i <= n; ++i)
        {
            for (j = 1; j <= m; ++j)
            {
                if (mapp[i][j] > 0)
                {
                    room[num_ceng][i][j] = 1;
                    --mapp[i][j];
                }
            }
        }
        --num_ceng;
    }

    cdm = 0;
    for (i = 1; i <= num_ceng1; ++i)
    {
        for (j = 1; j <= n; ++j)
        {
            for (k = 1; k <= m; ++k)
            {
                if (room[i][j][k])
                {
                    if (room[i + 1][j][k])
                        ++cdm;
                    if (room[i - 1][j][k])
                        ++cdm;
                    if (room[i][j + 1][k])
                        ++cdm;
                    if (room[i][j - 1][k])
                        ++cdm;
                    if (room[i][j][k - 1])
                        ++cdm;
                    if (room[i][j][k + 1])
                        ++cdm;
                }
            }
        }
    }

    printf("%d", 6 * num_block - cdm);
    return 0;
}