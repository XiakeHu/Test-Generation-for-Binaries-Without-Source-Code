#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int val;
    int type;
    int num;
} ele;

typedef int ll;

ll pmod(ll a, ll n);
void push(ele e);
void pop();
ele top();
int read();

#define MAX_M 1000
#define MAX_Q 100000

int q_size = 0;
ele q[MAX_Q];
int n, m;
int a[MAX_M + 1];
int b[MAX_M + 1];
long long ans = 0;

ll pmod(ll a, ll n)
{
    ll result = 1LL;
    while (n)
    {
        if ((n & 1) != 0)
            result *= a;
        a *= a;
        n >>= 1;
    }
    return result;
}
void push(ele e)
{
    int index = q_size++;
    q[index] = e;
}
void pop()
{
    int i;
    ele temp;

    for (i = 0; i < q_size - 1; ++i)
    {
        if (q[i].val > q[i + 1].val)
        {
            temp.val = q[i].val;
            temp.type = q[i].type;
            temp.num = q[i].num;

            q[i].val = q[i + 1].val;
            q[i].type = q[i + 1].type;
            q[i].num = q[i + 1].num;

            q[i + 1].val = temp.val;
            q[i + 1].type = temp.type;
            q[i + 1].num = temp.num;
        }
    }
}
ele top()
{
    ele result;
    int index = q_size - 1;
    
    result.type = q[index].type;
    result.num = q[index].num;
    result.val = q[index].val;
    
    return result;
}
int read()
{
    const unsigned short *ctype_table;
    char ch;
    int sign = 1;
    int value = 0;

    while (1)
    {
        ctype_table = *__ctype_b_loc();
        ch = getchar();
        if ((ctype_table[(unsigned char)ch] & 0x800) != 0)
            break;
        if (ch == '-')
            sign = -1;
    }

    value = ch - '0';
    while (1)
    {
        ctype_table = *__ctype_b_loc();
        ch = getchar();
        if ((ctype_table[(unsigned char)ch] & 0x800) == 0)
            break;
        value = 10 * value + (ch - '0');
    }

    return sign * value;
}
int main()
{
    ll v3;
    ll v4;
    ele tmp;
    int i_0;
    int i;
    ele v10;
    ele v11;

    n = read();
    m = read();
    for ( i = 1; i <= m; ++i )
    {
        a[i] = read();
        b[i] = read();
    }
    for ( i_0 = 1; i_0 <= m; ++i_0 )
    {
        v10.val = a[i_0];
        v10.type = i_0;
        v10.num = 1;
        push(v10);
    }
    while ( n-- )
    {
        tmp = top();
        pop();
        ans += tmp.val;
        v3 = a[tmp.type];
        v4 = pmod(tmp.num + 1, b[tmp.type]);
        v11.val = v3 * (v4 - pmod(tmp.num, b[tmp.type]));
        v11.type = tmp.type;
        v11.num = tmp.num + 1;
        push(v11);
    }
    printf("%lld", ans);
    return 0;
}