#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef long long ll;

int s(ll x) ;
int s(ll x)
{
    int sum = 0;
    while (x != 0)
    {
        sum += (int)(x % 10);
        x /= 10;
    }
    return sum;
}
int main()
{
    ll R;
    ll L;
    int book[10];
    ll b;
    ll a;
    ll j;
    ll i;
    int count;
    int index;

    book[0] = 3;
    book[1] = 9;
    book[2] = 24;
    book[3] = 63;
    book[4] = 153;
    book[5] = 362;
    book[6] = 819;
    book[7] = 1810;
    book[8] = 3872;
    book[9] = 1;
    index = 0;
    count = 0;

    scanf("%lld %lld", &L, &R);

    if (L == R)
    {
        a = s(L * L);
        b = s(L);
        if (a == b * b)
            ++count;
    }
    else
    {
        for (i = 1LL; i <= R; i *= 10LL)
        {
            if (i == 1)
            {
                if (L == 1 && R > 2)
                    count += book[index];
                if ((L == 1 && R == 2) || (L == 2 && R == 3))
                    count += 2;
                if (L == 2 && R > 3)
                    count += 2;
                if (L == 3 && R > 3)
                    ++count;
            }
            else
            {
                ll threshold = (32 * i) / 10;

                if (i >= L && i < R && threshold <= R)
                    count += book[index];

                if (i <= L && threshold > L && threshold >= R)
                {
                    for (j = L; j <= R; ++j)
                    {
                        a = s(j * j);
                        b = s(j);
                        if (a == b * b)
                            ++count;
                    }
                }

                if (i > L && i <= R && threshold > R)
                {
                    for (j = i; j <= R; ++j)
                    {
                        a = s(j * j);
                        b = s(j);
                        if (a == b * b)
                            ++count;
                    }
                }

                if (i < L && threshold >= L && threshold < R)
                {
                    for (j = L; j < threshold; ++j)
                    {
                        a = s(j * j);
                        b = s(j);
                        if (a == b * b)
                            ++count;
                    }
                }
            }
            ++index;
        }
    }

    printf("%d", count);
    return 0;
}