#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define MAXN 100003

typedef struct {
    int cnt;
    int heads[MAXN];
    int to[MAXN * 2];
    int next[MAXN * 2];
} graph;

int n, m, p;
int cov;
int vis[MAXN];
int imd[MAXN];
int ind[MAXN];
int scn;
int sta[MAXN];
int isA[MAXN];
int tpn;
int tplist[MAXN];
int fee;
int scA[MAXN];
int bel[MAXN];
int aai[MAXN];
int isa[MAXN];
int oud[MAXN];
int X[MAXN];
int tot;
graph E, E1, E2;

void addE(graph *g, const int x, const int y);
void cover(const int x);
void topo();
void dfs1(const int x);
void reverse();
void dfs2(const int x);
int search();
void reconstruct();
void read(int *X);
void Kosaraju();

void addE(graph *g, const int x, const int y)
{
    int new_edge_index = ++g->cnt;
    g->next[new_edge_index] = g->heads[x];
    g->to[new_edge_index] = y;
    g->heads[x] = new_edge_index;
}
void cover(const int x)
{
    int y;
    int e;

    ++cov;
    vis[x] = 1;
    for (e = E2.heads[x]; e; e = E2.next[e])
    {
        y = E2.to[e];
        if (!vis[y])
            cover(y);
    }
}
void topo()
{
    int queue_front;
    int queue_rear;
    int edge_index;
    int current_edge;
    int current_node;
    int neighbor_node;

    memcpy(imd, ind, sizeof(imd));
    queue_front = 0;
    queue_rear = 0;
    for (current_edge = 1; current_edge <= scn; ++current_edge)
    {
        if (!imd[current_edge])
        {
            sta[queue_rear] = current_edge;
            ++queue_rear;
        }
    }
    while (queue_front < queue_rear)
    {
        current_node = sta[queue_front];
        ++queue_front;
        if (isA[current_node])
        {
            ++tpn;
            tplist[tpn] = current_node;
        }
        for (edge_index = E2.heads[current_node]; edge_index; edge_index = E2.next[edge_index])
        {
            neighbor_node = E2.to[edge_index];
            --imd[neighbor_node];
            if (!imd[neighbor_node])
            {
                sta[queue_rear] = neighbor_node;
                ++queue_rear;
            }
        }
    }
}
void dfs1(const int x)
{
    int y;
    int edge;

    vis[x] = 1;
    for (edge = E.heads[x]; edge != 0; edge = E.next[edge])
    {
        y = E.to[edge];
        if (!vis[y])
        {
            dfs1(y);
        }
    }
    tot++;
    sta[tot] = x;
}
void reverse()
{
    int edge_index;
    int node_x;

    for ( node_x = 1; node_x <= n; ++node_x )
    {
        for ( edge_index = E.heads[node_x]; edge_index; edge_index = E.next[edge_index] )
            addE(&E1, E.to[edge_index], node_x);
    }
}
void dfs2(const int x) {
    int y;
    int edge_index;

    bel[x] = scn;
    if (isa[x]) {
        isA[scn] = 1;
        scA[scn] = (int)fmin((double)scA[scn], (double)X[x]);
    }
    for (edge_index = E1.heads[x]; edge_index != 0; edge_index = E1.next[edge_index]) {
        y = E1.to[edge_index];
        if (bel[y] == 0) {
            dfs2(y);
        }
    }
}
int search()
{
    int result;
    int current_node;
    int i;
    int j;

    topo();
    memset(vis, 0, sizeof(vis));
    for (i = 1; i <= tpn; ++i)
    {
        current_node = tplist[i];
        if (!vis[current_node])
        {
            fee += scA[current_node];
            cover(current_node);
        }
    }
    if (cov == scn)
        return fee;
    for (j = 1; j <= n; ++j)
    {
        if (!vis[bel[j]])
            return -j;
    }
    return n;
}
void reconstruct()
{
    int y;
    int edge_index;
    int x;

    for (x = 1; x <= n; ++x)
    {
        for (edge_index = E.heads[x]; edge_index; edge_index = E.next[edge_index])
        {
            y = E.to[edge_index];
            if (bel[x] != bel[y])
            {
                addE(&E2, bel[x], bel[y]);
                ++ind[bel[y]];
                ++oud[bel[x]];
            }
        }
    }
}
void read(int *X)
{
    char ch;
    char symbol;

    *X = 0;
    symbol = 0;
    for (ch = getchar(); ch <= 47 || ch > 57; ch = getchar())
    {
        if (ch == '-')
            symbol = 1;
    }
    while (ch > 47 && ch <= 57)
    {
        *X = (ch ^ 0x30) + 10 * *X;
        ch = getchar();
    }
    if (symbol)
        *X = -*X;
}
void Kosaraju()
{
    int current_node;
    int stack_index;
    int node;

    for ( node = 1; node <= n; ++node )
    {
        if ( !vis[node] )
            dfs1(node);
    }
    reverse();
    memset(bel, 0, sizeof(bel));
    scn = 0;
    for ( stack_index = tot; stack_index; --stack_index )
    {
        current_node = sta[stack_index];
        if ( !bel[current_node] )
        {
            ++scn;
            dfs2(current_node);
        }
    }
}
int main()
{
    int y;
    int x_0;
    int x;
    int i_0;
    int i;

    memset(scA, 127, sizeof(scA));
    read(&n);
    read(&p);
    for (i = 1; i <= p; ++i)
    {
        read(&aai[i]);
        read(&scA[aai[i]]);
        isa[aai[i]] = 1;
    }
    read(&m);
    for (i_0 = 1; i_0 <= m; ++i_0)
    {
        read(&x_0);
        read(&y);
        addE(&E, x_0, y);
    }
    Kosaraju();
    reconstruct();
    x = search();
    if (x >= 0)
        printf("YES%d", x);
    else
        printf("NO%d", -x);
    return 0;
}