#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct __attribute__((aligned(4))) {int x;char y[10];} MyStruct;

int compare(const void *a, const void *b) ;
void solve_int(int *x) ;
int compare(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;
    
    if (value_a > value_b)
        return 1;
    else if (value_a < value_b)
        return -1;
    else
        return 0;
}
void solve_int(int *x)
{
    ++(*x);
}
int main(int argc, const char **argv, const char **envp)
{
    int sorted_array[8];
    MyStruct my_struct;
    char input_string[28];
    int integer_value;

    integer_value = 10;
    my_struct.x = 5;
    *(long long *)my_struct.y = 0x6F6C6C6568LL;
    *(short *)&my_struct.y[8] = 0;
    solve_int(&integer_value);
    sorted_array[0] = 3;
    sorted_array[1] = 1;
    sorted_array[2] = 4;
    sorted_array[3] = 1;
    sorted_array[4] = 5;
    sorted_array[5] = 9;
    qsort(sorted_array, 6uLL, 4uLL, compare);
    printf("Enter a string: ");
    scanf("%s", input_string);
    printf("You entered: %s\n", input_string);
    return 0;
}