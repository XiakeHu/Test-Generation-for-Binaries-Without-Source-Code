#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>

typedef struct {
    char* s;
} BINT;

BINT BINT_create(char* x) {
    BINT bint;
    bint.s = malloc(strlen(x) + 1);
    strcpy(bint.s, x);
    return bint;
}

void BINT_destroy(BINT* bint) {
    free(bint->s);
}

BINT BINT_add(const BINT* a, const BINT* b) {
    int la = strlen(a->s), lb = strlen(b->s);
    int m = fmax(la, lb);
    int* c = calloc(m + 1, sizeof(int));
    
    for (int i = 0; i < la; ++i) {
        c[i] += a->s[la - 1 - i] - '0';
    }
    
    for (int i = 0; i < lb; ++i) {
        c[i] += b->s[lb - 1 - i] - '0';
    }
    
    for (int i = 0; i < m; ++i) {
        c[i + 1] += c[i] / 10;
        c[i] %= 10;
    }
    
    while (!c[m] && m) --m;
    
    char* res = calloc(m + 2, sizeof(char));
    
    for (int i = 0; i <= m; ++i) {
        res[i] = c[m - i] + '0';
    }
    
    free(c);
    
    BINT result = BINT_create(res);
    free(res);
    return result;
}

// 修复后的 BINT_multiply
BINT BINT_multiply(const BINT* a, const BINT* b) {
    int la = strlen(a->s), lb = strlen(b->s);
    int m = la + lb;
    int* c = calloc(m + 1, sizeof(int));
    
    // 修复：先存储数字到正确位置
    int* da = calloc(la, sizeof(int));
    int* db = calloc(lb, sizeof(int));
    for (int i = 0; i < la; ++i) {
        da[i] = a->s[la - 1 - i] - '0';
    }
    for (int i = 0; i < lb; ++i) {
        db[i] = b->s[lb - 1 - i] - '0';
    }
    
    // 乘法核心
    for (int i = 0; i < la; ++i) {
        for (int j = 0; j < lb; ++j) {
            c[i + j] += da[i] * db[j];
            c[i + j + 1] += c[i + j] / 10;
            c[i + j] %= 10;
        }
    }
    
    // 处理进位
    for (int i = 0; i < m; ++i) {
        c[i + 1] += c[i] / 10;
        c[i] %= 10;
    }
    
    while (m > 0 && !c[m]) --m;
    
    char* res = calloc(m + 2, sizeof(char));
    for (int i = 0; i <= m; ++i) {
        res[i] = c[m - i] + '0';
    }
    
    free(c);
    free(da);
    free(db);
    
    BINT result = BINT_create(res);
    free(res);
    return result;
}

bool BINT_less_than(const BINT* a, const BINT* b) {
    if (strlen(a->s) < strlen(b->s)) return true;
    if (strlen(a->s) == strlen(b->s) && strcmp(a->s, b->s) < 0) return true;
    return false;
}

void BINT_assign_string(BINT* bint, char* x) {
    free(bint->s);
    bint->s = malloc(strlen(x) + 1);
    strcpy(bint->s, x);
}

void BINT_assign_long_long(BINT* bint, long long x) {
    free(bint->s);
    char buffer[25];
    sprintf(buffer, "%lld", x);
    bint->s = malloc(strlen(buffer) + 1);
    strcpy(bint->s, buffer);
}

void BINT_assign_int(BINT* bint, int x) {
    free(bint->s);
    char buffer[25];
    sprintf(buffer, "%d", x);
    bint->s = malloc(strlen(buffer) + 1);
    strcpy(bint->s, buffer);
}

void BINT_print(const BINT* bint) {
    printf("%s", bint->s);
}

BINT D[45][45];
BINT dp[45][45];
char s[100];
int n, m;

int main() {
    scanf("%d %d %s", &n, &m, s + 1);
    
    for (int i = 1; i <= n; ++i) {
        for (int j = i; j <= n; ++j) {
            char* substr = malloc(j - i + 2);
            strncpy(substr, s + i, j - i + 1);
            substr[j - i + 1] = '\0';
            D[i][j] = BINT_create(substr);
            free(substr);
        }
    }
    
    for (int i = 1; i <= n; ++i) {
        dp[i][0] = D[1][i];
    }
    
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m; ++j) {
            if (j >= i) break;
            
            for (int k = j; k < i; ++k) {
                BINT temp = BINT_multiply(&dp[k][j - 1], &D[k + 1][i]);
                
                if (BINT_less_than(&dp[i][j], &temp)) {
                    BINT_destroy(&dp[i][j]);
                    dp[i][j] = temp;
                } else {
                    BINT_destroy(&temp);
                }
            }
        }
    }
    
    BINT_print(&dp[n][m]);
    
    for (int i = 1; i <= n; ++i) {
        for (int j = i; j <= n; ++j) {
            BINT_destroy(&D[i][j]);
        }
    }
    
    return 0;
}
