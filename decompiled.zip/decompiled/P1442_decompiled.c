#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct DD {
    int ld;
    int rd;
    int hd;
} DD;

typedef struct SegNode {
    int shu;
    int cover;
} SegNode;

SegNode segtree[800020];
DD kuai[100005];
int pai[200010];
int duiy[200010];
int hhnext[100005][2];
int f[100005][2];
int n, maxt, startx, starty, paitail, start_next;

void pushup(int cur);
void pushdown(int cur);
int cmp_int(const void *a, const void *b);
int cmp_dd(const void *a, const void *b);
void add(int cur, int l, int r, int L, int R, int t);
int query(int cur, int l, int r, int L, int R);

void pushup(int cur)
{
    int left_child = 2 * cur;
    int right_child = (2 * cur) | 1;
    int left_value = segtree[left_child].shu;
    int right_value = segtree[right_child].shu;
    segtree[cur].shu = (left_value > right_value) ? left_value : right_value;
}
void pushdown(int cur)
{
    if (segtree[cur].cover)
    {
        int left_child = 2 * cur;
        int right_child = (2 * cur) | 1;

        segtree[right_child].cover = segtree[cur].cover;
        segtree[left_child].cover = segtree[cur].cover;

        segtree[right_child].shu = segtree[cur].cover;
        segtree[left_child].shu = segtree[cur].cover;

        segtree[cur].cover = 0;
    }
}
int cmp_int(const void *a, const void *b)
{
    const int *da = (const int *)a;
    const int *db = (const int *)b;
    return *da - *db;
}
int cmp_dd(const void *a, const void *b)
{
    const DD *da = (const DD *)a;
    const DD *db = (const DD *)b;
    return da->hd - db->hd;
}
void add(int cur, int l, int r, int L, int R, int t)
{
    if (L <= l && r <= R)
    {
        segtree[cur].cover = t;
        segtree[cur].shu = t;
    }
    else
    {
        pushdown(cur);
        int mid = (l + r) >> 1;
        if (L <= mid)
            add(2 * cur, l, mid, L, R, t);
        if (R > mid)
            add((2 * cur) | 1, mid + 1, r, L, R, t);
        pushup(cur);
    }
}
int query(int cur, int l, int r, int L, int R)
{
    int mid;
    int result;

    if (L <= l && r <= R)
        return segtree[cur].shu;

    pushdown(cur);
    result = 0;
    mid = (l + r) >> 1;

    if (L <= mid)
    {
        int left_result = query(2 * cur, l, mid, L, R);
        result = (int)fmax(0.0, (double)left_result);
    }

    if (R > mid)
    {
        int right_result = query((2 * cur) | 1, mid + 1, r, L, R);
        return (int)fmax((double)result, (double)right_result);
    }

    return result;
}
int main()
{
    int search_result;
    int ans;
    unsigned int h;
    int i;
    int j;
    int k;
    int l;
    int m;

    scanf("%d%d", &n, &maxt);
    scanf("%d%d", &startx, &starty);
    paitail = 1;
    for (i = 1; i <= n; ++i)
    {
        scanf("%d%d%d", &kuai[i].ld, &kuai[i].rd, &kuai[i].hd);
        pai[paitail++] = kuai[i].ld;
        pai[paitail++] = kuai[i].rd;
    }
    qsort(&pai[1], paitail - 1, sizeof(int), cmp_int);
    for (j = 1; j <= n; ++j)
    {
        search_result = (int)((int*)bsearch(&kuai[j].ld, &pai[1], paitail - 1, sizeof(int), cmp_int) - &pai[0]);
        duiy[search_result] = kuai[j].ld;
        kuai[j].ld = search_result;
        search_result = (int)((int*)bsearch(&kuai[j].rd, &pai[1], paitail - 1, sizeof(int), cmp_int) - &pai[0]);
        duiy[search_result] = kuai[j].rd;
        kuai[j].rd = search_result;
    }
    qsort(&kuai[1], n, sizeof(DD), cmp_dd);
    for (k = 1; k <= n; ++k)
    {
        hhnext[k][0] = query(1, 1, 200005, kuai[k].ld, kuai[k].ld);
        if (kuai[k].hd - kuai[hhnext[k][0]].hd > maxt)
            hhnext[k][0] = -1;
        hhnext[k][1] = query(1, 1, 200005, kuai[k].rd, kuai[k].rd);
        if (kuai[k].hd - kuai[hhnext[k][1]].hd > maxt)
            hhnext[k][1] = -1;
        add(1, 1, 200005, kuai[k].ld, kuai[k].rd, k);
    }
    h = (unsigned int)((int*)bsearch(&startx, &pai[1], paitail - 1, sizeof(int), cmp_int) - &pai[0]);
    start_next = query(1, 1, 200005, h, h);
    if (starty - kuai[start_next].hd > maxt)
        start_next = -1;
    for (l = 0; l <= n; ++l)
    {
        f[l][1] = 0x40000000;
        f[l][0] = f[l][1];
    }
    int diff_left = startx - duiy[kuai[start_next].ld];
    if (diff_left < 0)
        diff_left = duiy[kuai[start_next].ld] - startx;
    f[start_next][0] = diff_left;
    int diff_right = startx - duiy[kuai[start_next].rd];
    if (diff_right < 0)
        diff_right = duiy[kuai[start_next].rd] - startx;
    f[start_next][1] = diff_right;
    for (m = start_next; m > 0; --m)
    {
        if (hhnext[m][0] != -1)
        {
            int delta_left_left;
            if (hhnext[m][0])
            {
                int index = kuai[hhnext[m][0]].ld - duiy[kuai[m].ld];
                delta_left_left = duiy[index];
                if (delta_left_left <= 0)
                    delta_left_left = -delta_left_left;
            }
            else
            {
                delta_left_left = 0;
            }
            f[hhnext[m][0]][0] = (int)fmin((double)f[hhnext[m][0]][0], (double)(f[m][0] + delta_left_left));
            int delta_left_right;
            if (hhnext[m][0])
            {
                int index = kuai[hhnext[m][0]].rd - duiy[kuai[m].ld];
                delta_left_right = duiy[index];
                if (delta_left_right <= 0)
                    delta_left_right = -delta_left_right;
            }
            else
            {
                delta_left_right = 0;
            }
            f[hhnext[m][0]][1] = (int)fmin((double)f[hhnext[m][0]][1], (double)(f[m][0] + delta_left_right));
        }
        if (hhnext[m][1] != -1)
        {
            int delta_right_left;
            if (hhnext[m][1])
            {
                int index = kuai[hhnext[m][1]].ld - duiy[kuai[m].rd];
                delta_right_left = duiy[index];
                if (delta_right_left <= 0)
                    delta_right_left = -delta_right_left;
            }
            else
            {
                delta_right_left = 0;
            }
            f[hhnext[m][1]][0] = (int)fmin((double)f[hhnext[m][1]][0], (double)(f[m][1] + delta_right_left));
            int delta_right_right;
            if (hhnext[m][1])
            {
                int index = kuai[hhnext[m][1]].rd - duiy[kuai[m].rd];
                delta_right_right = duiy[index];
                if (delta_right_right <= 0)
                    delta_right_right = -delta_right_right;
            }
            else
            {
                delta_right_right = 0;
            }
            f[hhnext[m][1]][1] = (int)fmin((double)f[hhnext[m][1]][1], (double)(f[m][1] + delta_right_right));
        }
    }
    ans = starty + (int)fmin((double)f[0][0], (double)f[0][1]);
    printf("%d", ans);
    return 0;
}