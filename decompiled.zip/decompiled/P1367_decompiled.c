#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int pos;
    int p;
    int num;
    int ans;
}Ants;

int compare(const void *a, const void *b) ;
int main(int argc, const char **argv, const char **envp) ;
int compare(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;
    return value_a - value_b;
}
int main(int argc, const char **argv, const char **envp)
{
    Ants a[100];
    int order[100];
    int direction_input;
    int position_offset;
    int direction_output;
    int itb;
    int t;
    int n;
    int i_2;
    int i_1;
    int i_0;
    int i;

    scanf("%d %d", &n, &t);
    for ( i = 0; i < n; ++i )
    {
        scanf("%d %d", &a[i].pos, &itb);
        if ( itb == -1 )
            direction_input = 1;
        else
            direction_input = 2;
        a[i].p = direction_input;
        a[i].num = i + 1;
    }
    qsort(a, n, sizeof(Ants), compare);
    for ( i_0 = 0; i_0 < n; ++i_0 )
    {
        order[i_0] = a[i_0].num;
        if ( a[i_0].p == 1 )
            position_offset = -t;
        else
            position_offset = t;
        a[i_0].pos += position_offset;
    }
    qsort(a, n, sizeof(Ants), compare);
    for ( i_1 = 0; i_1 < n; ++i_1 )
    {
        a[i_1].num = order[i_1];
        a[i_1].ans = (i_1 > 0 && a[i_1].pos == a[i_1 - 1].pos) || (i_1 < n - 1 && a[i_1].pos == a[i_1 + 1].pos);
    }
    qsort(a, n, sizeof(Ants), compare);
    for ( i_2 = 0; i_2 < n; ++i_2 )
    {
        if ( a[i_2].ans == 1 )
        {
            printf("%d 0\n", a[i_2].pos);
        }
        else
        {
            if ( a[i_2].p == 1 )
                direction_output = -1;
            else
                direction_output = 1;
            printf("%d %d\n", a[i_2].pos, direction_output);
        }
    }
    return 0;
}