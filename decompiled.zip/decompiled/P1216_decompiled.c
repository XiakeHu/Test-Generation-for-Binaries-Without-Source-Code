#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>
#include <limits.h>

#define MAXN 1005
#define MAXM 1000005
#define INF 1061109567

typedef struct Front_star {
    int u;
    int v;
    int w;
    int c;
    int nxt;
} Edge;

typedef struct {
    int c;
    int num;
} Node;

int S, T;
int dis[MAXM];
bool inqueue[MAXM];
int first[MAXM];
int pre[MAXM];
int cnt = 0;
int m, n;
Node f[MAXN][MAXN];

bool SPFA(Edge *e);
void addedge(Edge *e, int u, int v, int c, int w);
void MCMF(Edge *e);
void add(Edge *e, int u, int v, int c, int w);
void solvec(Edge *e);

bool SPFA(Edge *e)
{
    int queue[10002];
    int current_node;
    int neighbor_node;
    int edge_index;
    int queue_front;
    int queue_rear;
    int node_index;

    for (node_index = S; node_index <= T; ++node_index)
        dis[node_index] = -INF;
    dis[S] = 0;
    queue_front = 0;
    queue_rear = 1;
    queue[0] = S;

    while (queue_front < queue_rear)
    {
        current_node = queue[queue_front++];
        inqueue[current_node] = 0;
        for (edge_index = first[current_node]; edge_index; edge_index = e[edge_index].nxt)
        {
            neighbor_node = e[edge_index].v;
            if (dis[neighbor_node] < dis[current_node] + e[edge_index].c && e[edge_index].w > 0)
            {
                dis[neighbor_node] = dis[current_node] + e[edge_index].c;
                pre[neighbor_node] = edge_index;
                if (!inqueue[neighbor_node])
                {
                    queue[queue_rear++] = neighbor_node;
                    inqueue[neighbor_node] = 1;
                }
            }
        }
    }
    return dis[T] != -INF;
}
void addedge(Edge *e, int u, int v, int c, int w)
{
    cnt++;
    e[cnt].u = u;
    e[cnt].v = v;
    e[cnt].w = w;
    e[cnt].c = c;
    e[cnt].nxt = first[u];
    first[u] = cnt;
}
void MCMF(Edge *e)
{
    int flow_increment;
    int edge_index;
    int reverse_edge_index;
    int min_capacity;
    int total_cost;

    total_cost = 0;
    while (SPFA(e))
    {
        min_capacity = INF;
        for (edge_index = pre[T]; edge_index != 0; edge_index = pre[e[edge_index ^ 1].v])
        {
            flow_increment = e[edge_index].w;
            if (min_capacity > flow_increment)
                min_capacity = flow_increment;
        }
        for (reverse_edge_index = pre[T]; reverse_edge_index != 0; reverse_edge_index = pre[e[reverse_edge_index ^ 1].v])
        {
            e[reverse_edge_index].w -= min_capacity;
            e[reverse_edge_index ^ 1].w += min_capacity;
        }
        total_cost += min_capacity * dis[T];
    }
    printf("max=%d\n", total_cost);
}
void add(Edge *e, int u, int v, int c, int w)
{
    addedge(e, u, v, c, w);
    addedge(e, v, u, -c, 0);
}
void solvec(Edge *e)
{
    int i;
    int j;
    int row;
    int col;
    int dm;

    dm = m;
    for (i = 1; i <= m; ++i)
        add(e, S, f[1][i].num, 0, 1);
    for (row = 1; row < n; ++row)
    {
        for (col = 1; col <= dm; ++col)
        {
            add(e, f[row][col].num, f[row + 1][col + 1].num, f[row][col].c, INF);
            add(e, f[row][col].num, f[row + 1][col].num, f[row][col].c, INF);
        }
        ++dm;
    }
    for (col = 1; col <= dm; ++col)
        add(e, f[n][col].num, T, f[n][col].c, INF);
    MCMF(e);
}
int main()
{
    int weight;
    Edge *edges;
    int j;
    int i;
    int current_width;
    int total_nodes;

    total_nodes = 1;
    scanf("%d", &n);
    m = 1;
    current_width = m;
    for (i = 1; i <= n; ++i)
    {
        for (j = 1; j <= current_width; ++j)
        {
            scanf("%d", &weight);
            f[i][j].c = weight;
            f[i][j].num = total_nodes++;
        }
        ++current_width;
    }
    S = 0;
    T = total_nodes;
    edges = (Edge *)calloc(1000000, sizeof(Edge));
    solvec(edges);
    free(edges);
    return 0;
}