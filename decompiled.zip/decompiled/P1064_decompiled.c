#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int v;
    int w;
    int q;
    int f1;
    int f2;
} node;

int max(int a, int b) ;
   int max(int a, int b) ;
int max(int a, int b)
{
    int result = a;
    if (b >= a)
    {
        result = b;
    }
    return result;
}
int main() {
    int n, m;
    node a[65];
    int dp[65][32005] = {0};
    int f2;
    int f1;
    int temp_value;
    int j;
    int i_0;
    int i;

    scanf("%d%d", &n, &m);
    for (i = 1; i <= m; ++i) {
        scanf("%d%d%d", &a[i].v, &a[i].w, &a[i].q);
        a[i].f1 = -1;
        a[i].f2 = -1;
        if (a[i].q) {
            if (a[a[i].q].f1 <= 0)
                a[a[i].q].f1 = i;
            else
                a[a[i].q].f2 = i;
        }
    }
    for (i_0 = 1; i_0 <= m; ++i_0) {
        for (j = 1; j <= n; ++j) {
            if (a[i_0].q <= 0) {
                f1 = a[i_0].f1;
                f2 = a[i_0].f2;
                temp_value = dp[i_0 - 1][j];
                if (j >= a[i_0].v)
                    temp_value = max(temp_value, dp[i_0 - 1][j - a[i_0].v] + a[i_0].v * a[i_0].w);
                if (f1 > 0 && j >= a[i_0].v + a[f1].v)
                    temp_value = max(temp_value, a[i_0].v * a[i_0].w + dp[i_0 - 1][j - a[i_0].v - a[f1].v] + a[f1].v * a[f1].w);
                if (f2 > 0 && j >= a[i_0].v + a[f2].v)
                    temp_value = max(temp_value, a[i_0].v * a[i_0].w + dp[i_0 - 1][j - a[i_0].v - a[f2].v] + a[f2].v * a[f2].w);
                if (f1 > 0 && f2 > 0 && j >= a[f1].v + a[i_0].v + a[f2].v)
                    temp_value = max(temp_value, a[f1].v * a[f1].w + a[i_0].v * a[i_0].w + dp[i_0 - 1][j - a[i_0].v - a[f1].v - a[f2].v] + a[f2].v * a[f2].w);
                dp[i_0][j] = temp_value;
            } else {
                dp[i_0][j] = dp[i_0 - 1][j];
            }
        }
    }
    printf("%d", dp[m][n]);
    return 0;
}