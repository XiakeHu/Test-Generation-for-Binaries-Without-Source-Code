#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

#define MAX_N 200005

int n, K;
long long HP[MAX_N];
long long hp[MAX_N];
long long c1[MAX_N], c2[MAX_N], c3[MAX_N], c4[MAX_N];

int read() {
    int x = 0, f = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9') {
        if (ch == '-') f = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9') {
        x = x * 10 + ch - '0';
        ch = getchar();
    }
    return x * f;
}

bool check(long long P) {
    int sqrt_P = (int)sqrt((double)P);
    int total_operations = 0;
    long long t1 = 0;
    long long t2 = 0;
    long long t3 = 0;
    long long t0 = 0;

    memset(c1, 0, sizeof(c1));
    memset(c2, 0, sizeof(c2));
    memset(c3, 0, sizeof(c3));
    memset(c4, 0, sizeof(c4));

    for (int i = 1; i <= n; ++i) {
        hp[n - i + 1] = HP[i];
    }

    for (int i = 1; i <= n; ++i) {
        t3 += c3[i];
        t2 += c2[i];
        t1 += c1[i] + t2;
        t0 += c4[i] + t1;

        hp[i] -= t3 * P - t0;

        if (hp[i] > 0) {
            int needed_operations = (hp[i] + P - 1) / P;
            total_operations += needed_operations;
            if (total_operations > K) {
                return false;
            }

            c3[i + 1] += needed_operations;
            int idx1 = (sqrt_P + i <= n) ? (i + sqrt_P + 1) : (n + 1);
            c3[idx1] -= needed_operations;

            c2[i + 1] += 2LL * needed_operations;
            int idx2 = (sqrt_P + i <= n) ? (i + sqrt_P + 1) : (n + 1);
            c2[idx2] -= 2 * needed_operations;

            c1[i + 1] -= needed_operations;
            int idx3 = (sqrt_P + i <= n) ? (i + sqrt_P + 1) : (n + 1);
            c1[idx3] -= needed_operations * (2LL * sqrt_P - 1);

            int idx4 = (sqrt_P + i <= n) ? (i + sqrt_P + 1) : (n + 1);
            c4[idx4] -= needed_operations * sqrt_P * (long long)sqrt_P;
        }
    }

    return total_operations <= K;
}
int main()
{
    long long ans;
    long long r;
    long long l;
    int i;

    n = read();
    K = read();
    for ( i = 1; i <= n; ++i )
    {
        HP[i] = read() + 1;
    }
    l = 1LL;
    r = 1000000000000000LL;
    ans = 1000000000000000LL;
    while ( l < r )
    {
        long long mid = (l + r) >> 1;
        if ( check(mid) )
        {
            ans = mid;
            r = ans;
        }
        else
        {
            l = mid + 1;
        }
    }
    printf("%lld", ans);
    return 0;
}