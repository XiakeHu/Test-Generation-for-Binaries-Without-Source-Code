#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

#define MAX_N 1000
#define MAX_LEN 50
#define ALPHABET 26

int n, ptr, head;
int rudu[ALPHABET];
int chudu[ALPHABET];
bool vis[MAX_N + 1];
bool exist[ALPHABET];
int set[ALPHABET];
char st[(MAX_N + 1) * MAX_LEN];

struct Edge {
    int s, t;
} e[MAX_N * 2];
int p1;

int find(int x);
void add(int a, int b);
void dfs(int now);
bool judge();
int main();

int find(int x)
{
    if (x == set[x])
        return x;
    set[x] = find(set[x]);
    return set[x];
}

void add(int a, int b)
{
    e[++p1].s = a;
    e[p1].t = b;
}

void dfs(int now)
{
    size_t length;
    int i;

    for (i = 1; i <= n; ++i)
    {
        if (!vis[i] && now == st[MAX_LEN * i] - 'a')
        {
            vis[i] = 1;
            length = strlen(&st[MAX_LEN * i]);
            dfs(st[MAX_LEN * i + length - 1] - 'a');
            ++ptr;
            strcpy(&st[MAX_LEN * ptr], &st[MAX_LEN * i]);
        }
    }
}

bool judge()
{
    int fb;
    int fa;
    int b;
    int i_1;
    int i_0;
    int cnt;
    int i;

    for (i = 0; i < ALPHABET; ++i)
        set[i] = i;
    cnt = 0;
    for (i_0 = 1; i_0 <= p1; ++i_0)
    {
        b = e[i_0].t;
        fa = find(e[i_0].s);
        fb = find(b);
        if (fa != fb)
            set[fa] = fb;
    }
    for (i_1 = 0; i_1 < ALPHABET; ++i_1)
    {
        if (exist[i_1] && i_1 == set[i_1])
            ++cnt;
    }
    return cnt == 1;
}

int main()
{
    int i, i0, i1, i2, i3;
    int cnt;
    int a, b;
    int diff;

    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
        scanf("%s", &st[MAX_LEN * i]);

    qsort(&st[MAX_LEN], n, MAX_LEN, (int (*)(const void *, const void *))strcmp);

    p1 = 0;
    ptr = 0;
    head = -1;
    memset(rudu, 0, sizeof(rudu));
    memset(chudu, 0, sizeof(chudu));
    memset(vis, 0, sizeof(vis));
    memset(exist, 0, sizeof(exist));

    for (i0 = 1; i0 <= n; ++i0)
    {
        a = st[MAX_LEN * i0] - 'a';
        b = st[MAX_LEN * i0 + strlen(&st[MAX_LEN * i0]) - 1] - 'a';

        if (!exist[a])
            exist[a] = 1;
        if (!exist[b])
            exist[b] = 1;

        add(a, b);

        ++rudu[b];
        ++chudu[a];
    }

    if (!judge())
    {
        printf("***");
        return 0;
    }

    cnt = 0;
    for (i1 = 0; i1 < ALPHABET; ++i1)
    {
        diff = chudu[i1] - rudu[i1];
        if (diff < 0)
            diff = -diff;

        if (diff > 0)
        {
            ++cnt;
            if (diff > 1)
            {
                printf("***");
                return 0;
            }
            if (chudu[i1] - rudu[i1] == 1 && head == -1)
                head = i1;
        }
    }

    if (cnt != 0 && cnt != 2)
    {
        printf("***");
        return 0;
    }

    if (cnt == 2)
    {
        dfs(head);
    }
    else
    {
        for (i2 = 0; i2 < ALPHABET; ++i2)
        {
            if (exist[i2])
                dfs(i2);
        }
    }

    for (i3 = ptr; i3 > 0; --i3)
    {
        printf("%s", &st[MAX_LEN * i3]);
        if (i3 > 1)
            putchar('.');
    }

    return 0;
}