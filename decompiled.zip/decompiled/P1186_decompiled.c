#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct edge {
    int to;
    int nxt;
    int l;
} edge;

int cnt_0;

void addedge(edge *e, int *head, int u, int v, int x);
int main();
int read();

void addedge(edge *e, int *head, int u, int v, int x)
{
    int edge_index = ++cnt_0;
    e[edge_index].to = v;
    e[edge_index].nxt = head[u];
    e[edge_index].l = x;
    head[u] = edge_index;
}

int main()
{
    int node_count;
    int edge_count;
    int u;
    int v;
    int weight;
    int *head;
    edge *edges;
    int i;
    int j;

    scanf("%d %d", &node_count, &edge_count);
    edges = (edge *)malloc(sizeof(edge) * (2 * edge_count + 1));
    head = (int *)malloc(sizeof(int) * (node_count + 1));
    for (i = 1; i <= node_count; ++i)
        head[i] = -1;
    for (j = 1; j <= edge_count; ++j)
    {
        scanf("%d %d %d", &u, &v, &weight);
        addedge(edges, head, u, v, weight);
        addedge(edges, head, v, u, weight);
    }
    return 0;
}

int read()
{
    char current_char;
    int sign;
    int value;

    value = 0;
    sign = 1;
    current_char = getchar();
    while (current_char <= 47 || current_char > 57) {
        if (current_char == '-') {
            sign = -1;
        }
        current_char = getchar();
    }
    while (current_char > 47 && current_char <= 57) {
        value = 10 * value + current_char - '0';
        current_char = getchar();
    }
    return sign * value;
}