#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

typedef struct {
    int x;
    int y;
} Airport;

typedef struct {
    int nAirports_;
    Airport *airports_;
    int *cost_train_;
    int cost_air_;
} CarRoute;

int square(int x);
float getAirportDist(Airport a, Airport b);
float dijkstra(CarRoute *carRoute, int src_city, int des_city);
void solve(CarRoute *carRoute);
int main();

int square(int x)
{
    return x * x;
}
float getAirportDist(Airport a, Airport b)
{
    int dx_squared = square(a.x - b.x);
    int dy_squared = square(a.y - b.y);
    return (float)sqrt((double)(dx_squared + dy_squared));
}
float dijkstra(CarRoute *carRoute, int src_city, int des_city)
{
    int num_airports = carRoute->nAirports_;
    float *cost = (float *)malloc(sizeof(float) * num_airports);
    bool *collected = (bool *)malloc(sizeof(bool) * num_airports);

    for (int i = 0; i < num_airports; ++i)
    {
        cost[i] = -1.0f;
        collected[i] = false;
    }

    for (int i = 0; i < 4; ++i)
    {
        cost[4 * src_city + i] = 0.0f;
    }

    while (1)
    {
        int min_vertex = -1;
        float min_cost = -1.0f;

        for (int i = 0; i < num_airports; ++i)
        {
            if (!collected[i] && cost[i] != -1.0f && (min_cost > cost[i] || min_cost == -1.0f))
            {
                min_vertex = i;
                min_cost = cost[i];
            }
        }

        int min_city = min_vertex / 4;
        if (min_city == des_city)
        {
            free(cost);
            free(collected);
            return min_cost;
        }

        if (min_vertex == -1)
        {
            break;
        }

        collected[min_vertex] = true;

        for (int i = 0; i < num_airports; ++i)
        {
            if (!collected[i])
            {
                Airport airport_i = carRoute->airports_[i];
                Airport airport_min = carRoute->airports_[min_vertex];
                float dist = getAirportDist(airport_min, airport_i);

                int cost_per_unit;
                if (min_city == i / 4)
                {
                    cost_per_unit = carRoute->cost_train_[min_city];
                }
                else
                {
                    cost_per_unit = carRoute->cost_air_;
                }

                float new_cost = min_cost + (float)cost_per_unit * dist;

                if (cost[i] > new_cost || cost[i] == -1.0f)
                {
                    cost[i] = new_cost;
                }
            }
        }
    }

    free(cost);
    free(collected);
    return -1.0f;
}
void solve(CarRoute *carRoute)
{
    int nCities;
    int src_city;
    int des_city;
    int ax, ay, bx, by, cx, cy;
    int dx, dy;
    int abSquare, acSquare, bcSquare;
    float minCost;
    int i;

    scanf("%d %d %d %d", &nCities, &carRoute->cost_air_, &src_city, &des_city);
    --src_city;
    --des_city;

    carRoute->nAirports_ = 4 * nCities;
    carRoute->airports_ = (Airport *)malloc(sizeof(Airport) * carRoute->nAirports_);
    carRoute->cost_train_ = (int *)malloc(sizeof(int) * nCities);

    for (i = 0; i < nCities; ++i)
    {
        scanf("%d %d %d %d %d %d %d", &ax, &ay, &bx, &by, &cx, &cy, &carRoute->cost_train_[i]);

        carRoute->airports_[4 * i].x = ax;
        carRoute->airports_[4 * i].y = ay;
        carRoute->airports_[4 * i + 1].x = bx;
        carRoute->airports_[4 * i + 1].y = by;
        carRoute->airports_[4 * i + 2].x = cx;
        carRoute->airports_[4 * i + 2].y = cy;

        abSquare = square(ax - bx) + square(ay - by);
        acSquare = square(ax - cx) + square(ay - cy);
        bcSquare = square(bx - cx) + square(by - cy);

        if (abSquare == acSquare + bcSquare)
        {
            dx = ax + bx - cx;
            dy = ay + by - cy;
        }
        else if (acSquare == abSquare + bcSquare)
        {
            dx = ax + cx - bx;
            dy = ay + cy - by;
        }
        else
        {
            dx = bx + cx - ax;
            dy = by + cy - ay;
        }

        carRoute->airports_[4 * i + 3].x = dx;
        carRoute->airports_[4 * i + 3].y = dy;
    }

    minCost = dijkstra(carRoute, src_city, des_city);
    printf("%.1f\n", minCost);

    free(carRoute->airports_);
    free(carRoute->cost_train_);
}
int main()
{
    int testCaseCount;
    CarRoute carRoute;
    int i;

    scanf("%d", &testCaseCount);
    for (i = 0; i < testCaseCount; ++i)
        solve(&carRoute);
    return 0;
}