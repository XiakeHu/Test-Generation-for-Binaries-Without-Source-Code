#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int N, M;
int *finger;
int *vis;

int ad(int poi);
void prin();
int main();

int ad(int poi)
{
    int current_index;
    
    for (current_index = poi + 1; current_index <= N; ++current_index)
    {
        if (!vis[current_index])
            return current_index;
    }
    return -1;
}

void prin()
{
    int i;
    
    for (i = 1; i <= N; ++i)
        printf("%d ", finger[i]);
    putchar('\n');
}

int main()
{
    int k;
    int p;
    int j;
    int i_0;
    int i;

    scanf("%d%d", &N, &M);
    finger = (int*)malloc((N + 1) * sizeof(int));
    vis = (int*)malloc((N + 1) * sizeof(int));
    if ( finger && vis )
    {
        for ( i = 1; i <= N; ++i )
        {
            vis[i] = 1;
            scanf("%d", &finger[i]);
        }
LABEL_21:
        while ( M-- )
        {
            for ( i_0 = N; i_0 > 0; --i_0 )
            {
                k = ad(finger[i_0]);
                if ( k != -1 )
                {
                    vis[finger[i_0]] = 0;
                    finger[i_0] = k;
                    vis[k] = 1;
                    for ( j = i_0 + 1; j <= N; ++j )
                    {
                        for ( p = 1; p <= N; ++p )
                        {
                            if ( !vis[p] )
                            {
                                finger[j] = p;
                                vis[p] = 1;
                                break;
                            }
                        }
                    }
                    goto LABEL_21;
                }
                vis[finger[i_0]] = 0;
            }
        }
        prin();
        free(finger);
        free(vis);
        return 0;
    }
    else
    {
        puts("Memory allocation failed");
        return 1;
    }
}