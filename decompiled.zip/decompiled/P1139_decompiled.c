#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_N 50

typedef struct {
    char h;
    char from;
    char to;
} ss;

char a[MAX_N];
char b[MAX_N];
char c[MAX_N];
char d[MAX_N];
int f[30];
ss res[MAX_N * MAX_N];
ss ans[MAX_N * MAX_N];
int n;
int tot;
int p;

void change(char q, int *fro, int *too, int *t);
int find(char s);
void pd(int *topa, int *topb, int *topc, int *topd, int *t);
void solve(int topa, int topb, int topc, int topd, int t);

void change(char q, int *fro, int *too, int *t)
{
    char selected_char;

    if (q == 'A')
    {
        selected_char = a[*fro];
    }
    else if (q == 'B')
    {
        selected_char = b[*fro];
    }
    else
    {
        selected_char = c[*fro];
    }

    ++*too;
    --*fro;

    res[*t].h = selected_char;
    res[*t].from = q;
    res[*t].to = 'D';
}

int find(char s)
{
    if (s == '0')
    {
        return 27;
    }
    else
    {
        return f[s - '`'];
    }
}

void pd(int *topa, int *topb, int *topc, int *topd, int *t)
{
    ss *dest_entry;
    int i;
    bool flag;

    flag = 1;
    while (flag)
    {
        flag = 0;
        if (*topd > n)
        {
            if (*t < tot)
            {
                tot = *t;
                p = 1;
                for (i = 1; i <= tot; ++i)
                {
                    dest_entry = &ans[i];
                    dest_entry->h = res[i].h;
                    dest_entry->from = res[i].from;
                    dest_entry->to = res[i].to;
                }
            }
            return;
        }
        if (a[*topa] == d[*topd])
        {
            ++*t;
            change('A', topa, topd, t);
            flag = 1;
        }
        if (b[*topb] == d[*topd])
        {
            ++*t;
            change('B', topb, topd, t);
            flag = 1;
        }
        if (c[*topc] == d[*topd])
        {
            ++*t;
            change('C', topc, topd, t);
            flag = 1;
        }
    }
}

void solve(int topa, int topb, int topc, int topd, int t)
{
    int current_topa = topa;
    int current_topb = topb;
    int current_topc = topc;
    int current_topd = topd;
    int current_t = t;

    pd(&current_topa, &current_topb, &current_topc, &current_topd, &current_t);

    ++current_t;

    for (int i = 1; i <= 3; ++i)
    {
        if (i == 1)
        {
            if (current_topa > 0)
            {
                res[current_t].h = a[current_topa];
                res[current_t].from = 'A';
                res[current_t].to = 'B';

                char backup_b[MAX_N];
                for (int j = 0; j <= n; ++j)
                    backup_b[j] = b[j];

                b[++current_topb] = a[current_topa];
                solve(--current_topa, current_topb, current_topc, current_topd, current_t);

                for (int j = 0; j <= n; ++j)
                    b[j] = backup_b[j];

                ++current_topa;
                --current_topb;
            }
        }
        else if (i == 2)
        {
            if (current_topa > 0)
            {
                int value_a = find(a[current_topa]);
                int value_c = find(c[current_topc]);

                if (value_a < value_c)
                {
                    res[current_t].h = a[current_topa];
                    res[current_t].from = 'A';
                    res[current_t].to = 'C';

                    char backup_c[MAX_N];
                    for (int j = 0; j <= n; ++j)
                        backup_c[j] = c[j];

                    c[++current_topc] = a[current_topa];
                    solve(--current_topa, current_topb, current_topc, current_topd, current_t);

                    for (int j = 0; j <= n; ++j)
                        c[j] = backup_c[j];

                    ++current_topa;
                    --current_topc;
                }
            }
        }
        else if (i == 3)
        {
            if (current_topb > 0)
            {
                int value_b = find(b[current_topb]);
                int value_c = find(c[current_topc]);

                if (value_b < value_c)
                {
                    res[current_t].h = b[current_topb];
                    res[current_t].from = 'B';
                    res[current_t].to = 'C';

                    char backup_b2[MAX_N];
                    for (int j = 0; j <= n; ++j)
                        backup_b2[j] = b[j];

                    char backup_c2[MAX_N];
                    for (int j = 0; j <= n; ++j)
                        backup_c2[j] = c[j];

                    c[++current_topc] = b[current_topb];
                    solve(current_topa, --current_topb, current_topc, current_topd, current_t);

                    for (int j = 0; j <= n; ++j)
                        b[j] = backup_b2[j];

                    for (int j = 0; j <= n; ++j)
                        c[j] = backup_c2[j];

                    ++current_topb;
                    --current_topc;
                }
            }
        }
    }
}

int main()
{
    char input_char;
    int i;
    int j;
    int k;

    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
    {
        scanf(" %c", &input_char);
        d[n - i + 1] = input_char;
        a[i] = i + 96;
    }
    for (j = 1; j <= n; ++j)
        f[d[j] - 96] = j;
    tot = 1000000000;
    a[0] = '0';
    b[0] = '0';
    c[0] = '0';
    int topa = n;
    int topc = 0;
    int topb = 0;
    int topd = 1;
    p = 0;
    solve(topa, topb, topc, topd, 0);
    if (!p)
    {
        printf("NO");
    }
    else
    {
        for (k = 1; k <= tot; ++k)
            printf("%c %c %c\n", ans[k].h, ans[k].from, ans[k].to);
    }
    return 0;
}