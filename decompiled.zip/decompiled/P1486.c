#include <stdio.h>
#include <stdlib.h>

#define MAXN 2000005
const int MODS = 5371321, PRI = 832211;
int cnt, tot;
int tree[MAXN][2], size[MAXN], wv[MAXN], num[MAXN];

inline int rand_val(){
    static int sed = 15;
    return sed = (sed * PRI) % MODS;
}

void Updata(int node){
    size[node] = size[tree[node][0]] + size[tree[node][1]] + 1;
}

int Rotate(int node, int son){
    int child = tree[node][son];
    tree[node][son] = tree[child][son ^ 1];
    tree[child][son ^ 1] = node;
    Updata(node);
    Updata(child);
    return child;
}

int Insert(int tar, int node){
    if(!node){
        node = ++cnt;
        size[node] = 1;
        wv[node] = rand_val();
        num[node] = tar;
        return node;
    }
    size[node]++;
    if(tar <= num[node]) tree[node][0] = Insert(tar, tree[node][0]);
    else tree[node][1] = Insert(tar, tree[node][1]);
    if(tree[node][0] && wv[tree[node][0]] > wv[node]) node = Rotate(node, 0);
    else if(tree[node][1] && wv[tree[node][1]] > wv[node]) node = Rotate(node, 1);
    return node;
}

int Delete_Lower_Bound(int tar, int node){
    if(!node) return 0;
    if(num[node] < tar){
        return Delete_Lower_Bound(tar, tree[node][1]);
    } else {
        tree[node][0] = Delete_Lower_Bound(tar, tree[node][0]);
        Updata(node);
        return node;
    }
}

int Get_Kth(int k, int node){
    int left_size = size[tree[node][0]];
    if(left_size == k - 1) return num[node];
    if(left_size >= k) return Get_Kth(k, tree[node][0]);
    return Get_Kth(k - left_size - 1, tree[node][1]);
}

int main(){
    int m, min_m, loc = 0;
    if(scanf("%d %d", &m, &min_m) != 2) return 0;
    for(int i = 1; i <= m; i++){
        char cons[2];
        int tar;
        if(scanf("%s %d", cons, &tar) != 2) break;
        if(cons[0] == 'I'){
            if(tar >= min_m) tot = Insert(tar - loc, tot);
         } else if(cons[0] == 'A') {
            loc += tar;
         } else if(cons[0] == 'S'){
            loc -= tar;
            int tmp = loc - min_m;
            tot = Delete_Lower_Bound(-tmp, tot);
         } else {
            printf("%d\n", size[tot] >= tar ? Get_Kth(size[tot] - tar + 1, tot) + loc : -1);
         }
     }
    return 0;
}