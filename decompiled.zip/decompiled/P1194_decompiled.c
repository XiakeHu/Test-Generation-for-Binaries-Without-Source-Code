#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int from;
    int to;
    int dis;
} edge;

int fa[3005];
int A, B, m;

int find(int son) ;
int compare_edges(const void *a, const void *b) ;
void add_edge(int from, int to, int dis, int index, edge *Edge) ;
int kruscal(edge *Edge) ;

int find(int son)
{
    if (son == fa[son])
        return son;
    fa[son] = find(fa[son]);
    return fa[son];
}

int compare_edges(const void *a, const void *b)
{
    const edge *edge_a = (const edge *)a;
    const edge *edge_b = (const edge *)b;
    return edge_a->dis - edge_b->dis;
}

void add_edge(int from, int to, int dis, int index, edge *Edge)
{
    edge *target_edge = &Edge[index];
    target_edge->from = from;
    target_edge->to = to;
    target_edge->dis = dis;
}

int kruscal(edge *Edge)
{
    int i;
    int ft;
    int ff;
    int cnt;
    int ans;

    ans = 0;
    cnt = 0;
    for ( i = 1; i <= m && cnt < B; ++i )
    {
        ff = find(Edge[i].from);
        ft = find(Edge[i].to);
        if ( ff != ft )
        {
            fa[ft] = ff;
            ++cnt;
            ans += Edge[i].dis;
        }
    }
    return ans;
}

int main()
{
    int i, j, k, n;
    int dis;
    edge *Edge;
    int result;

    scanf("%d %d", &A, &B);

    for (i = 1; i <= B + 1; ++i)
        fa[i] = i;

    Edge = (edge *)malloc(sizeof(edge) * (B * (B - 1) / 2 + B + 5));
    m = 0;

    for (j = 1; j <= B; ++j)
    {
        for (k = 1; k <= j; ++k)
            scanf("%*d");

        for (k = j + 1; k <= B; ++k)
        {
            scanf("%d", &dis);
            if (dis != 0)
            {
                m++;
                add_edge(j, k, dis, m, Edge);
            }
        }
    }

    for (n = 1; n <= B; ++n)
    {
        m++;
        add_edge(B + 1, n, A, m, Edge);
    }

    qsort(Edge + 1, m, sizeof(edge), compare_edges);
    result = kruscal(Edge);
    printf("%d", result);

    free(Edge);
    return 0;
}