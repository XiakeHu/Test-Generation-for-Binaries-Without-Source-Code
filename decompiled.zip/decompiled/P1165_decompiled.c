#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int* data;
    int size;
    int capacity;
} VectorInt;

void vectorInit(VectorInt *vec, size_t initSize);
void vectorPushBack(VectorInt *vec, int value);
void vectorPopBack(VectorInt *vec);

void vectorPushBack(VectorInt *vec, int value)
{
    if (vec->size >= vec->capacity) {
        vec->capacity *= 2;
        vec->data = (int *)realloc(vec->data, sizeof(int) * vec->capacity);
    }
    vec->data[vec->size] = value;
    vec->size++;
}
void vectorPopBack(VectorInt *vec)
{
    if (vec->size != 0)
    {
        --vec->size;
    }
}
void vectorInit(VectorInt *vec, size_t initSize)
{
    vec->data = (int *)malloc(sizeof(int) * initSize);
    vec->size = 0;
    vec->capacity = initSize;
}
int main()
{
    int push_value;
    int operation;
    int n;
    VectorInt stack;
    int temp_value;
    int i;

    vectorInit(&stack, 100);
    scanf("%d", &n);
    for (i = 0; i < n; ++i)
    {
        scanf("%d", &operation);
        if (operation)
        {
            if (operation == 1)
            {
                vectorPopBack(&stack);
            }
            else if (operation == 2)
            {
                if (stack.size)
                    printf("%d\n", stack.data[stack.size - 1]);
                else
                    puts("0");
            }
        }
        else
        {
            scanf("%d", &push_value);
            temp_value = push_value;
            vectorPushBack(&stack, push_value);
        }
    }
    free(stack.data);
    return 0;
}