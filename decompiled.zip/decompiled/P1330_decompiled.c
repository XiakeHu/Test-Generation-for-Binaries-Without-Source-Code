#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define MAXN 2005

int fa[MAXN * 2];
int x[MAXN * MAXN];
int y[MAXN * MAXN];
int bj[MAXN * 2];
int n, m;

int find(int now) ;
void unity(int a, int b) ;
int main() ;

int find(int now)
{
    if (now == fa[now])
        return now;
    int parent = find(fa[now]);
    fa[now] = parent;
    return parent;
}
void unity(int a, int b)
{
    int root_a;
    int root_b;

    root_a = find(a);
    root_b = find(b);
    fa[root_a] = root_b;
}
int main()
{
    int i;
    int j;
    int root_x;
    int root_y;
    int root_x2;
    int root_y2;
    int component_size_x;
    int component_size_y;
    int size_x;
    int size_y;
    int min_size;
    int answer = 0;

    scanf("%d%d", &n, &m);
    for (i = 1; i <= 2 * n; ++i)
        fa[i] = i;

    for (i = 1; i <= m; ++i)
    {
        scanf("%d%d", &x[i], &y[i]);
        root_x = find(x[i]);
        root_y = find(y[i]);
        if (root_x == root_y)
        {
            printf("Impossible");
            exit(0);
        }
        unity(x[i] + n, y[i]);
        unity(x[i], y[i] + n);
    }

    memset(bj, 1, sizeof(bj));
    for (i = 1; i <= m; ++i)
    {
        root_x2 = find(x[i]);
        root_y2 = find(y[i]);
        if (bj[root_x2] && bj[root_y2])
        {
            bj[root_x2] = 0;
            bj[root_y2] = 0;
            component_size_x = 0;
            component_size_y = 0;
            for (j = 1; j <= n; ++j)
            {
                if (root_x2 == find(j))
                {
                    ++component_size_x;
                }
                else if (root_y2 == find(j))
                {
                    ++component_size_y;
                }
            }
            size_x = component_size_x;
            size_y = component_size_y;
            min_size = size_x;
            if (size_y < min_size)
                min_size = size_y;
            answer += min_size;
        }
    }
    printf("%d", answer);
    return 0;
}