#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int l, r;
char password[100] = { '#','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1','2','3','4','5','6','7','8','9','0',';',':','.','(','?','<','>','[',']','{','}'};
int change[260];

char C(int x){
    return password[x];
}

int X(char c){
    return change[c];
}

int get(int x){
    for(int i = 2;i * i <= x;i++){
        if(x % i == 0) return i;
     }
    return x;
}

int calc(int x){
    int total = 1,cnt = 0;
    while(x != 1){
        int p = get(x);
        cnt = 0;
        while(x % p == 0){
            x /= p;
            cnt++;
         }
        total *= (cnt + 1);
     }
    return total;
}

int from(int x){
    return  ((x) % 94866 == 0) ? ((x) / 94866) : ((x) / 94866 + 1);
}

#define L(x) (((x) - 1) * 94866 + 1)
#define R(x) ((x) * 94866)

int compare_ints(const void* a, const void* b){
    int arg1 = *(const int*)a;
    int arg2 = *(const int*)b;
    
    if (arg1 < arg2) return -1;
    if (arg1 > arg2) return 1;
    return 0;
}

int main(){
    for(int i = 0;i <= 74;i++){
        change[password[i]] = i;
     }
    
    int id = 1,ans = 1;
    scanf("%d%d",&l,&r);
    int x = from(l),y = from(r);
    
    if(x == y){
        for(int i = l;i <= r;i++){
            int tmp = calc(i);
            if(tmp > ans){
                id = i;
                ans = tmp;
             }
         }
        
        printf("Between %d and %d, %d has a maximum of %d divisors.",l,r,id,ans);
        return 0;
     }
    
    for(int i = l;i <= R(x);i++){
        int tmp = calc(i);
        if(tmp > ans){
            id = i;
            ans = tmp;
         }
     }
    
    for(int i = L(y);i <= r;i++){
        int tmp = calc(i);
        if(tmp > ans){
            id = i;
            ans = tmp;
         }
     }
    
    for(int i = x + 1;i <= y - 1;i++){
        int Z = X(password[3 * i - 2]) * 5476 + X(password[3 * i - 1]) * 74 + X(password[3 * i]);
        int Q = L(i) + Z;
        int tmp = calc(Q);
        
        if(tmp > ans){
            id = Q;
            ans = tmp;
         }
     }
    
    printf("Between %d and %d, %d has a maximum of %d divisors.",l,r,id,ans);
    return 0;
}