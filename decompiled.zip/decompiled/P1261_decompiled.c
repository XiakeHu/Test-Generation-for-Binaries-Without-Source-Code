#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define MAXN 30010
#define MAXM 60020
#define INF 1061109567

typedef struct {
    int to, v;
} Edge;

Edge edge[MAXM];
int m_0;
int G[MAXN][51];
int vis[MAXN];
int dis[MAXN];
int ok[MAXN];
int ans;
int far[12][MAXN];
int r[MAXN];
int o_edge[12][MAXN];
int n, m;
int u, v, t;

void add_edge(int from, int to, int v);
void spfa(int x);
void o_spfa(int x);
void wk(int x);

void add_edge(int from, int to, int val)
{
    int edge_index;
    int adjacency_count;

    edge[m_0].to = to;
    edge[m_0].v = val;
    edge_index = m_0;
    m_0++;
    adjacency_count = G[from][0];
    G[from][0] = adjacency_count + 1;
    G[from][adjacency_count + 1] = edge_index;

    edge[m_0].to = from;
    edge[m_0].v = val;
    edge_index = m_0;
    m_0++;
    adjacency_count = G[to][0];
    G[to][0] = adjacency_count + 1;
    G[to][adjacency_count + 1] = edge_index;
}
void spfa(int x)
{
    int queue[30011];
    int front = 0;
    int rear = 0;
    int current_node;
    int neighbor_index;
    Edge neighbor_edge;

    memset(vis, 0, sizeof(vis));
    for (int i = 1; i <= n; ++i)
        dis[i] = INF;
    memset(ok, 0, sizeof(ok));

    dis[x] = 0;
    vis[x] = 1;
    queue[rear++] = x;

    while (front < rear)
    {
        current_node = queue[front++];
        vis[current_node] = 0;

        if (!ok[current_node])
        {
            ++ans;
            ok[current_node] = 1;
        }

        for (neighbor_index = 1; neighbor_index <= G[current_node][0]; ++neighbor_index)
        {
            neighbor_edge = edge[G[current_node][neighbor_index]];
            if (dis[neighbor_edge.to] > dis[current_node] + neighbor_edge.v)
            {
                dis[neighbor_edge.to] = dis[current_node] + neighbor_edge.v;
                if (!vis[neighbor_edge.to] && dis[neighbor_edge.to] < far[r[x] + 1][neighbor_edge.to])
                {
                    queue[rear++] = neighbor_edge.to;
                    vis[neighbor_edge.to] = 1;
                }
            }
        }
    }
}
void o_spfa(int x)
{
    int queue[30010];
    int front = 0;
    int rear = -1;
    int current_node;
    int i, j;
    Edge next_edge;

    memset(vis, 0, sizeof(vis));
    for (i = 1; i <= n; ++i)
        far[x][i] = INF;

    for (i = 1; i <= o_edge[x][0]; ++i)
    {
        int neighbor = o_edge[x][i];
        far[x][neighbor] = 0;
        queue[++rear] = neighbor;
        vis[neighbor] = 1;
    }

    while (front <= rear)
    {
        current_node = queue[front++];
        vis[current_node] = 0;

        for (j = 1; j <= G[current_node][0]; ++j)
        {
            next_edge = edge[G[current_node][j]];
            int new_distance = far[x][current_node] + next_edge.v;

            if (new_distance < far[x][next_edge.to])
            {
                far[x][next_edge.to] = new_distance;

                if (!vis[next_edge.to])
                {
                    vis[next_edge.to] = 1;
                    queue[++rear] = next_edge.to;
                }
            }
        }
    }
}
void wk(int x)
{
    int i;
    for (i = 1; i <= n; ++i)
    {
        if (far[x][i] > far[x + 1][i])
        {
            far[x][i] = far[x + 1][i];
        }
    }
}
int main()
{
    int i;
    int j;
    int k;
    int l;

    scanf("%d%d", &n, &m);
    for (i = 1; i <= n; ++i)
    {
        scanf("%d", &r[i]);
        int region = r[i];
        o_edge[region][++o_edge[region][0]] = i;
    }
    for (j = 1; j <= m; ++j)
    {
        scanf("%d%d%d", &u, &v, &t);
        add_edge(u, v, t);
    }
    for (k = 1; k <= 10; ++k)
        o_spfa(k);
    for (l = 9; l > 0; --l)
        wk(l);
    for (i = 1; i <= n; ++i)
        spfa(i);
    printf("%d", ans);
    return 0;
}