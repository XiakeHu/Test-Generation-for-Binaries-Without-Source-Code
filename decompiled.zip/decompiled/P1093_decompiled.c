#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int chines;
    int math;
    int eng;
    int sum;
    int num;
}node;

int compare(const void *a, const void *b) ;
   int compare(const void *a, const void *b) ;
int compare(const void *a, const void *b)
{
    const node *node_a = (const node *)a;
    const node *node_b = (const node *)b;

    if (node_a->sum != node_b->sum)
        return node_b->sum - node_a->sum;

    if (node_a->chines == node_b->chines)
        return node_a->num - node_b->num;

    return node_b->chines - node_a->chines;
}
int main()
{
    int i;
    int j;
    int n;
    node stu[1000];

    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
    {
        scanf("%d %d %d", &stu[i].chines, &stu[i].math, &stu[i].eng);
        stu[i].sum = stu[i].chines + stu[i].math + stu[i].eng;
        stu[i].num = i;
    }
    qsort(&stu[1], n, sizeof(node), compare);
    for (j = 1; j <= 5 && j <= n; ++j)
        printf("%d %d\n", stu[j].num, stu[j].sum);
    return 0;
}