#include <stdio.h>
#include <stdbool.h>
#include <string.h>

typedef struct {
    int x;
    int y;
} Point;

int n, m;
int book[105][105];
int f[105][105];
Point s, t, p;
Point st[10005];
int top = -1;
int pre = 0;
Point direction_vectors[4];

void print_point(const Point *point);
Point add_points(const Point *a, const Point *b);
bool equal_points(const Point *a, const Point *b);
void scan_point(Point *a);
void dfs(Point current_point);

void print_point(const Point *point)
{
    printf("(%d, %d)", point->x, point->y);
}

Point add_points(const Point *a, const Point *b)
{
    Point result;
    Point null_point = {0, 0};

    result.x = a->x + b->x;
    result.y = a->y + b->y;

    if (result.x > 0 && result.x <= n && result.y > 0 && result.y <= m && !book[result.x][result.y] && f[result.x][result.y])
    {
        return result;
    }
    else
    {
        return null_point;
    }
}

bool equal_points(const Point *a, const Point *b)
{
    return a->x == b->x && a->y == b->y;
}

void scan_point(Point *a)
{
    scanf("%d %d", &a->x, &a->y);
}

void dfs(Point current_point)
{
    Point temp_point;
    int direction_index;
    int path_index;

    temp_point = current_point;
    if (!equal_points(&temp_point, &p))
    {
        st[++top] = temp_point;
        book[temp_point.x][temp_point.y] = 1;
        if (equal_points(&temp_point, &t))
        {
            pre = 1;
            print_point(&st[0]);
            for (path_index = 1; path_index <= top; ++path_index)
            {
                printf("->");
                print_point(&st[path_index]);
            }
            putchar('\n');
            book[temp_point.x][temp_point.y] = 0;
            --top;
        }
        else
        {
            for (direction_index = 0; direction_index <= 3; ++direction_index)
            {
                Point next_point = add_points(&temp_point, &direction_vectors[direction_index]);
                dfs(next_point);
            }
            book[temp_point.x][temp_point.y] = 0;
            --top;
        }
    }
}

int main()
{
    int row_index;
    int col_index;

    direction_vectors[0].x = 0;
    direction_vectors[0].y = -1;
    direction_vectors[1].x = -1;
    direction_vectors[1].y = 0;
    direction_vectors[2].x = 0;
    direction_vectors[2].y = 1;
    direction_vectors[3].x = 1;
    direction_vectors[3].y = 0;

    scanf("%d %d", &n, &m);
    for (row_index = 1; row_index <= n; ++row_index)
    {
        for (col_index = 1; col_index <= m; ++col_index)
        {
            scanf("%d", &f[row_index][col_index]);
            book[row_index][col_index] = 0;
        }
    }

    scan_point(&s);
    scan_point(&t);
    p.x = 0;
    p.y = 0;
    st[0] = s;
    top = 0;
    dfs(s);

    if (!pre)
    {
        printf("-1");
    }
    return 0;
}