#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n;
int i, j, sum;

int main()
{
    scanf("%d", &n);
    
    for (i = 1; i <= n / 2; ++i)
    {
        for (j = i + 1; j <= n / 2 + 1; ++j)
        {
            sum = (j + i) * (j - i + 1) / 2;
            if (sum == n)
                printf("%d %d\n", i, j);
            if (sum > n)
                break;
        }
    }
    return 0;
}