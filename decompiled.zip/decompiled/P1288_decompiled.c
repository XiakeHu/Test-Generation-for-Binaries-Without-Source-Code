#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

int n;
int a[100];

int next(int idx);
int prior(int idx);
bool dfs(int idx);
int main();

int next(int idx)
{
    if (idx == n - 1)
        return 0;
    else
        return idx + 1;
}
int prior(int idx)
{
    if (idx != 0)
    {
        return idx - 1;
    }
    else
    {
        return n - 1;
    }
}
bool dfs(int idx)
{
    if (!a[idx] && !a[prior(idx)])
        return false;
    if (a[idx] && !a[next(idx)])
        return true;
    if (a[prior(idx)] && !a[prior(prior(idx))])
        return true;

    if (a[idx])
    {
        if (a[prior(idx)])
        {
            int saved_current = a[idx];
            a[idx] = 0;
            if (!dfs(next(idx)))
            {
                a[idx] = saved_current;
                return true;
            }
            a[idx] = saved_current;

            int saved_prev = a[prior(idx)];
            a[prior(idx)] = 0;
            if (!dfs(prior(idx)))
            {
                a[prior(idx)] = saved_prev;
                return true;
            }
            a[prior(idx)] = saved_prev;

            for (int subtract_current = 1; subtract_current < a[idx]; ++subtract_current)
            {
                a[idx] -= subtract_current;
                if (!dfs(next(idx)))
                {
                    a[idx] += subtract_current;
                    return true;
                }
                a[idx] += subtract_current;
            }

            for (int subtract_prev = 1; subtract_prev < a[prior(idx)]; ++subtract_prev)
            {
                a[prior(idx)] -= subtract_prev;
                if (!dfs(prior(idx)))
                {
                    a[prior(idx)] += subtract_prev;
                    return true;
                }
                a[prior(idx)] += subtract_prev;
            }
            return false;
        }
        else
        {
            int forward_count = 0;
            for (int i = idx; a[i]; i = next(i))
                ++forward_count;
            return (forward_count & 1) != 0;
        }
    }
    else
    {
        int backward_count = 0;
        for (int i = prior(idx); a[i]; i = prior(i))
            ++backward_count;
        return (backward_count & 1) != 0;
    }
}
int main()
{
    int i;

    scanf("%d", &n);
    for (i = 0; i < n; ++i)
        scanf("%d", &a[i]);
    if (dfs(0))
        printf("YES");
    else
        printf("NO");
    return 0;
}