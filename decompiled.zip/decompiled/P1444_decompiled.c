#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

typedef struct {
    int x;
    int y;
} node;

int n, ans;
node a[105];
int f[105];

bool pd(int k, int t, int bk, int c);
int cmp(const void *xx, const void *yy);
void dfs(int k);

bool pd(int k, int t, int bk, int c)
{
    bool result = false;

    if (k != 1)
    {
        result = (t == bk && c == 0);
        if (result)
        {
            return true;
        }
    }

    if (c == 0)
    {
        if (a[t].y == a[t + 1].y)
        {
            return pd(k + 1, t + 1, bk, 1);
        }
        else
        {
            return false;
        }
    }
    else if (c == 1)
    {
        return pd(k + 1, f[t], bk, 0);
    }

    return result;
}
int cmp(const void *xx, const void *yy)
{
    const node *node_x = (const node *)xx;
    const node *node_y = (const node *)yy;

    if (node_x->y < node_y->y)
        return -1;
    if (node_x->y == node_y->y && node_x->x < node_y->x)
        return -1;
    return 0;
}
void dfs(int k)
{
    int i;
    int j;

    if (k == n + 1)
    {
        for (i = 1; i <= n; ++i)
        {
            if (pd(1, i, i, 0))
            {
                ++ans;
                return;
            }
        }
    }
    else if (f[k])
    {
        dfs(k + 1);
    }
    else
    {
        for (j = k + 1; j <= n; ++j)
        {
            if (!f[j])
            {
                f[k] = j;
                f[j] = k;
                dfs(k + 1);
                f[k] = 0;
                f[j] = 0;
            }
        }
    }
}
int main()
{
    int i;

    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
        scanf("%d%d", &a[i].x, &a[i].y);
    qsort(&a[1], n, sizeof(node), cmp);
    dfs(1);
    printf("%d", ans);
    return 0;
}