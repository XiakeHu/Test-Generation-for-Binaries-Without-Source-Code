#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int compare(const void *a, const void *b) ;
 int compare(const void *a, const void *b) ;
int compare(const void *a, const void *b)
{
    const int *value_a = (const int *)a;
    const int *value_b = (const int *)b;
    return *value_a - *value_b;
}
int main(int argc, const char **argv, const char **envp)
{
    int tmp;
    int tf_0[1008];
    int count[1007];
    int n;
    int i_1;
    int i_0;
    int i;
    int sum;

    memset(count, 0, sizeof(count));
    memset(tf_0, 0, sizeof(tf_0));
    sum = 0;
    scanf("%d", &n);
    for (i = 0; i < n; ++i)
    {
        scanf("%d", &tmp);
        if (!tf_0[tmp])
        {
            ++count[tmp];
            tf_0[tmp] = 1;
        }
    }
    for (i_0 = 0; i_0 <= 1004; ++i_0)
    {
        if (tf_0[i_0] > 0)
            ++sum;
    }
    printf("%d", sum);
    qsort(count, 0x3EDuLL, 4uLL, compare);
    for (i_1 = 0; i_1 <= 1004; ++i_1)
    {
        if (count[i_1] > 0)
            printf("%d ", i_1);
    }
    return 0;
}
