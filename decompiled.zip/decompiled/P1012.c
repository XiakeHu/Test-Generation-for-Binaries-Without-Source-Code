#include <stdio.h>
#include <stdlib.h>
#include <string.h>

long long n;
char s[21][10];

int cmp(const void* a, const void* b);
long long read();
void fun();

int main() {
    fun();
    return 0;
}

void fun() {
    n = read();
    for (int i = 0; i < n; ++i) {
        scanf("%s", s[i]);
    }
    qsort(s, n, 10, cmp);
    for (int i = 0; i < n; ++i) {
        printf("%s", s[i]);
    }
}

long long read() {
    long long x = 0, f = 1;
    int ch = getchar();
    while (ch != EOF && (ch < '0' || ch > '9')) {
        if (ch == '-')
            f = -1;
        ch = getchar();
    }
    while (ch != EOF && ch >= '0' && ch <= '9') {
        x = (x << 3) + (x << 1) + (ch ^ '0');
        ch = getchar();
    }
    return x * f;
}

int cmp(const void* a, const void* b) {
    char *s1 = (char*)a;
    char *s2 = (char*)b;
    char temp[21];
    strcpy(temp, s1);
    strcat(temp, s2);
    char temp2[21];
    strcpy(temp2, s2);
    strcat(temp2, s1);
    return strcmp(temp2, temp);
}