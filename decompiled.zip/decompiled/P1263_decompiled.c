#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>
#define MAXN 81610
#define MAXM 500000
typedef struct {
    int from;
    int to;
    int weight;
    int next;
} EDGE;

EDGE edge[MAXM];
int head[MAXN];
int deep[MAXN];
int cnt;
int s, t, n, m;
int maxflow;
int idbegin;
int castle[205][205];
int wall[205][205][2];

int dfs(int cur, int limit);
bool bfs();
int convert(int x, int y);
void add(int x, int y, int w);
int dinic();
void input();
int main();

int dfs(int cur, int limit)
{
    int remaining_flow = limit;
    if (remaining_flow == 0 || cur == t) {
        return remaining_flow;
    }

    int total_flow = 0;
    for (int edge_index = head[cur]; edge_index >= 0; edge_index = edge[edge_index].next) {
        if (deep[edge[edge_index].to] == deep[cur] + 1) {
            int flow_to_send = (remaining_flow < edge[edge_index].weight) ? remaining_flow : edge[edge_index].weight;
            int flow_result = dfs(edge[edge_index].to, flow_to_send);
            if (flow_result > 0) {
                total_flow += flow_result;
                remaining_flow -= flow_result;
                edge[edge_index].weight -= flow_result;
                edge[edge_index ^ 1].weight += flow_result;
                if (remaining_flow == 0) {
                    break;
                }
            }
        }
    }

    if (total_flow == 0) {
        deep[cur] = -1;
    }
    return total_flow;
}
bool bfs()
{
    int i;

    for (i = 0; i <= 80001; ++i)
        deep[i] = -1;

    deep[s] = 0;
    int queue[MAXN];
    int front = 0, rear = 0;
    queue[rear++] = s;
    while (front < rear) {
        int u = queue[front++];
        for (int i = head[u]; i != -1; i = edge[i].next) {
            int v = edge[i].to;
            if (deep[v] == -1 && edge[i].weight > 0) {
                deep[v] = deep[u] + 1;
                queue[rear++] = v;
            }
        }
    }
    return deep[t] != -1;
}
int convert(int x, int y)
{
    return 200 * (x - 1) + y;
}
void add(int x, int y, int w)
{
    int current_edge_index = cnt;
    edge[current_edge_index].from = x;
    edge[current_edge_index].to = y;
    edge[current_edge_index].weight = w;
    edge[current_edge_index].next = head[x];
    head[x] = current_edge_index;
    cnt = current_edge_index + 1;
}
int dinic()
{
    maxflow = 0;
    while (bfs())
    {
        int flow = dfs(s, 0x7FFFFFFF);
        maxflow += flow;
    }
    return maxflow;
}
void input()
{
    int poswall_0;
    int poswall;
    int j_1;
    int i_4;
    int k_0;
    int k;
    int j_0;
    int i_3;
    int j;
    int i_2;
    int i_1;
    int i_0;
    int i;

    for (i = 0; i <= 81608; ++i)
        head[i] = -1;
    s = 0;
    t = 80001;
    scanf("%d %d", &n, &m);
    for (i_0 = 0; i_0 <= n + 1; ++i_0)
    {
        castle[i_0][0] = 2;
        castle[i_0][m + 1] = 2;
    }
    for (i_1 = 1; i_1 <= m + 1; ++i_1)
    {
        castle[0][i_1] = 2;
        castle[n + 1][i_1] = 2;
    }
    for (i_2 = 1; i_2 <= n; ++i_2)
    {
        for (j = 1; j <= m; ++j)
            scanf("%d", &castle[i_2][j]);
    }
    for (i_3 = 1; i_3 <= n; ++i_3)
    {
        for (j_0 = 1; j_0 <= m; ++j_0)
        {
            if (castle[i_3][j_0] != 2)
            {
                poswall = convert(i_3, j_0);
                if (castle[i_3 + 1][j_0] == 2)
                {
                    add(s, poswall, 1);
                    add(poswall, s, 0);
                    for (k = i_3; castle[k][j_0] != 2; --k)
                        wall[k][j_0][0] = poswall;
                }
                if (castle[i_3][j_0 + 1] == 2)
                {
                    add(poswall + 40000, t, 1);
                    add(t, poswall + 40000, 0);
                    poswall_0 = convert(i_3, j_0);
                    for (k_0 = j_0; castle[i_3][k_0] != 2; --k_0)
                        wall[i_3][k_0][1] = poswall_0;
                }
            }
        }
    }
    idbegin = cnt;
    for (i_4 = 1; i_4 <= n; ++i_4)
    {
        for (j_1 = 1; j_1 <= m; ++j_1)
        {
            if (!castle[i_4][j_1])
            {
                add(wall[i_4][j_1][0], wall[i_4][j_1][1] + 40000, 1);
                add(wall[i_4][j_1][1] + 40000, wall[i_4][j_1][0], 0);
            }
        }
    }
}
int main()
{
    int i;

    input();
    dinic();
    printf("%d\n", maxflow);
    for (i = idbegin; i < cnt; i += 2)
    {
        if (!edge[i].weight)
        {
            int row = (edge[i].to - 40001) / 200 + 1;
            int col = (edge[i].from - 1) % 200 + 1;
            printf("%d %d\n", row, col);
        }
    }
    return 0;
}