#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    char* str;
} String;

int compare(const void *a, const void *b);
void solve_string(String st);

int compare(const void *a, const void *b)
{
    char char_a = *(char *)a;
    char char_b = *(char *)b;
    return (int)char_a - (int)char_b;
}
void solve_string(String st) {
    size_t index_girl;
    size_t index_boy;
    size_t index;
    int girl_count;
    int boy_count;

    boy_count = 0;
    girl_count = 0;
    for (index = 0; index < strlen(st.str); ++index) {
        if ((st.str[index] == 'b' && st.str[index + 1] == 'o' && st.str[index + 2] == 'y') ||
            (st.str[index] == 'g' && st.str[index + 1] == 'i' && st.str[index + 2] == 'r' && st.str[index + 3] == 'l')) {
            qsort(&st.str[index], 4, 1, compare);
        }
    }
    for (index_boy = 0; index_boy < strlen(st.str) - 2; ++index_boy) {
        if (st.str[index_boy] == 'b' && st.str[index_boy + 1] == 'o' && st.str[index_boy + 2] == 'y') {
            ++boy_count;
        }
    }
    for (index_girl = 0; index_girl < strlen(st.str) - 3; ++index_girl) {
        if (st.str[index_girl] == 'g' && st.str[index_girl + 1] == 'i' && st.str[index_girl + 2] == 'r' && st.str[index_girl + 3] == 'l') {
            ++girl_count;
        }
    }
    printf("%d\n", boy_count);
    printf("%d\n", girl_count);
}
int main() {
    String st;
    st.str = (char *)malloc(0x400uLL);
    scanf("%s", st.str);
    solve_string(st);
    free(st.str);
    return 0;
}