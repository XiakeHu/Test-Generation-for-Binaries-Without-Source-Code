#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

#define STACK_SIZE 100

typedef struct {
    int arr[STACK_SIZE];
    int top;
} StackInt;

typedef struct {
    char arr[STACK_SIZE];
    int top;
} StackChar;

bool isEmpty(StackChar *s);
void pushInt(StackInt *s, int item);
char pop(StackChar *s);
char peek(StackChar *s);
int cal(int a, char cz, int b);
int popInt(StackInt *s);
void push(StackChar *s, char item);

bool isEmpty(StackChar *s)
{
    return s->top == -1;
}
void pushInt(StackInt *s, int item)
{
    s->top = s->top + 1;
    s->arr[s->top] = item;
}
char pop(StackChar *s)
{
    int old_top = s->top--;
    return s->arr[old_top];
}
char peek(StackChar *s)
{
    return s->arr[s->top];
}
int cal(int a, char cz, int b)
{
    int result = cz;
    switch (cz)
    {
        case '+':
            return a + b;
        case '-':
            return a - b;
        case '*':
            return a * b;
    }
    return result;
}
int popInt(StackInt *s)
{
    int topIndex = s->top--;
    return s->arr[topIndex];
}
void push(StackChar *s, char item)
{
    s->top = s->top + 1;
    s->arr[s->top] = item;
}
int main()
{
    int shu;
    char s[272];
    StackInt num;
    StackChar ope;
    char cz;
    int a;
    int b;
    int i;
    int temp_result;

    memset(&ope, 0, sizeof(ope));
    ope.top = -1;
    memset(&num, 0, sizeof(num));
    num.top = -1;
    pushInt(&num, 0);

    while (scanf("%s", s) != EOF)
    {
        if (s[0] != ']')
        {
            scanf("%d", &shu);
        }

        if (s[0] == 'F')
        {
            while (!isEmpty(&ope) && peek(&ope) != '[')
            {
                b = popInt(&num);
                a = popInt(&num);
                cz = pop(&ope);
                temp_result = cal(a, cz, b);
                pushInt(&num, temp_result);
            }
            push(&ope, '+');
            pushInt(&num, shu);
        }

        if (s[0] == 'B')
        {
            while (!isEmpty(&ope) && peek(&ope) != '[')
            {
                b = popInt(&num);
                a = popInt(&num);
                cz = pop(&ope);
                temp_result = cal(a, cz, b);
                pushInt(&num, temp_result);
            }
            push(&ope, '-');
            pushInt(&num, shu);
        }

        if (s[0] == 'R')
        {
            while (!isEmpty(&ope) && peek(&ope) != '[')
            {
                b = popInt(&num);
                a = popInt(&num);
                cz = pop(&ope);
                temp_result = cal(a, cz, b);
                pushInt(&num, temp_result);
            }
            push(&ope, '+');
            pushInt(&num, shu);
            push(&ope, '*');
            push(&ope, '[');
            pushInt(&num, 0);
            getchar();
        }

        if (s[0] == ']')
        {
            for (i = strlen(s); i > 0; --i)
            {
                while (peek(&ope) != '[')
                {
                    b = popInt(&num);
                    a = popInt(&num);
                    cz = pop(&ope);
                    temp_result = cal(a, cz, b);
                    pushInt(&num, temp_result);
                }
                pop(&ope);
            }
        }
    }

    while (!isEmpty(&ope))
    {
        b = popInt(&num);
        a = popInt(&num);
        cz = pop(&ope);
        temp_result = cal(a, cz, b);
        pushInt(&num, temp_result);
    }

    temp_result = popInt(&num);
    if (temp_result <= 0)
    {
        temp_result = -temp_result;
    }
    printf("%d", temp_result);
    return 0;
}