#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

bool p(int x, int n) ;
   bool p(int x, int n) ;
bool p(int x, int n)
{
    int i;
    for (i = 0; i <= n && n >= x * i; ++i)
    {
    }
    return i > n;
}
int main() {
    int k, n;
    scanf("%d %d", &n, &k);
    
    if (n == k) {
        putchar('1');
        return 0;
    } else {
        int left = 1;
        int right = n;
        
        while (left < right) {
            int mid = (left + right) >> 1;
            if (p(mid, n)) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        
        if (k == 1) {
            printf("%d", n);
        } else {
            int result = left;
            if (result < 2) {
                result = 2;
            }
            printf("%d", result - 1);
        }
        return 0;
    }
}