#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef int int64;

int n;
int a[1005];
int b[1005];
int num[1005];
int ans[1005];
int Ans;
int sum;

int get();
void update();
void sa();
int main();

int get()
{
    int i;
    int current_sum_a;
    int current_max_sum;

    current_sum_a = 0;
    current_max_sum = 0;
    for ( i = 1; i <= n; ++i )
    {
        current_sum_a += a[num[i]];
        if ( current_sum_a > current_max_sum )
            current_max_sum = current_sum_a;
        current_max_sum += b[num[i]];
    }
    return current_max_sum;
}
void update()
{
    int i;
    for (i = 1; i <= n; ++i)
        ans[i] = num[i];
    Ans = sum;
}
void sa()
{
    double temperature = 100.0;
    const double end_temperature = 0.00000001;
    const double cooling_rate = 0.9357;

    while (temperature > end_temperature)
    {
        int x = rand() % n + 1;
        int y = rand() % n + 1;

        int temp = num[x];
        num[x] = num[y];
        num[y] = temp;

        sum = get();
        int delta = sum - Ans;

        if (delta >= 0)
        {
            double random_value = (double)rand() / 2147483647.0;
            if (random_value > exp((double)-delta / temperature))
            {
                int revert_temp = num[x];
                num[x] = num[y];
                num[y] = revert_temp;
            }
        }
        else
        {
            update();
        }

        temperature *= cooling_rate;
    }
}
int main()
{
    int i;
    int i_0;
    int i_1;
    int i_2;
    int iteration_count;
    unsigned int seed;

    seed = rand();
    srand(seed);
    seed = rand();
    srand(seed);

    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
        scanf("%d", &a[i]);
    for (i_0 = 1; i_0 <= n; ++i_0)
        scanf("%d", &b[i_0]);
    for (i_1 = 1; i_1 <= n; ++i_1)
        num[i_1] = i_1;

    sum = get();
    Ans = sum;
    for (i_2 = 1; i_2 <= n; ++i_2)
        ans[i_2] = i_2;

    iteration_count = 500;
    while (iteration_count--)
        sa();

    printf("%d\n", Ans);
    for (i_2 = 1; i_2 <= n; ++i_2)
        printf("%d ", ans[i_2]);

    return 0;
}