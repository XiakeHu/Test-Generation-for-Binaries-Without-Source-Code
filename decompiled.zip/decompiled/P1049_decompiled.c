#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

typedef struct {
    int first;
    int second;
}Pair;

int n, V, tot, ans;
int v[1005];
bool vis[1005];
double T;

Pair rd_pair();
bool accept(int del);
int main();

Pair rd_pair()
{
    Pair p;
    p.first = rand() % n + 1;
    p.second = rand() % 2;
    return p;
}

bool accept(int del)
{
    bool result = true;

    if (del <= 0)
    {
        double exponent_value = exp((double)(del) / T);
        double random_ratio = (double)(rand()) / 2147483647.0;

        if (exponent_value <= random_ratio)
        {
            return false;
        }
    }

    return result;
}

int main()
{
    int selected_item_index;
    int delta_energy;
    int i;

    unsigned int seed = time(0);
    srand(seed);
    scanf("%d%d", &V, &n);
    for (i = 1; i <= n; ++i)
        scanf("%d", &v[i]);
    memset(vis, 0, sizeof(vis));
    T = 10000.0;
    tot = 0;
    ans = 0;
    while (T > 1.0e-14)
    {
        int current_best = tot;
        if (ans >= tot)
            current_best = ans;
        ans = current_best;
        Pair p = rd_pair();
        selected_item_index = p.first;
        delta_energy = v[selected_item_index];
        if (vis[selected_item_index])
            delta_energy = -delta_energy;
        if (accept(delta_energy))
        {
            if (vis[selected_item_index])
            {
                vis[selected_item_index] = 0;
                tot -= v[selected_item_index];
                goto LABEL_14;
            }
            if (tot + v[selected_item_index] <= V)
            {
                vis[selected_item_index] = 1;
                tot += v[selected_item_index];
                goto LABEL_14;
            }
        }
        else
        {
        LABEL_14:
            T = 0.9978900000000001 * T;
        }
    }
    printf("%d", V - ans);
    return 0;
}