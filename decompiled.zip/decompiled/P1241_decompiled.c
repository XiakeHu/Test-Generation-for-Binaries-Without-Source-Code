#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define MAX_LEN 1000

typedef struct {
    int val[MAX_LEN];
    int _top;
} Stack;

typedef struct {
    int l;
    int m;
    int r;
    char s[4];
} Bracket;

Stack stack;
Bracket *brackets;
int len;
char in[MAX_LEN];

int top(Stack *st);
void merge(Bracket *br);
void init();
int pop(Stack *st);
void push(Stack *st, int x);

int top(Stack *st)
{
    return st->val[st->_top];
}
void merge(Bracket *br)
{
    int index = 0;
    
    if (br->l != 0) {
        br->s[index] = br->l;
        index++;
    }
    
    if (br->m != 0) {
        br->s[index] = br->m;
        index++;
    }
    
    if (br->r != 0) {
        br->s[index] = br->r;
        index++;
    }
    
    br->s[index] = 0;
}
void init()
{
    int i;
    Bracket *current_bracket;
    Bracket *next_bracket;

    brackets = (Bracket *)malloc(len * sizeof(Bracket));
    for (i = 0; i < len; ++i)
    {
        current_bracket = &brackets[i];
        current_bracket->r = 0;
        next_bracket = &brackets[i];
        next_bracket->m = current_bracket->r;
        brackets[i].l = next_bracket->m;
        memset(brackets[i].s, 0, sizeof(brackets[i].s));
    }
    stack._top = 0;
    memset(&stack, 0, sizeof(stack));
}
int pop(Stack *st)
{
    if (st->_top > 0)
    {
        --st->_top;
    }
    return st->val[st->_top];
}
void push(Stack *st, int x)
{
    st->val[++st->_top] = x;
}
int main()
{
    int current_char;
    Bracket *current_bracket;
    Bracket *stack_top_bracket;
    int popped_index;
    int i;
    int j;
    int k;

    scanf("%s", in);
    len = strlen(in);
    init();
    for (i = 0; i < len; ++i)
        brackets[i].m = in[i];
    for (j = 0; j < len; ++j)
    {
        current_char = brackets[j].m;
        if (current_char == ']')
        {
            stack_top_bracket = brackets;
            if (stack_top_bracket[top(&stack)].m == '[')
            {
                pop(&stack);
                continue;
            }
            brackets[j].l = '[';
        }
        else
        {
            if (current_char > ']')
                continue;
            if (current_char == '[')
            {
                push(&stack, j);
                continue;
            }
            if (current_char > '[')
                continue;
            if (current_char == '(')
            {
                push(&stack, j);
                continue;
            }
            if (current_char == ')')
            {
                current_bracket = brackets;
                if (current_bracket[top(&stack)].m == '(')
                {
                    pop(&stack);
                    continue;
                }
                brackets[j].l = '(';
            }
        }
    }
    while (stack._top > 0)
    {
        stack_top_bracket = brackets;
        current_char = stack_top_bracket[top(&stack)].m;
        if (current_char == '(')
        {
            current_bracket = brackets;
            popped_index = pop(&stack);
            current_bracket[popped_index].r = ')';
        }
        else if (current_char == '[')
        {
            current_bracket = brackets;
            popped_index = pop(&stack);
            current_bracket[popped_index].r = ']';
        }
    }
    for (k = 0; k < len; ++k)
    {
        merge(&brackets[k]);
        printf("%s", brackets[k].s);
    }
    free(brackets);
    return 0;
}