#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int cmp(const void *a, const void *b) ;
int main() ;
int cmp(const void *a, const void *b)
{
    char char_a = *(const char *)a;
    char char_b = *(const char *)b;
    return (int)char_a - (int)char_b;
}
int main()
{
    int i, j, k, m, n;
    int len, p, now;
    char a[100], b[100], c[100];
    const char *s = "";

    scanf("%d %s %d", &len, a, &p);
    for (i = 0; i < len; ++i)
        b[i] = a[i];
    qsort(b, len, 1, cmp);
    for (j = 0; j < len; ++j)
    {
        if (b[j] == a[p - 1])
        {
            b[j] = 64;
            now = j;
            break;
        }
    }
    c[0] = a[now];
    for (k = 1; k < len; ++k)
    {
        for (m = len - 1; m >= 0; --m)
        {
            if (b[m] == a[now])
            {
                now = m;
                c[k] = a[m];
                b[m] = 64;
                break;
            }
        }
    }
    for (n = len - 1; n >= 0; --n)
        putchar(c[n]);
    puts(s);
    return 0;
}
