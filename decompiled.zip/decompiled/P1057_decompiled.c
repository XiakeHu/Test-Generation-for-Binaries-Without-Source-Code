#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int r;
    int c;
    int N[35][35];
}Matrix;

void init(Matrix *M, int r, int c) ;
Matrix* multiply(Matrix* retstr, Matrix A, Matrix B) ;
Matrix* power(Matrix* retstr, Matrix M, long long p) ;
int main() ;
void init(Matrix *M, int r, int c)
{
    M->r = r;
    M->c = c;
    memset(M->N, 0, sizeof(M->N));
}
Matrix* multiply(Matrix* retstr, Matrix A, Matrix B)
{
    Matrix resultMatrix;
    int rowIndex;
    int colIndex;
    int innerIndex;

    init(&resultMatrix, A.r, B.c);
    for (rowIndex = 0; rowIndex < resultMatrix.r; ++rowIndex)
    {
        for (colIndex = 0; colIndex < resultMatrix.c; ++colIndex)
        {
            for (innerIndex = 0; innerIndex < A.c; ++innerIndex)
            {
                resultMatrix.N[rowIndex][colIndex] += A.N[rowIndex][innerIndex] * B.N[innerIndex][colIndex];
            }
        }
    }
    memcpy(retstr, &resultMatrix, sizeof(Matrix));
    return retstr;
}
Matrix* power(Matrix* retstr, Matrix M, long long p)
{
    Matrix tmp;
    Matrix ans;
    Matrix src;
    Matrix v4;
    Matrix v5;
    void* dest;
    long long pa;
    int i;

    dest = retstr;
    pa = p;
    memcpy(&tmp, &M, sizeof(Matrix));
    init(&ans, M.r, M.c);
    for (i = 0; i < ans.r; ++i)
        ans.N[i][0] = 1LL;
    while (pa)
    {
        if ((pa & 1) != 0)
        {
            memcpy(&v5, &tmp, sizeof(Matrix));
            memcpy(&v4, &ans, sizeof(Matrix));
            multiply(&src, v4, v5);
            memcpy(&ans, &src, sizeof(Matrix));
        }
        memcpy(&v5, &tmp, sizeof(Matrix));
        memcpy(&v4, &tmp, sizeof(Matrix));
        multiply(&tmp, v4, v5);
        pa >>= 1;
    }
    memcpy(dest, &ans, sizeof(Matrix));
    return (Matrix*)dest;
}
int main()
{
    long long n, m;
    Matrix x1, ans, temp;
    int i;

    scanf("%lld%lld", &n, &m);
    init(&x1, n, n);
    for (i = 0; i < n; ++i)
    {
        long long prev_index = (i + n - 1) % n;
        x1.N[i][prev_index] = 1LL;
        x1.N[i][(i + 1) % n] = x1.N[i][prev_index];
    }
    memcpy(&temp, &x1, sizeof(Matrix));
    power(&ans, temp, m);
    printf("%lld", ans.N[0][0]);
    return 0;
}
