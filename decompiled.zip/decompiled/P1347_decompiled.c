#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef int lint;  lint readlint() ;
int main() ;
lint readlint()
{
    lint sign;
    lint value;
    char current_char;

    current_char = getchar();
    value = 0;
    sign = 1;

    while (current_char <= 47 || current_char > 57)
    {
        if (current_char == '-')
            sign = -sign;
        current_char = getchar();
    }

    while (current_char > 47 && current_char <= 57)
    {
        value = 10 * value + current_char - '0';
        current_char = getchar();
    }

    return sign * value;
}
int main()
{
    int list[30];

    readlint();
    readlint();
    memset(list, 0, sizeof(list));
    return 0;
}
