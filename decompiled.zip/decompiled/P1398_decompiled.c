#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n, m;
int a[1005][1005];
int S[1005][1005];
int S2[1005][1005];
int ansN[1005][1005];
int ansI[1005][1005];

int read() ;
int main() ;
int read()
{
    char current_char;
    int sign;
    int value;

    value = 0;
    sign = 1;
    for ( current_char = getchar(); current_char <= 47 || current_char > 57; current_char = getchar() )
    {
        if ( current_char == 45 )
            sign = -1;
    }
    while ( current_char > 47 && current_char <= 57 )
    {
        value = 10 * value + current_char - 48;
        current_char = getchar();
    }
    return sign * value;
}
int main()
{
    int row;
    int col;

    n = read();
    m = read();
    for ( row = 1; row <= n; ++row )
    {
        for ( col = 1; col <= m; ++col )
        {
            a[row][col] = read();
            S[row][col] = a[row][col] + S[row - 1][col + 504];
            S2[row][col] = a[row][col] + S2[row - 1][col];
        }
    }
    memset(ansN, -63, sizeof(ansN));
    memset(ansI, -63, sizeof(ansI));
    return 0;
}