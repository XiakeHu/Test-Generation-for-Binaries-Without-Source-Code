#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n, m, ans, all;
int vis[2008];
int w[2008];

void check() ;
int compare(const void *a, const void *b) ;
void dfs(int step, int now, int b) ;
int main() ;
void check()
{
    int mark[28] = {0};
    int que[2008] = {0};
    int book[2007] = {0};
    int current_sum;
    int loop_limit;
    int inner_index;
    int outer_index_1;
    int outer_index_0;
    int start_node;
    int queue_tail;
    int outer_index;
    int current_answer;

    memset(book, 0, sizeof(book));
    memset(que, 0, sizeof(que));
    memset(mark, 0, sizeof(mark));
    current_answer = 0;

    for (outer_index = 1; outer_index <= n; ++outer_index)
    {
        if (vis[outer_index])
            mark[outer_index] = 1;
    }

    queue_tail = 1;
    for (outer_index_0 = 1; outer_index_0 <= n; ++outer_index_0)
    {
        if (!vis[outer_index_0])
        {
            start_node = outer_index_0;
            break;
        }
    }

    mark[start_node] = 1;
    que[queue_tail] = w[start_node];
    book[w[start_node]] = 1;
    ++queue_tail;
    ++current_answer;

    for (outer_index_1 = start_node + 1; outer_index_1 <= n; ++outer_index_1)
    {
        if (!mark[outer_index_1])
        {
            mark[outer_index_1] = 1;
            loop_limit = queue_tail - 1;
            for (inner_index = 1; inner_index <= loop_limit; ++inner_index)
            {
                current_sum = w[outer_index_1] + que[inner_index];
                if (!book[current_sum])
                {
                    book[current_sum] = 1;
                    que[queue_tail++] = current_sum;
                    ++current_answer;
                }
            }
            if (!book[w[outer_index_1]])
            {
                book[w[outer_index_1]] = 1;
                que[queue_tail++] = w[outer_index_1];
                ++current_answer;
            }
        }
    }

    ans = (int)fmax((double)ans, (double)current_answer);
}
int compare(const void *a, const void *b)
{
    const int *value_a = (const int *)a;
    const int *value_b = (const int *)b;
    return *value_a - *value_b;
}
void dfs(int step, int now, int b)
{
    int last;
    int i;

    if (now > ans)
    {
        if (step == m + 1)
        {
            check();
        }
        else
        {
            last = 0;
            for (i = b; i <= n; ++i)
            {
                if (!vis[i] && w[i] != w[last])
                {
                    vis[i] = 1;
                    dfs(step + 1, now - w[i], i + 1);
                    vis[i] = 0;
                    last = i;
                }
            }
        }
    }
}
int main()
{
    int i;
    ans = 0;
    all = 0;
    scanf("%d %d", &n, &m);
    for (i = 1; i <= n; ++i)
    {
        scanf("%d", &w[i]);
        all += w[i];
    }
    qsort(&w[1], n, sizeof(int), compare);
    dfs(1, all, 1);
    printf("%d", ans);
    return 0;
}