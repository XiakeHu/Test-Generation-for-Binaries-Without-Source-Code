#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct TreeNode {
    char me;
    struct TreeNode *left;
    struct TreeNode *right;
} Tree;

Tree *find_tree(char w, Tree *start);
Tree *build(char w);
void preorder(Tree *start);

Tree *find_tree(char w, Tree *start)
{
    Tree *found_node;

    if (!start || w == start->me)
        return start;

    found_node = find_tree(w, start->left);
    if (found_node)
        return found_node;
    else
        return find_tree(w, start->right);
}
Tree *build(char w)
{
    if (w == '*')
    {
        return NULL;
    }

    Tree *node = (Tree *)malloc(sizeof(Tree));
    node->me = w;
    node->left = NULL;
    node->right = NULL;
    return node;
}
void preorder(Tree *start)
{
    if (start)
    {
        putchar(start->me);
        preorder(start->left);
        preorder(start->right);
    }
}
int main()
{
    int node_count;
    char parent_char, left_char, right_char;
    Tree *root_node;
    Tree *found_node;
    int i;

    scanf("%d", &node_count);
    scanf(" %c %c %c", &parent_char, &left_char, &right_char);

    root_node = build(parent_char);
    root_node->left = build(left_char);
    root_node->right = build(right_char);

    for (i = 1; i < node_count; ++i)
    {
        scanf(" %c %c %c", &parent_char, &left_char, &right_char);
        found_node = find_tree(parent_char, root_node);
        if (found_node)
        {
            found_node->left = build(left_char);
            found_node->right = build(right_char);
        }
    }

    preorder(root_node);
    return 0;
}