#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

void solve() ;
 int a[1005]; int dp1[1005]; int dp2[1005]; int ans;  void solve() ;
void solve()
{
    int temp_val;
    int temp_val2;
    int temp_val3;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;

    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
        scanf("%d", &a[i]);

    for (j = 1; j <= n; ++j)
    {
        for (k = 0; k < j; ++k)
        {
            if (a[k] < a[j])
            {
                temp_val = dp1[k] + 1;
                if (temp_val < dp1[j])
                    temp_val = dp1[j];
                dp1[j] = temp_val;
            }
        }
    }

    for (l = n; l > 0; --l)
    {
        for (m = n + 1; m > l; --m)
        {
            if (a[m] < a[l])
            {
                temp_val2 = dp2[m] + 1;
                if (temp_val2 < dp2[l])
                    temp_val2 = dp2[l];
                dp2[l] = temp_val2;
            }
        }
    }

    for (int idx = 1; idx <= n; ++idx)
    {
        temp_val3 = ans;
        if (dp1[idx] + dp2[idx] - 1 >= ans)
            temp_val3 = dp1[idx] + dp2[idx] - 1;
        ans = temp_val3;
    }

    printf("%d", n - ans);
}
int main()
{
    solve();
    return 0;
}
