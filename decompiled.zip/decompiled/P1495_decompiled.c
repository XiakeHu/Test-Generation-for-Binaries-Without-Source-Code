#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int mod;
    int lft;
    int phi;
} pig_t;

int Phi[1000001];
int vis[1000001];
int prime[1000001];
int tot;
int n;

pig_t read_pig();
void write(long long x);
pig_t solve(const int l, const int r);
void ola();
long long qpow(const long long base, const long long exponent, const long long modulus);

pig_t read_pig()
{
    pig_t result;
    int a;
    int b;

    scanf("%d%d", &a, &b);
    result.mod = a;
    result.lft = b;
    result.phi = Phi[a];
    return result;
}
void write(long long x)
{
    if (x > 9)
        write(x / 10);
    putchar(x % 10 + '0');
}
pig_t solve(const int l, const int r)
{
    pig_t result;
    pig_t left_result;
    pig_t right_result;
    int temp_mod_product;
    int temp_lft_remainder;
    int temp_phi_product;
    int combined_remainder;
    int final_mod;

    if (l == r)
    {
        return read_pig();
    }

    left_result = solve(l, (l + r) >> 1);
    right_result = solve(((l + r) >> 1) + 1, r);

    temp_mod_product = left_result.mod * right_result.mod;

    temp_lft_remainder = left_result.lft % left_result.mod;
    temp_phi_product = right_result.phi * temp_lft_remainder;

    temp_lft_remainder = right_result.lft % right_result.mod;
    combined_remainder = temp_phi_product + temp_lft_remainder * left_result.phi;

    final_mod = combined_remainder % (right_result.phi * left_result.mod);

    result.mod = temp_mod_product;
    result.lft = final_mod;
    result.phi = left_result.phi * right_result.phi;

    return result;
}
void ola()
{
    int j;
    int i;

    Phi[1] = 1;
    for (i = 2; i <= 1000000; ++i)
    {
        if (!vis[i])
        {
            prime[++tot] = i;
            Phi[i] = i - 1;
        }
        for (j = 1; j <= tot && prime[j] * i <= 1000000; ++j)
        {
            vis[i * prime[j]] = 1;
            if (i % prime[j] == 0)
            {
                Phi[i * prime[j]] = Phi[i] * prime[j];
                break;
            }
            Phi[i * prime[j]] = (prime[j] - 1) * Phi[i];
        }
    }
}
int main()
{
    pig_t result;

    ola();
    scanf("%d", &n);
    result = solve(1, n);
    write(result.lft);
    putchar('\n');
    return 0;
}
long long qpow(const long long base, const long long exponent, const long long modulus)
{
    long long half_power;
    long long result;

    if (exponent == 0)
        return 1LL;

    half_power = qpow(base, exponent >> 1, modulus);
    result = (half_power * half_power) % modulus;

    if ((exponent & 1) != 0)
        return (base * result) % modulus;

    return result;
}