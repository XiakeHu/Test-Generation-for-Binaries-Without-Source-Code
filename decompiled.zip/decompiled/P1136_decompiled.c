#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

char s[520];
int a[520];
int f[520][520][2];
int g[520][520];

int max(int a, int b)
{
    int result = a;
    if (b >= a)
    {
        result = b;
    }
    return result;
}

int main() {
    int n, m;
    scanf("%d %d", &n, &m);
    getchar();
    fgets(s, 520, stdin);
    s[strcspn(s, "\n")] = 0;

    for (int i = 1; i <= n; ++i) {
        a[i] = (s[i - 1] == 'z');
    }

    for (int i = 2; i <= n; ++i) {
        int transition = (!a[i - 1] && a[i]);
        f[i][0][a[i]] = f[i - 1][0][a[i - 1]] + transition;
    }

    for (int i = 1; i <= n; ++i) {
        for (int j = i + 1; j <= n; ++j) {
            int transition = (!a[j - 1] && a[j]);
            g[i][j] = transition + g[i - 1][j + 519];
        }
    }

    for (int i = 0; i <= m; ++i) {
        f[0][i][0] = 0x80000000;
        for (int j = 1; j <= n; ++j) {
            f[j][i][a[j] == 0] = 0x80000000;
        }
    }

    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m; ++j) {
            f[i][j][a[i] == 0] = 0x80000000;
            int current_char = a[i];
            int val = max(f[i - 1][j][0] + current_char, f[i - 1][j][1]);
            f[i][j][current_char] = val;

            for (int k = 1; k < i; ++k) {
                if (a[k] != a[i]) {
                    if (k == i - 1) {
                        int temp = max(f[k - 1][j - 1][0] + a[i], f[k - 1][j - 1][1]);
                        int transition = (!a[i] && a[k]);
                        int idx = (a[i] == 0);
                        int candidate = max(f[i][j][idx], transition + temp);
                        f[i][j][idx] = candidate;
                    } else {
                        int temp = max(f[k - 1][j - 1][0] + a[i], f[k - 1][j - 1][1]);
                        int transition1 = (!a[i] && a[k + 1]);
                        int sum = transition1 + temp;
                        int transition2 = (!a[i - 1] && a[k]);
                        int idx = (a[i] == 0);
                        int candidate = max(f[i][j][idx], transition2 + sum + g[k][i + 519]);
                        f[i][j][idx] = candidate;
                    }
                }
            }
        }
    }

    int result = max(f[n][m][0], f[n][m][1]);
    printf("%d\n", result);
    return 0;
}