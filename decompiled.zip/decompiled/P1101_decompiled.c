#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int num;
char a[102 * 102];
int book[102][102];
char ans[] = "yizhong";

int dfs(int n, int m, int no, int f) ;
int main(int argc, const char **argv, const char **envp) ;
int dfs(int n, int m, int no, int f)
{
    int result;

    if (n <= 0 || m <= 0 || n > num || m > num)
        return 0;

    if (a[102 * n + m] != ans[no])
        return 0;

    if (no == 7)
    {
        book[n][m] = 1;
        return 1;
    }

    result = f;
    switch (f)
    {
    case 1:
        if (dfs(n - 1, m - 1, no + 1, f))
        {
            book[n][m] = 1;
            result = 1;
        }
        else
        {
            result = 0;
        }
        break;
    case 2:
        if (dfs(n - 1, m, no + 1, f))
        {
            book[n][m] = 1;
            result = 1;
        }
        else
        {
            result = 0;
        }
        break;
    case 3:
        if (dfs(n - 1, m + 1, no + 1, f))
        {
            book[n][m] = 1;
            result = 1;
        }
        else
        {
            result = 0;
        }
        break;
    case 4:
        if (dfs(n, m - 1, no + 1, f))
        {
            book[n][m] = 1;
            result = 1;
        }
        else
        {
            result = 0;
        }
        break;
    case 5:
        dfs(n - 1, m - 1, no + 1, 1);
        dfs(n - 1, m, no + 1, 2);
        dfs(n - 1, m + 1, no + 1, 3);
        dfs(n, m - 1, no + 1, 4);
        dfs(n, m + 1, no + 1, 6);
        dfs(n + 1, m - 1, no + 1, 7);
        dfs(n + 1, m, no + 1, 8);
        result = dfs(n + 1, m + 1, no + 1, 9);
        break;
    case 6:
        if (dfs(n, m + 1, no + 1, f))
        {
            book[n][m] = 1;
            result = 1;
        }
        else
        {
            result = 0;
        }
        break;
    case 7:
        if (dfs(n + 1, m - 1, no + 1, f))
        {
            book[n][m] = 1;
            result = 1;
        }
        else
        {
            result = 0;
        }
        break;
    case 8:
        if (dfs(n + 1, m, no + 1, f))
        {
            book[n][m] = 1;
            result = 1;
        }
        else
        {
            result = 0;
        }
        break;
    case 9:
        if (dfs(n + 1, m + 1, no + 1, f))
        {
            book[n][m] = 1;
            result = 1;
        }
        else
        {
            result = 0;
        }
        break;
    default:
        return result;
    }

    return result;
}
int main(int argc, const char **argv, const char **envp)
{
    char input_char[2];
    int row, col;
    int start_row, start_col;
    int output_row, output_col;

    scanf("%d", &num);
    for (row = 1; row <= num; ++row)
    {
        for (col = 1; col <= num; ++col)
        {
            scanf("%s", input_char);
            a[102 * row + col] = input_char[0];
        }
    }
    for (start_row = 1; start_row <= num; ++start_row)
    {
        for (start_col = 1; start_col <= num; ++start_col)
            dfs(start_row, start_col, 1, 5);
    }
    for (output_row = 1; output_row <= num; ++output_row)
    {
        for (output_col = 1; output_col <= num; ++output_col)
        {
            if (book[output_row][output_col])
                putchar(a[102 * output_row + output_col]);
            else
                putchar('*');
        }
        putchar('\n');
    }
    return 0;
}