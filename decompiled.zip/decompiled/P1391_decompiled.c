#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int bin_digit(int num, int id) ;
void dfs(int n, int *mp, int currln, int curstep, int prevln, int *ans) ;
int main() ;
int bin_digit(int num, int id)
{
    int mask = 1 << id;
    int masked_value = num & mask;
    int result = masked_value >> id;
    return result;
}
void dfs(int n, int *mp, int currln, int curstep, int prevln, int *ans)
{
    if (n)
    {
        int nextln = 0;
        int nstep = 0;
        for (int i = 1; i <= n; ++i)
        {
            int bit_left = bin_digit(currln, i - 1);
            int bit_right = bin_digit(currln, i + 1);
            int sum_neighbors = bit_left + bit_right;
            int bit_prev = bin_digit(prevln, i);
            int sum_total = sum_neighbors + bit_prev;
            int new_bit = sum_total & 1;
            nextln |= (new_bit << i);

            int target_bit = bin_digit(mp[n], i);
            int current_bit = bin_digit(nextln, i);
            if (target_bit != current_bit)
            {
                ++nstep;
                if (target_bit)
                    return;
            }
        }
        dfs(n - 1, mp, nextln, curstep + nstep, currln, ans);
    }
    else
    {
        if (*ans > curstep)
            *ans = curstep;
    }
}
int main()
{
    int i;
    int j;
    int k;
    int m;
    int target_bit;
    int current_bit;
    int mp[23];
    int ans;
    int temp;
    int n;
    int flag;
    int sstep;

    ans = 2147462637;
    scanf("%d", &n);
    for (i = 1; i <= n; ++i)
    {
        mp[i] = 0;
        for (j = 1; j <= n; ++j)
        {
            scanf("%d", &temp);
            mp[i] = temp + 2 * mp[i];
        }
    }
    for (k = 0; k < (1 << (n + 1)); k += 2)
    {
        sstep = 0;
        flag = 1;
        for (m = 1; m <= n; ++m)
        {
            target_bit = bin_digit(mp[1], m);
            current_bit = bin_digit(k, m);
            if (target_bit != current_bit)
            {
                ++sstep;
                if (target_bit)
                {
                    flag = 0;
                    break;
                }
            }
        }
        if (flag)
            dfs(n, mp, k, sstep, 0, &ans);
    }
    if (ans == 2147462637)
        printf("%d", -1);
    else
        printf("%d", ans);
    return 0;
}
