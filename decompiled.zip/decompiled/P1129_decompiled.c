#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

 int main(int argc, const char **argv, const char **envp) ;
int main(int argc, const char **argv, const char **envp)
{
    int input_value;
    int *array;
    int array_size;

    array_size = 5;
    array = (int *)malloc(array_size * sizeof(int));
    scanf("%d", &input_value);
    return 0;
}
