#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct __attribute__((aligned(8))) {int *heap;int size;} my_priority;

void gao(my_priority *q, int pos) ;
int size(my_priority *q) ;
void doit(my_priority *q, int i) ;
void pop(my_priority *q) ;
void push(my_priority *q, int w) ;
void init(my_priority *q) ;
int top(my_priority *q) ;
void gao(my_priority *q, int pos)
{
    int temp_value;
    int child_index;

    if (q->size > 2 * pos)
    {
        child_index = (2 * pos != q->size - 1 && q->heap[2 * pos] > q->heap[2 * pos + 1]) ? 1 : 0;
        if (q->heap[pos] > q->heap[2 * pos + child_index])
        {
            temp_value = q->heap[pos];
            q->heap[pos] = q->heap[2 * pos + child_index];
            q->heap[2 * pos + child_index] = temp_value;
            gao(q, child_index + 2 * pos);
        }
    }
}
int size(my_priority *q)
{
    return q->size - 1;
}
void doit(my_priority *q, int i)
{
    int temp_value;

    while (q->heap[i] < q->heap[i / 2])
    {
        temp_value = q->heap[i];
        q->heap[i] = q->heap[i / 2];
        q->heap[i / 2] = temp_value;
        i = i / 2;
    }
}
void pop(my_priority *q)
{
    q->heap[1] = q->heap[--q->size];
    gao(q, 1);
}
void push(my_priority *q, int w)
{
    q->size++;
    q->heap = (int *)realloc(q->heap, sizeof(int) * q->size);
    q->heap[q->size - 1] = w;
    doit(q, q->size - 1);
}
void init(my_priority *q)
{
    q->heap = (int *)malloc(sizeof(int));
    q->heap[0] = -1000000000;
    q->size = 2;
}
int top(my_priority *q)
{
    return q->heap[1];
}
int main() {
    my_priority queue;
    int tmp_value;
    int n;
    int total_cost = 0;
    int i;

    total_cost = 0;
    init(&queue);
    scanf("%d", &n);
    for (i = 1; i <= n; ++i) {
        scanf("%d", &tmp_value);
        push(&queue, tmp_value);
    }
    while (size(&queue) > 1) {
        tmp_value = top(&queue);
        pop(&queue);
        tmp_value += top(&queue);
        pop(&queue);
        total_cost += tmp_value;
        push(&queue, tmp_value);
    }
    printf("%d", total_cost);
    free(queue.heap);
    return 0;
}