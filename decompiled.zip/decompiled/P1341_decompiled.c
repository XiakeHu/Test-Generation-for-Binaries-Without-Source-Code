#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_N 60
#define MAX_M 2000

typedef struct {
    int from, to, p;
} Edge;

int head[MAX_N], next[MAX_M], to[MAX_M], w[MAX_M];
int du[MAX_N], vis[MAX_M];
int t = 0, n, cnt = 0, start = 0, end = 0, step = 0;
int num[256];
char letter[MAX_N];
char s[MAX_N];
Edge edge[MAX_M];

int cmp(const void *a, const void *b);
void add(int u, int v, int p);
void dfs(int x, int step, char *s);

int cmp(const void *a, const void *b)
{
    Edge *ea = (Edge *)a;
    Edge *eb = (Edge *)b;
    return eb->from - ea->from;
}

void add(int u, int v, int p)
{
    int edge_index = ++t;
    next[edge_index] = head[u];
    to[edge_index] = v;
    w[edge_index] = p;
    head[u] = edge_index;
    ++du[u];
}

void dfs(int x, int step, char *s)
{
    int i;
    int next_node;

    if (x != 0)
    {
        s[step - 1] = letter[x];
        if (step == n + 1)
        {
            if (x == end || end == 0)
            {
                printf("%s", s);
                exit(0);
            }
        }
        else
        {
            for (i = head[x]; i != 0; i = next[i])
            {
                if (vis[w[i]] == 0 && vis[w[i] ^ 1] == 0)
                {
                    vis[w[i]] = 1;
                    next_node = to[i];
                    dfs(next_node, step + 1, s);
                    vis[w[i]] = 0;
                }
            }
        }
    }
}

int main()
{
    int edge_index_1;
    int edge_index_2;
    int from_value;
    int to_value;
    char char_b;
    char char_a;
    int i_3;
    int i_2;
    int i_1;
    int i_0;
    int i;

    scanf("%d", &n);
    for (i = 0; i <= 25; ++i)
    {
        num[i + 65] = i + 1;
        letter[i + 1] = i + 65;
        num[i + 97] = i + 27;
        letter[i + 27] = i + 97;
    }
    for (i_0 = 1; i_0 <= n; ++i_0)
    {
        scanf(" %c %c", &char_a, &char_b);
        edge_index_1 = ++cnt;
        from_value = num[(int)char_b];
        edge[cnt].to = num[(int)char_a];
        edge[edge_index_1].from = from_value;
        edge[edge_index_1].p = 2 * i_0;
        edge_index_2 = ++cnt;
        from_value = num[(int)char_a];
        edge[cnt].to = num[(int)char_b];
        edge[edge_index_2].from = from_value;
        edge[edge_index_2].p = (2 * i_0) | 1;
    }
    qsort(&edge[1], cnt, sizeof(Edge), cmp);
    for (i_1 = 1; i_1 <= cnt; ++i_1)
        add(edge[i_1].from, edge[i_1].to, edge[i_1].p);
    for (i_2 = 1; i_2 <= 52; ++i_2)
    {
        if ((du[i_2] & 1) != 0)
        {
            if (start)
            {
                if (end)
                {
                    printf("No Solution");
                    return 0;
                }
                end = i_2;
            }
            else
            {
                start = i_2;
            }
        }
    }
    if (!start)
    {
        for (i_3 = 1; i_3 <= 52; ++i_3)
        {
            if (du[i_3])
            {
                start = i_3;
                break;
            }
        }
    }
    s[n + 1] = 0;
    step = 1;
    dfs(start, step, s);
    printf("No Solution");
    return 0;
}