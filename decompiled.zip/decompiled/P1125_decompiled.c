#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int le;
    int xunhuan;
}Variables;

Variables init_variables() ;
   Variables init_variables() ;
   Variables init_variables() ;
Variables init_variables()
{
    Variables vars;
    vars.le = 0;
    vars.xunhuan = 0;
    return vars;
}
void solve()
{
    int prime_numbers[28];
    char input_string[108];
    Variables vars;
    int difference;
    int i, j, k;
    int max_count;
    int min_count;
    int a[26] = {0};

    vars = init_variables();
    scanf("%s", input_string);
    vars.le = strlen(input_string);

    for (i = 0; i < vars.le; ++i)
    {
        vars.xunhuan = input_string[i];
        ++a[vars.xunhuan - 'a'];
    }

    prime_numbers[0] = 2;
    prime_numbers[1] = 3;
    prime_numbers[2] = 5;
    prime_numbers[3] = 7;
    prime_numbers[4] = 11;
    prime_numbers[5] = 13;
    prime_numbers[6] = 17;
    prime_numbers[7] = 19;
    prime_numbers[8] = 23;
    prime_numbers[9] = 29;
    prime_numbers[10] = 31;
    prime_numbers[11] = 37;
    prime_numbers[12] = 41;
    prime_numbers[13] = 43;
    prime_numbers[14] = 47;
    prime_numbers[15] = 53;
    prime_numbers[16] = 59;
    prime_numbers[17] = 61;
    prime_numbers[18] = 67;
    prime_numbers[19] = 71;
    prime_numbers[20] = 73;
    prime_numbers[21] = 79;
    prime_numbers[22] = 83;
    prime_numbers[23] = 89;
    prime_numbers[24] = 97;

    min_count = 9999;
    max_count = -500;

    for (j = 0; j <= 25; ++j)
    {
        if (min_count > a[j] && a[j])
            min_count = a[j];
    }

    for (j = 0; j <= 25; ++j)
    {
        if (max_count < a[j])
            max_count = a[j];
    }

    difference = max_count - min_count;

    for (k = 0; k <= 24; ++k)
    {
        if (difference == prime_numbers[k])
        {
            printf("Lucky Word\n%d", difference);
            return;
        }
    }

    printf("No Answer\n0");
}
int main()
{
    solve();
    return 0;
}