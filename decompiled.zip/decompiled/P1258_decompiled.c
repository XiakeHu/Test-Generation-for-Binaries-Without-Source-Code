#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

bool check(double x, double y) ;
double read() ;
double work1(double mid, double a, double b) ;
double work2(double mid, double s, double a, double b) ;
 bool check(double x, double y); double work2(double mid, double s, double a, double b); double read(); double work1(double mid, double a, double b);  int main() ;
bool check(double x, double y)
{
    return x > y;
}
double read()
{
    char current_char;
    double sign_factor;
    double result_value;

    result_value = 0.0;
    sign_factor = 1.0;
    for ( current_char = getchar(); current_char <= 47 || current_char > 57; current_char = getchar() )
    {
        if ( current_char == 45 )
            sign_factor = -1.0;
    }
    while ( current_char > 47 && current_char <= 57 )
    {
        result_value = (double)current_char + result_value * 10.0 - 48.0;
        current_char = getchar();
    }
    return result_value * sign_factor;
}
double work1(double mid, double a, double b)
{
    double result = 0.0;
    result += mid / b;
    result += (mid - 1.0) / a;
    return result;
}
double work2(double mid, double s, double a, double b)
{
    double result = 0.0;
    
    double term1 = mid / b;
    result += term1;
    
    double term2 = (mid - term1 * a) / (a + b);
    result += term2;
    
    double term3 = (s - (term2 * a + term1 * a)) / b;
    result += term3;
    
    return result;
}
int main()
{
    double s = read();
    double a = read();
    double b = read();

    double left_bound = 1.0;
    double right_bound = s;

    while (right_bound >= left_bound)
    {
        double mid_value = (left_bound + right_bound) / 2.0;
        double time1 = work1(mid_value, a, b);
        double time2 = work2(mid_value, s, a, b);

        if (check(time1, time2))
        {
            left_bound = mid_value;
        }
        else
        {
            right_bound = mid_value;
        }

        if (fabs(time1 - time2) < 0.0000001)
        {
            printf("%.6lf", time1);
            return 0;
        }
    }

    return 0;
}