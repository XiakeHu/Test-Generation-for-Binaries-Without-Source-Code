#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

long long n, m;
long long a[2005];
long long b[2005];
long long c[4005];
int flag[4005];
long long ans;

int compare(const void *a, const void *b) ;
long long find(long long key) ;
void read(long long *x) ;
int main() ;
int compare(const void *a, const void *b)
{
    long long value_a = *(const long long *)a;
    long long value_b = *(const long long *)b;

    if (value_a == value_b)
        return 0;
    if (value_a > value_b)
        return 1;
    return -1;
}
long long find(long long key)
{
    int index;
    for (index = 1; index <= m; ++index)
    {
        if (key == c[index])
            return index;
    }
    return -1LL;
}
void read(long long *x)
{
    char ch;
    long long sign;

    sign = 1LL;
    for (ch = getchar(); ch <= 47 || ch > 57; ch = getchar())
    {
        if (ch == '-')
            sign = -1LL;
    }
    *x = 0LL;
    while (ch > 47 && ch <= 57)
    {
        *x = 10 * *x + ch - '0';
        ch = getchar();
    }
    *x *= sign;
}
int main()
{
    long long i;
    int j;
    long long i_0;
    long long i_1;

    m = 0;
    ans = 0;
    for (i = 0; i < 4005; ++i) flag[i] = 0;

    read(&n);
    for (i = 1; i <= n; ++i)
    {
        read(&a[i]);
        read(&b[i]);
        m++;
        c[m] = a[i];
        m++;
        c[m] = b[i];
    }
    qsort(&c[1], m, sizeof(long long), compare);
    for (i_0 = 1; i_0 <= n; ++i_0)
    {
        a[i_0] = find(a[i_0]);
        b[i_0] = find(b[i_0]) - 1;
        for (j = a[i_0]; j <= b[i_0]; ++j)
            flag[j] = 1;
    }
    for (i_1 = 1; i_1 < m; ++i_1)
    {
        if (flag[i_1])
            ans += c[i_1 + 1] - c[i_1];
    }
    printf("%lld", ans);
    return 0;
}