#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

#define MAX_CNT 1000
#define STR_LEN 100
#define HASH_SIZE 1000

char data[MAX_CNT][STR_LEN];
int nexty[MAX_CNT];
int hashy[HASH_SIZE];
int cnt = 0;

bool hash_find(char *zfc) ;
void hash_insert(char *zfc) ;
void dy(char *zfc) ;
int main() ;
bool hash_find(char *zfc)
{
    int length;
    int i;
    int hash_value;
    int u;

    length = strlen(zfc);
    hash_value = 0;
    for (i = 0; i < length; ++i)
        hash_value = (437 * zfc[i] + hash_value) % 997;
    for (u = hashy[hash_value]; u; u = nexty[u])
    {
        if (!strcmp(data[u], zfc))
            return 1;
    }
    return 0;
}
void hash_insert(char *zfc)
{
    int length;
    int i;
    int hash_value;

    length = strlen(zfc);
    hash_value = 0;
    for (i = 0; i < length; ++i)
        hash_value = (437 * zfc[i] + hash_value) % 997;
    strcpy(data[++cnt], zfc);
    nexty[cnt] = hashy[hash_value];
    hashy[hash_value] = cnt;
}
void dy(char *zfc)
{
    int index;
    char current_char;

    index = 0;
    current_char = getchar();

    while (current_char != 32 && (current_char <= 47 || current_char > 57) && (current_char <= 64 || current_char > 122))
    {
        current_char = getchar();
    }

    while (current_char == 32 || (current_char > 47 && current_char <= 57) || (current_char > 64 && current_char <= 122))
    {
        zfc[index] = current_char;
        index++;
        current_char = getchar();
    }
    zfc[index] = '\0';
}
int main()
{
    int day = 0;
    int n, m;
    char dr[STR_LEN];
    scanf("%d %d", &n, &m);
    getchar();
    
    for (int i = 0; i < n; ++i)
    {
        memset(dr, 0, sizeof(dr));
        dy(dr);
        hash_insert(dr);
    }
    
    for (int i = 0; i < m; ++i)
    {
        memset(dr, 0, sizeof(dr));
        dy(dr);
        if (hash_find(dr))
            ++day;
    }
    
    printf("%d", day);
    return 0;
}