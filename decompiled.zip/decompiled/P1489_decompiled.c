#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int n, ans, x, y, s;
int a[1005];
int p[1005];

int calc();
void sa();
void wrt(int x);
int rd();
void MAIN();

int calc()
{
    int i;
    int cnt;

    cnt = 0;
    for (i = 1; i <= n >> 1; ++i)
        cnt += a[p[i]];
    return cnt;
}
void sa()
{
    int delta;
    double probability;
    int temp_value;
    int temp_result;
    int swap_index_y;
    int swap_index_x;
    double temperature;

    for (temperature = 5000.0; temperature > 1.0e-15; temperature = temperature * 0.997)
    {
        swap_index_x = rand() % n + 1;
        do
        {
            swap_index_y = rand() % n + 1;
        } while (swap_index_x == swap_index_y);

        temp_value = p[swap_index_x];
        p[swap_index_x] = p[swap_index_y];
        p[swap_index_y] = temp_value;

        temp_result = calc();
        delta = s - 2 * temp_result;
        if (delta <= 0)
        {
            delta = 2 * temp_result - s;
        }

        if (delta - ans >= 0)
        {
            probability = exp((double)(ans - delta) / temperature);
            if (probability > (double)rand() / 2147483647.0)
            {
                temp_value = p[swap_index_x];
                p[swap_index_x] = p[swap_index_y];
                p[swap_index_y] = temp_value;
            }
        }
        else
        {
            ans = delta;
            x = temp_result;
            y = s - temp_result;
        }
    }
}
void wrt(int x)
{
    int absolute_value;
    int divisor;
    int digit_count;

    absolute_value = x;
    divisor = 10;
    digit_count = 1;
    if (x < 0)
    {
        absolute_value = -x;
        putchar('-');
    }
    while (divisor <= absolute_value)
    {
        ++digit_count;
        divisor *= 10;
    }
    while (digit_count--)
    {
        divisor /= 10;
        putchar(absolute_value / divisor + '0');
        absolute_value %= divisor;
    }
}
int rd()
{
    char current_char;
    int sign;
    int value;

    value = 0;
    sign = 1;
    for ( current_char = getchar(); current_char <= 47 || current_char > 57; current_char = getchar() )
    {
        if ( current_char == 45 )
            sign = -1;
    }
    while ( current_char > 47 && current_char <= 57 )
    {
        value = 10 * value + current_char - 48;
        current_char = getchar();
    }
    return sign * value;
}
void MAIN()
{
    int min_val;
    int max_val;
    int i;

    n = rd();
    s = 0;
    for (i = 1; i <= n; ++i)
    {
        p[i] = i;
        a[i] = rd();
        s += a[i];
    }
    ans = 0;
    if (n == 1)
    {
        wrt(0);
        putchar(' ');
        wrt(a[1]);
    }
    else
    {
        while ((double)clock() / 1000000.0 < 0.99)
            sa();
        min_val = x;
        if (y <= x)
            min_val = y;
        wrt(min_val);
        putchar(' ');
        max_val = x;
        if (y >= x)
            max_val = y;
        wrt(max_val);
    }
}
int main(int argc, const char **argv, const char **envp)
{
    srand(time(NULL));
    MAIN();
    return 0;
}