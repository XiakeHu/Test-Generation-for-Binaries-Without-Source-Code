#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

typedef struct {
    unsigned int year;
    unsigned int month;
    unsigned int day;
    unsigned int hour;
    unsigned int minute;
    unsigned int second;
} Calender;

bool is_runnian(unsigned int year);
unsigned int getDaysInMonth(Calender *this, unsigned int y, unsigned int m);
int compare(const void *a, const void *b);
void CalenderWrite(Calender *this, unsigned int ye, unsigned int mo, unsigned int da, unsigned int ho, unsigned int mi, unsigned int se);
unsigned long long getStandardTime(Calender *this);
int main();

static const unsigned int daysNum[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

bool is_runnian(unsigned int year)
{
    if (year % 400 == 0)
        return true;
    if (year % 100 != 0)
        return (year % 4) == 0;
    return false;
}

unsigned int getDaysInMonth(Calender *this, unsigned int y, unsigned int m)
{
    if (m != 2)
        return daysNum[m];
    if (is_runnian(y))
        return 29;
    return 28;
}

int compare(const void *a, const void *b)
{
    int value_a = *(const int *)a;
    int value_b = *(const int *)b;

    if (value_a < value_b)
        return -1;
    else if (value_a > value_b)
        return 1;
    else
        return 0;
}

void CalenderWrite(
        Calender *this,
        unsigned int ye,
        unsigned int mo,
        unsigned int da,
        unsigned int ho,
        unsigned int mi,
        unsigned int se)
{
    this->year = ye;
    this->month = mo;
    this->day = da;
    this->hour = ho;
    this->minute = mi;
    this->second = se;
}

unsigned long long getStandardTime(Calender *this)
{
    unsigned int month_counter;
    unsigned int hour_counter;
    unsigned int day_counter;
    unsigned int month_loop;
    unsigned int year_counter;
    unsigned long long total_seconds;

    total_seconds = 0ULL;
    for (year_counter = 0; year_counter < this->year; ++year_counter)
    {
        if (is_runnian(year_counter))
            total_seconds += 31622400ULL;
        else
            total_seconds += 31536000ULL;
    }
    for (month_loop = 1; month_loop < this->month; ++month_loop)
        total_seconds += 86400ULL * getDaysInMonth(this, this->year, month_loop);
    for (day_counter = 1; day_counter < this->day; ++day_counter)
        total_seconds += 86400ULL;
    for (hour_counter = 0; hour_counter < this->hour; ++hour_counter)
        total_seconds += 3600ULL;
    for (month_counter = 0; month_counter < this->minute; ++month_counter)
        total_seconds += 60ULL;
    return this->second + total_seconds;
}

int main()
{
    unsigned int n;
    unsigned int task_durations[5005];
    unsigned int total_duration = 0;
    unsigned int answer = 0;
    unsigned long long time_left_minutes;
    Calender begin_time;
    Calender end_time;
    unsigned int year, month, day, hour, minute;

    scanf("%u", &n);
    for (unsigned int i = 0; i < n; ++i)
        scanf("%u", &task_durations[i]);

    qsort(task_durations, n, sizeof(unsigned int), compare);

    for (unsigned int i = 0; i < n; ++i)
        total_duration += task_durations[i];

    scanf("%u-%u-%u-%u:%u", &year, &month, &day, &hour, &minute);
    CalenderWrite(&begin_time, year, month, day, hour, minute, 0);

    scanf("%u-%u-%u-%u:%u", &year, &month, &day, &hour, &minute);
    CalenderWrite(&end_time, year, month, day, hour, minute, 0);

    unsigned long long end_seconds = getStandardTime(&end_time);
    unsigned long long begin_seconds = getStandardTime(&begin_time);
    time_left_minutes = (end_seconds - begin_seconds) / 60;

    for (unsigned int i = 0; i < n && time_left_minutes >= task_durations[i]; ++i)
    {
        time_left_minutes -= task_durations[i];
        ++answer;
    }

    printf("%u\n", answer);
    return 0;
}