#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

char a1[1000];
long long a[1000];
long long c[1000];
long long b;
long long d;
long long len;
long long lenc;

int main()
{
    int leading_zero_index;
    int division_loop_index;
    int conversion_loop_index;

    scanf("%s %lld", a1, &b);

    len = strlen(a1);

    for (conversion_loop_index = 0; conversion_loop_index < len; ++conversion_loop_index)
        a[conversion_loop_index] = a1[conversion_loop_index] - '0';

    d = 0;
    for (division_loop_index = 0; division_loop_index < len; ++division_loop_index)
    {
        c[division_loop_index] = (10 * d + a[division_loop_index]) / b;
        d = (10 * d + a[division_loop_index]) % b;
    }

    lenc = 0;
    while (lenc < len && c[lenc] == 0)
        ++lenc;

    if (lenc == len) {
        printf("0");
    } else {
        for (leading_zero_index = lenc; leading_zero_index < len; ++leading_zero_index)
            printf("%lld", c[leading_zero_index]);
    }

    return 0;
}