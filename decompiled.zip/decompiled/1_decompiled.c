#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#define MAX_SIZE 50

typedef struct {
    char name[20];
    int scores[5];
    float average;
} Student;

int count = 0;
Student students[MAX_SIZE];
const char *subjects[] = {"数学", "语文", "英语", "物理", "化学"};
const char asc_30D5[] = "各科统计";
const char byte_30F8[] = "科目";
const char byte_30B2[] = "平均分";
const char byte_30EE[] = "最高分";
const char byte_30E4[] = "最低分";
const char byte_309F[] = "姓名";
const char asc_312B[] = "成绩排名";
const char byte_313A[] = "排名";

void showStats();
void inputData();
void showAll();
void showRank();
void showGradeDist();

void showStats() {
    int i;
    int s;
    int sum;
    int max;
    int min;
    int i_0;
    int score;

    puts(asc_30D5);
    printf("%-6s %-8s %-8s %-8s\n", byte_30F8, byte_30B2, byte_30EE, byte_30E4);
    for (i = 0; i <= 39; ++i)
        putchar(45);
    putchar(10);
    for (s = 0; s <= 4; ++s) {
        sum = 0;
        max = 0;
        min = 100;
        for (i_0 = 0; i_0 < count; ++i_0) {
            score = students[i_0].scores[s];
            sum += score;
            if (score > max)
                max = students[i_0].scores[s];
            if (score < min)
                min = students[i_0].scores[s];
        }
        printf("%-6s %-8.1f %-8d %-8d\n", subjects[s], (float)((float)sum / (float)count), max, min);
    }
}

void inputData() {
    float temp_float;
    int temp_int;
    Student *temp_student;
    int total;
    int i;
    int i2;
    int total2;
    int j;
    Student examples[5];
    char line[104];

    puts("请输入学生数据（格式：姓名 分数1 分数2 分数3 分数4 分数5），空行结束：");
    while (fgets(line, 100, stdin) && line[0] != '\n' && count <= 49) {
        if (sscanf(line, "%s %d %d %d %d %d",
                   examples[0].name,
                   &examples[0].scores[0],
                   &examples[0].scores[1],
                   &examples[0].scores[2],
                   &examples[0].scores[3],
                   &examples[0].scores[4]) == 6) {
            total = 0;
            for (i = 0; i <= 4; ++i) {
                total += examples[0].scores[i];
            }
            temp_float = (float)total / 5.0f;
            examples[0].average = temp_float;
            temp_int = count++;
            // 使用memcpy安全拷贝结构体数据
            memcpy(&students[temp_int], &examples[0], sizeof(Student));
        }
    }
    if (!count) {
        // 修正示例数据，使用strcpy安全拷贝姓名
        strcpy(examples[0].name, "张三");
        examples[0].scores[0] = 85;
        examples[0].scores[1] = 92;
        examples[0].scores[2] = 78;
        examples[0].scores[3] = 88;
        examples[0].scores[4] = 90;
        examples[0].average = 0.0f;
        
        strcpy(examples[1].name, "李四");
        examples[1].scores[0] = 92;
        examples[1].scores[1] = 88;
        examples[1].scores[2] = 95;
        examples[1].scores[3] = 87;
        examples[1].scores[4] = 91;
        examples[1].average = 0.0f;
        
        strcpy(examples[2].name, "王五");
        examples[2].scores[0] = 78;
        examples[2].scores[1] = 85;
        examples[2].scores[2] = 82;
        examples[2].scores[3] = 79;
        examples[2].scores[4] = 84;
        examples[2].average = 0.0f;
        
        strcpy(examples[3].name, "赵六");
        examples[3].scores[0] = 65;
        examples[3].scores[1] = 72;
        examples[3].scores[2] = 68;
        examples[3].scores[3] = 70;
        examples[3].scores[4] = 67;
        examples[3].average = 0.0f;
        
        strcpy(examples[4].name, "钱七");
        examples[4].scores[0] = 95;
        examples[4].scores[1] = 98;
        examples[4].scores[2] = 96;
        examples[4].scores[3] = 94;
        examples[4].scores[4] = 97;
        examples[4].average = 0.0f;
        
        for (i2 = 0; i2 <= 4; ++i2) {
            total2 = 0;
            for (j = 0; j <= 4; ++j) {
                total2 += examples[i2].scores[j];
            }
            temp_float = (float)total2 / 5.0f;
            examples[i2].average = temp_float;
            temp_int = count++;
            // 使用memcpy安全拷贝结构体数据
            memcpy(&students[temp_int], &examples[i2], sizeof(Student));
        }
    }
}

void showAll() {
    int i;
    int i_0;
    int i_1;
    int j;

    printf("\n%-8s ", byte_309F);
    for (i = 0; i <= 4; ++i)
        printf("%-6s", subjects[i]);
    printf("%-8s\n", byte_30B2);
    for (i_0 = 0; i_0 <= 59; ++i_0)
        putchar(45);
    putchar(10);
    for (i_1 = 0; i_1 < count; ++i_1) {
        printf("%-8s ", students[i_1].name);
        for (j = 0; j <= 4; ++j)
            printf("%-6d", students[i_1].scores[j]);
        printf("%-8.1f\n", students[i_1].average);
    }
}

void showRank() {
    int i;
    int j;
    int i_0;
    int i_1;
    Student temp;

    for (i = 0; i < count - 1; ++i) {
        for (j = 0; j < count - i - 1; ++j) {
            if (students[j + 1].average > students[j].average) {
                // 使用结构体整体交换，避免姓名截断问题
                memcpy(&temp, &students[j], sizeof(Student));
                memcpy(&students[j], &students[j + 1], sizeof(Student));
                memcpy(&students[j + 1], &temp, sizeof(Student));
            }
        }
    }
    
    puts(asc_312B);
    printf("%-4s %-8s %-8s\n", byte_313A, byte_309F, byte_30B2);
    for (i_0 = 0; i_0 <= 24; ++i_0) {
        putchar(45);
    }
    putchar(10);
    for (i_1 = 0; i_1 < count; ++i_1) {
        printf("%-4d %-8s %-8.1f\n", i_1 + 1, students[i_1].name, students[i_1].average);
    }
}

void showGradeDist() {
    int i;
    unsigned int levels[5] = {0};
    
    for (i = 0; i < count; ++i) {
        if (students[i].average >= 90.0) {
            levels[0]++;
        } else if (students[i].average >= 80.0) {
            levels[1]++;
        } else if (students[i].average >= 70.0) {
            levels[2]++;
        } else if (students[i].average >= 60.0) {
            levels[3]++;
        } else {
            levels[4]++;
        }
    }
    
    puts("\n等级分布:");
    printf("A(90+): %d人 ", levels[0]);
    printf("B(80-89): %d人 ", levels[1]);
    printf("C(70-79): %d人 ", levels[2]);
    printf("D(60-69): %d人 ", levels[3]);
    printf("F(<60): %d人\n", levels[4]);
}

int main() {
    float totalAvg;
    int passCount;
    int i;

    puts("=== 学生成绩管理系统 ===");
    inputData();
    printf("\n当前共有 %d 名学生\n", count);
    showAll();
    showStats();
    showRank();
    showGradeDist();
    totalAvg = 0.0;
    passCount = 0;
    for (i = 0; i < count; ++i) {
        totalAvg = students[i].average + totalAvg;
        if (students[i].average >= 60.0)
            ++passCount;
    }
    puts("\n=== 总体统计 ===");
    printf("平均分: %.1f\n", totalAvg / (float)count);
    printf("及格率: %.1f%%\n", 100.0 * (float)passCount / (float)count);
    return 0;
}