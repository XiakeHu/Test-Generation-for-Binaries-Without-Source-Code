#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAXN 200005

struct Edge {
    int to, nxt;
} edge[MAXN * 2];

int fst[MAXN], tot;
int vis[MAXN], sz[MAXN], Centered[MAXN];
long long val[MAXN];
int Total_Size, Min_Weight, Center;
int SubTree_Sum[4], SubTree_Max[4];
int Pre_Sum[4], Pre_Max[4];
long long Max_Val, Sum;
int n;

void Get_Center(int x);
void Work_SubTree(int x, int dis_root);
void Add_Edge(int f, int t);
void Divide(int x, int Size);

void Get_Center(int x)
{
    int neighbor;
    int current_edge;
    int max_subtree_size;

    vis[x] = 1;
    sz[x] = 1;
    max_subtree_size = 0;

    for (current_edge = fst[x]; current_edge; current_edge = edge[current_edge].nxt)
    {
        neighbor = edge[current_edge].to;
        if (!vis[neighbor] && !Centered[neighbor])
        {
            Get_Center(neighbor);
            sz[x] += sz[neighbor];
            if (sz[neighbor] > max_subtree_size)
            {
                max_subtree_size = sz[neighbor];
            }
        }
    }

    int complement_size = Total_Size - sz[x];
    if (complement_size > max_subtree_size)
    {
        max_subtree_size = complement_size;
    }

    if (max_subtree_size < Min_Weight)
    {
        Min_Weight = max_subtree_size;
        Center = x;
    }

    vis[x] = 0;
}

void Work_SubTree(int x, int dis_root)
{
    int neighbor_node;
    int edge_index;

    if (dis_root <= 2)
    {
        vis[x] = 1;
        SubTree_Sum[dis_root] = (SubTree_Sum[dis_root] + val[x]) % 10007;
        if (val[x] > SubTree_Max[dis_root]) SubTree_Max[dis_root] = val[x];
        for (edge_index = fst[x]; edge_index; edge_index = edge[edge_index].nxt)
        {
            neighbor_node = edge[edge_index].to;
            if (!Centered[neighbor_node] && !vis[neighbor_node])
                Work_SubTree(neighbor_node, dis_root + 1);
        }
        vis[x] = 0;
    }
}

void Add_Edge(int f, int t)
{
    tot++;
    edge[tot].nxt = fst[f];
    edge[tot].to = t;
    fst[f] = tot;
}

void Divide(int x, int Size)
{
    int current_center;
    int neighbor;
    int neighbor_2;
    int current_edge;
    int current_edge_2;
    int i;
    int j;

    Min_Weight = 2000000000;
    Total_Size = Size;
    Get_Center(x);
    current_center = Center;
    Centered[current_center] = 1;
    Pre_Max[0] = val[current_center];
    Pre_Sum[0] = Pre_Max[0] % 10007;

    for (current_edge = fst[current_center]; current_edge; current_edge = edge[current_edge].nxt)
    {
        neighbor = edge[current_edge].to;
        if (!Centered[neighbor])
        {
            memset(SubTree_Sum, 0, sizeof(SubTree_Sum));
            memset(SubTree_Max, 0, sizeof(SubTree_Max));
            Work_SubTree(neighbor, 1);
            for (i = 0; i <= 2; ++i)
            {
                long long prod = (long long)Pre_Max[i] * SubTree_Max[2 - i];
                if (prod > Max_Val) Max_Val = prod;
                Sum = (Sum + (long long)SubTree_Sum[2 - i] * Pre_Sum[i]) % 10007;
            }
            for (j = 0; j <= 2; ++j)
            {
                if (SubTree_Max[j] > Pre_Max[j]) Pre_Max[j] = SubTree_Max[j];
                Pre_Sum[j] = (Pre_Sum[j] + SubTree_Sum[j]) % 10007;
            }
        }
    }

    for (current_edge_2 = fst[current_center]; current_edge_2; current_edge_2 = edge[current_edge_2].nxt)
    {
        neighbor_2 = edge[current_edge_2].to;
        if (!Centered[neighbor_2])
        {
            Divide(neighbor_2, sz[neighbor_2]);
        }
    }
}

int main()
{
    int to;
    int from;
    int i_0;
    int i;

    scanf("%d", &n);
    for (i = 1; i < n; ++i)
    {
        scanf("%d%d", &from, &to);
        Add_Edge(from, to);
        Add_Edge(to, from);
    }
    for (i_0 = 1; i_0 <= n; ++i_0)
        scanf("%lld", &val[i_0]);
    Max_Val = 0;
    Sum = 0;
    Divide(1, n);
    printf("%lld %lld", Max_Val, (2 * Sum) % 10007);
    return 0;
}