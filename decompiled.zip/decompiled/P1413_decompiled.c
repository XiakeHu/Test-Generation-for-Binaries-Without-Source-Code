#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int s;
    int t;
}node;

int cmp(const void *a, const void *b) ;
int main() ;

node a[1000];
int n;
int ans;

int cmp(const void *a, const void *b)
{
    const node *node_a = (const node *)a;
    const node *node_b = (const node *)b;
    
    if (node_a->s == node_b->s)
        return node_a->t - node_b->t;
    else
        return node_a->s - node_b->s;
}
int main()
{
    int current_start;
    int current_end;
    int outer_index;
    int inner_index;

    ans = 0;
    scanf("%d", &n);
    for (inner_index = 1; inner_index <= n; ++inner_index)
        scanf("%d%d", &a[inner_index].s, &a[inner_index].t);
    qsort(&a[1], n, sizeof(node), cmp);
    outer_index = 1;
    while (outer_index <= n)
    {
        current_start = a[outer_index].s;
        current_end = a[outer_index].t;
        ++outer_index;
        while (outer_index <= n && current_start == a[outer_index].s)
        {
            if (current_end < a[outer_index].t - 59)
            {
                ++ans;
                current_end = a[outer_index].t;
            }
            ++outer_index;
        }
        ++ans;
    }
    printf("%d", ans);
    return 0;
}