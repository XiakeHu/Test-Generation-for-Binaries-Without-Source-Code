#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>
#define MAX_M 1005

int m, k;
int p[MAX_M];
int s[MAX_M];

typedef struct {
    int from;
    int to;
} once;

once sep[MAX_M];

bool check(int maxn) ;
void sort_print(int maxn) ;
void binary_search(int l, int r) ;
int main() ;
bool check(int maxn)
{
    int group = 0;
    for (int i = 1; i <= m; ++i)
    {
        if (++group == k + 1)
        {
            return false;
        }
        for (int j = i; j <= m; ++j)
        {
            if (maxn < s[j] - s[j - 1])
            {
                return false;
            }
            if (maxn < s[j] - s[i - 1])
            {
                i = j - 1;
                break;
            }
            if (j == m)
            {
                i = m;
            }
        }
    }
    return true;
}
void sort_print(int maxn)
{
    int j;
    int i;
    int group;

    group = 0;
    for (i = m; i > 0; --i)
    {
        ++group;
        for (j = i; j > 0; --j)
        {
            if (maxn < s[i] - s[j - 1])
            {
                i = j + 1;
                break;
            }
            sep[group].from = j;
            sep[group].to = i;
            if (j == 1)
                i = 1;
        }
    }
}
void binary_search(int l, int r)
{
    int mid;

    while (l <= r)
    {
        mid = (l + r) / 2;
        if (check(mid))
            r = mid - 1;
        else
            l = mid + 1;
    }
    sort_print(l);
}
int main()
{
    int outer_i;
    int i;

    scanf("%d %d", &m, &k);
    if (!m)
        return 0;
    for (i = 1; i <= m; ++i)
    {
        scanf("%d", &p[i]);
        s[i] = p[i] + s[i - 1];
    }
    binary_search((s[m] - s[0]) / k, s[m] - s[0]);
    for (outer_i = k; outer_i > 0; --outer_i)
        printf("%d %d\n", sep[outer_i].from, sep[outer_i].to);
    return 0;
}