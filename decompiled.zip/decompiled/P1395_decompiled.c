#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int dt;
    struct Node *next;
} Node;

typedef struct {
    Node *head;
} Graph;

Graph *g;
int n, sum, ans, *t, road;
Node *q;

void add(int x, int y);
int dfs(int x, int fa);
void bfs();

void add(int x, int y) {
    Node *new_node = (Node *)malloc(sizeof(Node));
    new_node->dt = y;
    new_node->next = g[x].head;
    g[x].head = new_node;
}

int dfs(int x, int fa) {
    Node *current_node;
    int subtree_size = 0;
    int max_child_size = 0;
    int child_size;

    for (current_node = g[x].head; current_node; current_node = current_node->next) {
        if (fa != current_node->dt) {
            child_size = dfs(current_node->dt, x);
            subtree_size += child_size;
            if (max_child_size < child_size) {
                max_child_size = child_size;
            }
        }
    }
    int candidate;
    if (max_child_size >= n - subtree_size) {
        candidate = max_child_size;
    } else {
        candidate = n - subtree_size - 1;
    }
    if (candidate < sum || (candidate == sum && x < ans)) {
        sum = candidate;
        ans = x;
    }
    return subtree_size + 1;
}

void bfs() {
    Node *new_node;
    int neighbor_value;
    Node *node_to_free;
    int current_value;
    Node *current_node;
    Node *adj_iter;

    current_node = (Node *)malloc(sizeof(Node));
    current_node->dt = ans;
    current_node->next = q;
    q = current_node;

    while (q) {
        current_value = q->dt;
        node_to_free = q;
        q = q->next;
        free(node_to_free);

        for (adj_iter = g[current_value].head; adj_iter; adj_iter = adj_iter->next) {
            neighbor_value = adj_iter->dt;
            if (!t[neighbor_value] && neighbor_value != ans) {
                t[neighbor_value] = t[current_value] + 1;
                road += t[neighbor_value];
                new_node = (Node *)malloc(sizeof(Node));
                new_node->dt = neighbor_value;
                new_node->next = q;
                q = new_node;
            }
        }
    }
}

int main() {
    int to, from, i;
    scanf("%d", &n);
    g = (Graph *)malloc((n + 1) * sizeof(Graph));
    t = (int *)calloc(n + 1, sizeof(int));
    for (i = 1; i <= n; ++i) {
        g[i].head = NULL;
    }
    sum = n + 1;
    ans = 0;
    road = 0;
    q = NULL;

    for (i = 1; i < n; ++i) {
        scanf("%d %d", &from, &to);
        add(from, to);
        add(to, from);
    }
    dfs(1, 0);
    bfs();
    printf("%d %d\n", ans, road);

    for (i = 1; i <= n; ++i) {
        Node *cur = g[i].head;
        while (cur) {
            Node *tmp = cur;
            cur = cur->next;
            free(tmp);
        }
    }
    free(g);
    free(t);
    return 0;
}