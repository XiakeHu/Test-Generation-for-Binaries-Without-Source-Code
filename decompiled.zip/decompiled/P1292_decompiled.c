#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int x, y, a, b, gcd;

int read();
void exgcd(int a, int b);
int main();

int read()
{
    char current_char;
    int sign = 1;
    int value = 0;

    current_char = getchar();
    while ((current_char - '0') > 9 && current_char != '-')
        current_char = getchar();

    if (current_char == '-')
        sign = -1;

    while ((current_char - '0') <= 9)
    {
        value = 10 * value + (current_char - '0');
        current_char = getchar();
    }

    return value * sign;
}
void exgcd(int a, int b)
{
    int temp_x;

    if (b != 0)
    {
        exgcd(b, a % b);
        temp_x = x;
        x = y;
        y = temp_x - y * (a / b);
    }
    else
    {
        x = 1;
        y = 0;
        gcd = a;
    }
}
int main()
{
    int a_temp;
    int x_temp;
    int adjustment_x;
    int adjustment_y;

    a = read();
    b = read();
    exgcd(a, b);

    if (x >= 0)
        x_temp = 0;
    else
        x_temp = -x;

    while (x_temp < 0 || y < 0)
    {
        if (x >= 0)
            adjustment_x = 0;
        else
            adjustment_x = b / gcd;
        x_temp += adjustment_x;

        if (x < 0)
            adjustment_y = 0;
        else
            adjustment_y = a / gcd;
        y -= adjustment_y;
    }

    printf("%d %d", gcd, x_temp);
    return 0;
}