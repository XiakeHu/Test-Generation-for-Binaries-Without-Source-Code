#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int first;
    int second;
} Pair;

int Floor;
char tree[2000 * 2000];
int m, n;
int tmp1, tmp2;

Pair find_tree(int x, int y);
void print_tree();
void make_tree();
void delete_tree(Pair x);
int main();

Pair find_tree(int x, int y)
{
    int j;
    int i;
    int cnt2;
    int cnt1;

    cnt1 = 0;
    cnt2 = 0;
    i = 1;
    j = Floor;
    while (i <= Floor && j > 0)
    {
        if (tree[2000 * i + j] == 111 || tree[2000 * i + j] == 42)
            ++cnt1;
        if (cnt1 == x)
            break;
        ++i;
        --j;
    }
    while (j <= 2 * Floor)
    {
        if (tree[2000 * i + j] == 111 || tree[2000 * i + j] == 42)
            ++cnt2;
        if (cnt2 == y)
            break;
        ++j;
    }
    Pair result;
    result.first = i;
    result.second = j;
    return result;
}
void print_tree()
{
    int row;
    int col;

    for (row = 1; row <= Floor; ++row)
    {
        for (col = 1; col <= 2 * Floor; ++col)
        {
            char current_char = tree[2000 * row + col];
            if (current_char == 42 || current_char == 45)
            {
                putchar(' ');
            }
            else
            {
                putchar(current_char);
            }
        }
        putchar('\n');
    }
}
void make_tree()
{
    int row;
    int col;
    int current_row;
    int current_col;
    int is_branch_start;

    for (row = 1; row <= Floor; ++row)
    {
        for (col = 1; col <= Floor - row; ++col)
            tree[2000 * row + col] = 32;
    }
    for (current_row = Floor; current_row > 0; --current_row)
    {
        is_branch_start = 0;
        for (current_col = 1; current_col <= 2 * Floor; ++current_col)
        {
            if (current_col % 6 == 1
                || current_col % 6 == 5 && current_row == Floor
                || tree[2000 * current_row + 1999 + current_col] == 47 && tree[2000 * current_row + 2001 + current_col] == 92)
            {
                tree[2000 * current_row + current_col] = 111;
            }
            else if ((tree[2000 * current_row + 1999 + current_col] == 111 || tree[2000 * current_row + 1999 + current_col] == 47)
                  && !is_branch_start
                  && tree[2000 * current_row - 2 + current_col] != 92)
            {
                tree[2000 * current_row + current_col] = 47;
                is_branch_start = 1;
            }
            else if ((tree[2000 * current_row + 2001 + current_col] == 111 || tree[2000 * current_row + 2001 + current_col] == 92) && is_branch_start)
            {
                tree[2000 * current_row + current_col] = 92;
                is_branch_start = 0;
            }
            else
            {
                tree[2000 * current_row + current_col] = 32;
            }
        }
    }
}
void delete_tree(Pair x)
{
    tree[2000 * x.first + x.second] = 42;

    if (tree[2000 * (x.first - 1) + (x.second - 1)] == 92)
    {
        int row = x.first - 1;
        int col = x.second - 1;
        while (row > 0 && col > 0)
        {
            if (tree[2000 * row + col] == 92)
            {
                tree[2000 * row + col] = 45;
            }
            else if (tree[2000 * row + col] == 111)
            {
                break;
            }
            --row;
            --col;
        }
    }

    if (tree[2000 * (x.first - 1) + (x.second + 1)] == 47)
    {
        int row = x.first - 1;
        int col = x.second + 1;
        while (row > 0 && col <= 2 * Floor)
        {
            if (tree[2000 * row + col] == 47)
            {
                tree[2000 * row + col] = 45;
            }
            else if (tree[2000 * row + col] == 111)
            {
                break;
            }
            --row;
            ++col;
        }
    }

    int row = x.first + 1;
    int col = x.second - 1;
    while (row <= Floor && col > 0)
    {
        switch (tree[2000 * row + col])
        {
            case '/':
                tree[2000 * row + col] = 45;
                break;
            case '*':
                goto lower_right_start;
            case 'o':
            {
                Pair found = find_tree(row, col);
                delete_tree(found);
                goto lower_right_start;
            }
        }
        ++row;
        --col;
    }

lower_right_start:
    row = x.first + 1;
    col = x.second + 1;
    while (row <= Floor && col > 0)
    {
        switch (tree[2000 * row + col])
        {
            case '\\':
                tree[2000 * row + col] = 45;
                break;
            case '*':
                return;
            case 'o':
            {
                Pair found = find_tree(row, col);
                delete_tree(found);
                return;
            }
        }
        ++row;
        ++col;
    }
}
int main()
{
    Pair tree_position;
    int i;

    scanf("%d %d", &m, &n);
    Floor = (int)(pow(2.0, (double)(m - 2)) * 3.0);
    make_tree();
    for (i = 0; i < n; ++i)
    {
        scanf("%d %d", &tmp1, &tmp2);
        tree_position = find_tree(tmp1, tmp2);
        delete_tree(tree_position);
    }
    print_tree();
    return 0;
}