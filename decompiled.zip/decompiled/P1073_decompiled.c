#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAXN 100010

typedef struct edge {
    int v;
    struct edge *next;
} edge;

edge *head[MAXN];
edge *hh[MAXN];
edge *h[MAXN];
int low[MAXN];
int dfn[MAXN];
int ins[MAXN];
int sta[MAXN];
int top;
int tot;
int scc;
int val[MAXN];
int Max[MAXN];
int Min[MAXN];
int bel[MAXN];
int vis[MAXN];
int cnt;
int ind[MAXN];
int List[MAXN];
int n, m;
int U[MAXN];
int V[MAXN];
int z[MAXN];
int dp[MAXN];
int ans;

void tarjan(int u);
void dfs(int u);
void addedge(int u, int v);
void addd(int u, int v);
void toposort();
void add(int u, int v);

void tarjan(int u) {
    int neighbor_vertex;
    edge *current_edge;

    low[u] = ++tot;
    dfn[u] = low[u];
    ins[u] = 1;
    sta[++top] = u;

    for (current_edge = head[u]; current_edge != NULL; current_edge = current_edge->next) {
        neighbor_vertex = current_edge->v;

        if (dfn[neighbor_vertex]) {
            if (ins[neighbor_vertex]) {
                low[u] = (int)fmin((double)low[u], (double)dfn[neighbor_vertex]);
            }
        } else {
            tarjan(neighbor_vertex);
            low[u] = (int)fmin((double)low[u], (double)low[neighbor_vertex]);
        }
    }

    if (low[u] == dfn[u]) {
        ++scc;
        while (u != sta[top + 1]) {
            Max[scc] = (int)fmax((double)Max[scc], (double)val[sta[top]]);
            Min[scc] = (int)fmin((double)Min[scc], (double)val[sta[top]]);
            bel[sta[top]] = scc;
            ins[sta[top]] = 0;
            --top;
        }
    }
}

void dfs(int u)
{
    edge *current_edge;

    if (!vis[u])
    {
        vis[u] = 1;
        for (current_edge = hh[u]; current_edge; current_edge = current_edge->next)
        {
            dfs(current_edge->v);
        }
    }
}

void addedge(int u, int v)
{
    edge *new_edge;
    
    cnt++;
    new_edge = (edge *)malloc(sizeof(edge));
    
    new_edge->v = v;
    new_edge->next = head[u];
    head[u] = new_edge;
}

void addd(int u, int v)
{
    edge *new_edge = (edge *)malloc(sizeof(edge));
    new_edge->v = v;
    new_edge->next = hh[u];
    hh[u] = new_edge;
}

void toposort()
{
    int current_vertex;
    edge *current_edge;
    int outer_index;
    int inner_index;

    tot = 0;
    for (inner_index = 1; inner_index <= scc; ++inner_index)
    {
        if (!ind[inner_index])
            List[++tot] = inner_index;
    }
    for (outer_index = 1; outer_index <= tot; ++outer_index)
    {
        for (current_edge = h[List[outer_index]]; current_edge; current_edge = current_edge->next)
        {
            current_vertex = current_edge->v;
            ind[current_vertex] = ind[current_vertex] - 1;
            if (!ind[current_vertex])
                List[++tot] = current_vertex;
        }
    }
}

void add(int u, int v)
{
    edge *new_edge;

    cnt = cnt + 1;
    new_edge = (edge *)malloc(sizeof(edge));

    new_edge->v = v;
    new_edge->next = h[u];
    h[u] = new_edge;
}

int main()
{
    int y;
    int x;
    int v;
    int u;
    edge *current_edge;
    int i_5;
    int i_4;
    int i_3;
    int i_2;
    int i_1;
    int i_0;
    int i;

    memset(head, 0, sizeof(head));
    memset(hh, 0, sizeof(hh));
    memset(h, 0, sizeof(h));
    memset(dfn, 0, sizeof(dfn));
    memset(ins, 0, sizeof(ins));
    memset(vis, 0, sizeof(vis));
    memset(ind, 0, sizeof(ind));
    memset(bel, 0, sizeof(bel));
    cnt = 0;
    top = 0;
    tot = 0;
    scc = 0;
    ans = 0;

    scanf("%d %d", &n, &m);
    for (i = 1; i <= n; ++i)
        scanf("%d", &val[i]);
    for (i_0 = 1; i_0 <= n; ++i_0)
    {
        Min[i_0] = 1000000000;
        Max[i_0] = -1000000000;
    }
    for (i_1 = 1; i_1 <= m; ++i_1)
    {
        scanf("%d %d %d", &U[i_1], &V[i_1], &z[i_1]);
        addedge(U[i_1], V[i_1]);
        if (z[i_1] == 2)
            addedge(V[i_1], U[i_1]);
    }
    for (i_2 = 1; i_2 <= n; ++i_2)
    {
        if (!dfn[i_2])
            tarjan(i_2);
    }
    for (i_3 = 1; i_3 <= m; ++i_3)
    {
        x = bel[U[i_3]];
        y = bel[V[i_3]];
        if (x != y)
        {
            add(x, y);
            ++ind[y];
            addd(y, x);
            if (z[i_3] == 2)
            {
                add(y, x);
                ++ind[x];
                addd(x, y);
            }
        }
    }
    toposort();
    dfs(bel[n]);
    for (i_4 = 1; i_4 <= scc; ++i_4)
        dp[i_4] = Min[i_4];
    for (i_5 = 1; i_5 <= scc; ++i_5)
    {
        u = List[i_5];
        if (vis[u])
            ans = (int)fmax((double)ans, (double)(Max[u] - dp[u]));
        for (current_edge = h[u]; current_edge; current_edge = current_edge->next)
        {
            v = current_edge->v;
            dp[v] = (int)fmin((double)dp[v], (double)dp[u]);
        }
    }
    printf("%d", ans);
    return 0;
}