#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

int produce_prim_number(int *prim) ;
int cal(int x, int p) ;
int pow_mod(long long n, int k, int M) ;
int combination(int n, int m) ;
 int combination(int n, int m);  int main() ;
int produce_prim_number(int *prim)
{
    bool *is_composite = (bool *)alloca(1000001 * sizeof(bool));
    memset(is_composite, 0, 1000001 * sizeof(bool));
    
    int prime_count = 0;
    prim[prime_count++] = 2;
    
    for (int i = 3; i * i <= 1000000; i += 2)
    {
        if (!is_composite[i])
        {
            prim[prime_count++] = i;
            for (int j = i * i; j <= 1000000; j += i)
            {
                is_composite[j] = true;
            }
        }
    }
    
    for (int i = (i % 2 == 0 ? i + 1 : i); i <= 1000000; i += 2)
    {
        if (!is_composite[i])
        {
            prim[prime_count++] = i;
        }
    }
    
    return prime_count;
}
int cal(int x, int p)
{
    long long rec;
    int ans;

    ans = 0;
    for (rec = p; rec <= x; rec *= p)
        ans += x / rec;
    return ans;
}
int pow_mod(long long n, int k, int M)
{
    long long ans = 1LL;
    while (k)
    {
        if ((k & 1) != 0)
            ans = n * ans % M;
        n = n * n % M;
        k >>= 1;
    }
    return (int)ans;
}
int combination(int n, int m)
{
    int M = 10007;
    int prime_count;
    int prime_exponent;
    long long result = 1LL;
    int primes[1000000];
    
    prime_count = produce_prim_number(primes);
    
    for (int i = 0; i < prime_count && n >= primes[i]; ++i)
    {
        prime_exponent = cal(n, primes[i]) - cal(m, primes[i]) - cal(n - m, primes[i]);
        result = result * pow_mod(primes[i], prime_exponent, M) % M;
    }
    
    return (int)result;
}
int main()
{
    int n;
    int m;
    int result;

    while (1)
    {
        scanf("%d%d", &m, &n);
        if (m == 0 || n == 0)
        {
            break;
        }
        result = combination(m, n);
        printf("%d\n", result);
    }
    return 0;
}