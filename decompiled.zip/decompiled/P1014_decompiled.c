#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

 int main(int argc, const char **argv, const char **envp) ;
int main(int argc, const char **argv, const char **envp)
{
    int n;
    int ans;
    int t;

    scanf("%d", &n);
    t = 1;
    ans = 0;
    do
    {
        while (t < n)
        {
            n -= t;
            ++ans;
            ++t;
        }
        if (t == n && (ans & 1) == 0)
        {
            printf("1/%d", ans + 1);
            return 0;
        }
        if (t == n && (ans & 1) != 0)
        {
            printf("%d/1", ans + 1);
            return 0;
        }
        if (t > n && (ans & 1) != 0)
        {
            printf("%d/%d", n + ans - t + 1, t - n + 1);
            return 0;
        }
    } while (t <= n || (ans & 1) != 0);
    printf("%d/%d", t - n + 1, n + ans - t + 1);
    return 0;
}
