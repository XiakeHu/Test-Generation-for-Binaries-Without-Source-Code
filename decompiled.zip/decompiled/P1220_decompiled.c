#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

typedef struct {
    int place;
    int p;
} abc;

int n, pl;
int all;
int ans;
int may;
int z[1005];
abc s[1005];

int cmp(const void *a, const void *b);
void search(int now);

int cmp(const void *a, const void *b)
{
    const abc *struct_a = (const abc *)a;
    const abc *struct_b = (const abc *)b;
    return struct_a->place - struct_b->place;
}
void search(int now)
{
    int current_index;
    bool moved;

    moved = false;
    current_index = now;
    if (may <= ans)
    {
        while (z[current_index] && current_index < n)
            ++current_index;
        if (!z[current_index])
        {
            z[current_index] = 1;
            may += all * (s[current_index].place - s[now].place);
            all -= s[current_index].p;
            search(current_index);
            all += s[current_index].p;
            may -= all * (s[current_index].place - s[now].place);
            z[current_index] = 0;
            moved = true;
            current_index = now;
        }
        while (z[current_index] && current_index > 1)
            --current_index;
        if (!z[current_index])
        {
            z[current_index] = 1;
            may += all * (s[now].place - s[current_index].place);
            all -= s[current_index].p;
            search(current_index);
            all += s[current_index].p;
            may -= all * (s[now].place - s[current_index].place);
            z[current_index] = 0;
            moved = true;
        }
        if (!moved && ans > may)
            ans = may;
    }
}
int main()
{
    bool can = false;
    int i;
    int ia;

    scanf("%d%d", &n, &pl);
    memset(z, 0, sizeof(z));
    all = 0;
    ans = 0x7fffffff;
    may = 0;
    for (i = 1; i <= n; ++i)
    {
        scanf("%d%d", &s[i].p, &s[i].place);
        all += s[i].p;
        if (i == pl && !can)
        {
            pl = s[i].place;
            all -= s[i].p;
            z[i] = 1;
            can = true;
        }
    }
    qsort(&s[1], n, sizeof(abc), cmp);
    for (ia = 1; ia <= n; ++ia)
    {
        if (s[ia].place == pl)
        {
            pl = ia;
            break;
        }
    }
    search(pl);
    printf("%d", ans);
    return 0;
}