#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define MAX_N 1005

typedef struct {
    int first;
    int second;
} Pair;

int top = 0;
int ed[MAX_N * 2];
int li[MAX_N * 2];
int vi[MAX_N * 2];
int nxt[MAX_N * 2];
int beg[MAX_N];
int dn;
int pre[MAX_N];
int ppre[MAX_N];
int type[MAX_N];
double dist[MAX_N];
int undist[MAX_N][MAX_N];
int vis[MAX_N];
int unpre[MAX_N][MAX_N];

void addedge(int a, int b, int l, int v) {
    int edge_index = ++top;
    ed[edge_index] = b;
    li[edge_index] = l;
    vi[edge_index] = v;
    nxt[edge_index] = beg[a];
    beg[a] = edge_index;
}

void undisdij(int x) {
    int current_node;
    Pair *priority_queue;
    int edge_index;
    int i;

    for (i = 1; i <= dn; ++i) {
        undist[x][i] = INT_MAX;
        vis[i] = 0;
    }
    undist[x][x] = 0;
    priority_queue = (Pair *)malloc(sizeof(Pair) * (dn + 1));
    priority_queue[1].first = 0;
    priority_queue[1].second = x;
    while (!vis[1]) {
        current_node = priority_queue[1].second;
        vis[current_node] = 1;
        for (edge_index = beg[current_node]; edge_index; edge_index = nxt[edge_index]) {
            if (!vi[edge_index] && undist[x][ed[edge_index]] > undist[x][current_node] + li[edge_index]) {
                unpre[x][ed[edge_index]] = current_node;
                undist[x][ed[edge_index]] = li[edge_index] + undist[x][current_node];
                priority_queue[1].first = -undist[x][ed[edge_index]];
                priority_queue[1].second = ed[edge_index];
            }
        }
    }
    free(priority_queue);
}

void dijkstra(int s) {
    int current_node;
    Pair *priority_queue;
    int inner_loop_index;
    int edge_index;
    int outer_loop_index;

    priority_queue = (Pair *)malloc(sizeof(Pair) * (dn + 1));
    for (outer_loop_index = 1; outer_loop_index <= dn; ++outer_loop_index) {
        pre[outer_loop_index] = s;
        ppre[outer_loop_index] = s;
        type[outer_loop_index] = 0;
        dist[outer_loop_index] = (double)undist[s][outer_loop_index] / 70.0;
        priority_queue[1].first = (int)-dist[outer_loop_index];
        priority_queue[1].second = outer_loop_index;
        vis[outer_loop_index] = 0;
    }
    while (!vis[1]) {
        current_node = priority_queue[1].second;
        vis[current_node] = 1;
        for (edge_index = beg[current_node]; edge_index; edge_index = nxt[edge_index]) {
            if (vi[edge_index]) {
                if (dist[ed[edge_index]] > (double)li[edge_index] / (double)vi[edge_index] + dist[current_node]) {
                    dist[ed[edge_index]] = (double)li[edge_index] / (double)vi[edge_index] + dist[current_node];
                    type[ed[edge_index]] = 1;
                    pre[ed[edge_index]] = current_node;
                    priority_queue[1].first = (int)-dist[ed[edge_index]];
                    priority_queue[1].second = ed[edge_index];
                }
                for (inner_loop_index = 1; inner_loop_index <= dn; ++inner_loop_index) {
                    if (dist[inner_loop_index] > (double)undist[ed[edge_index]][inner_loop_index] / (double)vi[edge_index] + dist[current_node] + (double)li[edge_index] / (double)vi[edge_index]) {
                        dist[inner_loop_index] = (double)undist[ed[edge_index]][inner_loop_index] / (double)vi[edge_index] + dist[current_node] + (double)li[edge_index] / (double)vi[edge_index];
                        type[inner_loop_index] = 0;
                        pre[inner_loop_index] = current_node;
                        ppre[inner_loop_index] = ed[edge_index];
                        priority_queue[1].first = (int)-dist[inner_loop_index];
                        priority_queue[1].second = inner_loop_index;
                    }
                }
            }
        }
    }
    free(priority_queue);
}

int main() {
    int n, m, d;
    int a, b, l, v;
    int i, j;
    int da;
    int xpt, pxt;
    int *stack;
    int *stack_ptr;

    scanf("%d%d%d", &n, &m, &d);
    for (i = 1; i <= m; ++i) {
        scanf("%d%d%d%d", &a, &b, &l, &v);
        addedge(a + 1, b + 1, l, v);
        addedge(b + 1, a + 1, l, v);
    }

    da = d + 1;
    dn = n;
    for (i = 1; i <= n; ++i)
        undisdij(i);

    dijkstra(1);

    stack = (int *)malloc(sizeof(int) * (dn + 1));
    stack_ptr = stack;

    while (da != 1) {
        *stack_ptr = da;
        stack_ptr++;

        if (type[da]) {
            da = pre[da];
        } else {
            if (ppre[da] == pre[da]) {
                while (unpre[1][da] != 1) {
                    da = unpre[1][da];
                    *stack_ptr = da;
                    stack_ptr++;
                }
                break;
            }
            pxt = ppre[da];
            xpt = pre[da];
            while (pxt != da) {
                da = unpre[pxt][da];
                *stack_ptr = da;
                stack_ptr++;
            }
            da = xpt;
        }
    }

    putchar('0');
    while (--stack_ptr >= stack) {
        printf(" %d", *stack_ptr - 1);
    }

    free(stack);
    return 0;
}