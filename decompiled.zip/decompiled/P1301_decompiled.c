#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int x;
    int y;
}Point;

int m, n;
int a[110][110];
Point team[10010];
int head, tail;
int ans[10010];
int b[10010];
int dword_404060[8] = {-1, -1, 0, 1, 1, 1, 0, -1};
int dy[8] = {0, 1, 1, 1, 0, -1, -1, -1};
int pd[110][110][8];
int Min = 999999999;

int main() {
    int new_y;
    int new_x;
    int direction_idx;
    int j;
    int i;

    scanf("%d %d", &m, &n);
    for (i = 1; i <= m; ++i) {
        for (j = 1; j <= n; ++j) {
            scanf("%d", &a[i][j]);
        }
    }

    team[1].y = 1;
    team[1].x = 1;
    b[1] = 9;
    head = 0;
    tail = 1;

    do {
        head++;
        if (team[head].x == m && team[head].y == n) {
            if (ans[head] < Min) {
                Min = ans[head];
            }
        } else {
            for (direction_idx = 0; direction_idx <= 7; ++direction_idx) {
                if (direction_idx != b[head]) {
                    new_x = team[head].x + dword_404060[direction_idx] * a[team[head].x][team[head].y];
                    new_y = team[head].y + dy[direction_idx] * a[team[head].x][team[head].y];
                    if (new_x >= 1 && new_x <= m && new_y >= 1 && new_y <= n &&
                        !pd[team[head].x][team[head].y][direction_idx]) {
                        pd[team[head].x][team[head].y][direction_idx] = 1;
                        tail++;
                        team[tail].x = new_x;
                        team[tail].y = new_y;
                        ans[tail] = ans[head] + 1;
                        b[tail] = direction_idx;
                    }
                }
            }
        }
    } while (head != tail);

    if (Min == 999999999) {
        printf("NEVER");
    } else {
        printf("%d", Min);
    }
    return 0;
}