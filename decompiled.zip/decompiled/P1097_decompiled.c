#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    int key;
    int value;
}Pair;

int compare(const void *a, const void *b) ;
int main(int argc, const char **argv, const char **envp) ;

Pair statistics[1000];
int n;
int in;
int num_count;

int compare(const void *a, const void *b)
{
    const Pair *first_pair = (const Pair *)a;
    const Pair *second_pair = (const Pair *)b;
    return first_pair->key - second_pair->key;
}
int main(int argc, const char **argv, const char **envp)
{
    int current_key;
    int outer_loop_index;
    int inner_loop_index;
    int found_flag;
    int input_value;

    num_count = 0;
    scanf("%d", &n);
    for (outer_loop_index = 0; outer_loop_index < n; ++outer_loop_index)
    {
        scanf("%d", &in);
        found_flag = 0;
        for (inner_loop_index = 0; inner_loop_index < num_count; ++inner_loop_index)
        {
            current_key = statistics[inner_loop_index].key;
            if (current_key == in)
            {
                statistics[inner_loop_index].value = statistics[inner_loop_index].value + 1;
                found_flag = 1;
                break;
            }
        }
        if (!found_flag)
        {
            statistics[num_count].key = in;
            statistics[num_count].value = 1;
            num_count = num_count + 1;
        }
    }
    qsort(statistics, num_count, sizeof(Pair), compare);
    for (outer_loop_index = 0; outer_loop_index < num_count; ++outer_loop_index)
    {
        printf("%d %d\n", statistics[outer_loop_index].key, statistics[outer_loop_index].value);
    }
    return 0;
}