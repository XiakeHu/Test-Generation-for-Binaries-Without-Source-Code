#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAXN 100005
#define MAXM 1200005 // 增加边数空间
#define INF 0x3f3f3f3f

struct Edge {
    int to, nxt, flow, cost;
} edge[MAXM];

int fir[MAXN], cnt = 1;
int dis[MAXN], vis[MAXN];
int q[MAXN + 100]; // 改为全局变量
int s, t, n, m, MC, MF;

void add(int u, int v, int w, int c) {
    edge[++cnt] = (struct Edge){v, fir[u], w, -c}; fir[u] = cnt;
    edge[++cnt] = (struct Edge){u, fir[v], 0, c}; fir[v] = cnt;
}

bool spfa() {
    memset(dis, 0x3f, sizeof(dis));
    memset(vis, 0, sizeof(vis));
    int head = 0, tail = 0;
    q[tail++] = s;
    dis[s] = 0;
    vis[s] = 1;

    while (head != tail) {
        int u = q[head++];
        if (head >= MAXN) head = 0;
        vis[u] = 0;
        for (int i = fir[u]; i; i = edge[i].nxt) {
            int v = edge[i].to;
            if (edge[i].flow && dis[v] > dis[u] + edge[i].cost) {
                dis[v] = dis[u] + edge[i].cost;
                if (!vis[v]) {
                    q[tail++] = v;
                    if (tail >= MAXN) tail = 0;
                    vis[v] = 1;
                }
            }
        }
    }
    return dis[t] != INF;
}

int dfs(int u, int flow) {
    if (u == t) {
        MF += flow;
        vis[u] = 1;
        return flow;
    }
    int used = 0;
    vis[u] = 1;
    for (int i = fir[u]; i; i = edge[i].nxt) {
        int v = edge[i].to;
        if ((v == t || !vis[v]) && edge[i].flow && dis[v] == dis[u] + edge[i].cost) {
            int mi = dfs(v, (flow - used < edge[i].flow ? flow - used : edge[i].flow));
            if (mi) {
                edge[i].flow -= mi;
                edge[i ^ 1].flow += mi;
                used += mi;
                MC += mi * edge[i].cost;
            }
            if (used == flow) return used;
        }
    }
    return used;
}

void MCMF() {
    while (spfa()) {
        vis[t] = 1;
        while (vis[t]) {
            memset(vis, 0, sizeof(vis)); // 建议使用 memset
            dfs(s, 1e9); // 初始流给大一点
        }
    }
}

int main() {
    s = 0;
    t = 50000;
    int s2 = 50001;

    add(s, s2, 1, 0);
    scanf("%d%d", &n, &m);
    int sum = n * m;

    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m; ++j) {
            int k;
            scanf("%d", &k);
            add((i - 1) * m + j, (i - 1) * m + j + sum, 1, k);
        }
    }

    for (int i = 1; i < n; ++i) {
        for (int j = 1; j < m; ++j) {
            for (int k = j + 1; k <= m; ++k) {
                add((i - 1) * m + j + sum, i * m + k, 1, 0);
            }
        }
    }

    for (int i = 1; i <= m; ++i) {
        add(s2, i, 1, 0);
        add((n - 1) * m + i + sum, t, 1, 0);
    }

    MCMF();

    printf("%d\n", -MC);

    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m; ++j) {
            for (int k = fir[(i - 1) * m + j]; k; k = edge[k].nxt) {
                int v = edge[k].to;
                if (v - ((i - 1) * m + j) == sum && edge[k].flow == 0) {
                    printf("%d ", j);
                }
            }
        }
    }

    return 0;
}
