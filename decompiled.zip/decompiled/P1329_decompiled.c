#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef unsigned long long ull;
ull n, s, sum, x;
ull *f;
int *a;
int cnt = 0;

void Print();
void Dfs(int step, int ccc);

void Print()
{
    int sum = 0;
    for (int i = 1; i < n; ++i)
    {
        printf("%d ", sum);
        sum += a[i];
    }
    printf("%d\n", sum);
}

void Dfs(int step, int ccc)
{
    if (ccc <= x)
    {
        if (step == n)
        {
            if (ccc == x)
            {
                Print();
                if (++cnt == 100)
                {
                    exit(0);
                }
            }
        }
        else
        {
            a[step] = 1;
            Dfs(step + 1, n - step + ccc);
            a[step] = -1;
            Dfs(step + 1, ccc);
        }
    }
}

int main()
{
    int j;
    int i;

    scanf("%llu %llu", &n, &s);

    sum = ((n - 1) * n) >> 1;

    if ((sum + s) & 1)
    {
        puts("0");
        return 0;
    }
    else
    {
        x = (2 * s + (n - 1) * n) >> 2;

        size_t f_size = 0x14520uLL;
        f = (ull *)malloc(f_size);
        if (f)
        {
            memset(f, 0, f_size);

            size_t a_size = 0xA290uLL;
            a = (int *)malloc(a_size);
            if (a)
            {
                f[0] = 1ULL;

                for (i = 1; i < n; ++i)
                {
                    for (j = x; j >= i; --j)
                    {
                        f[j] += f[j - i];
                    }
                }

                printf("%llu\n", f[x]);

                Dfs(1, 0);

                free(f);
                free(a);
                return 0;
            }
            else
            {
                puts("Memory allocation failed");
                free(f);
                return -1;
            }
        }
        else
        {
            puts("Memory allocation failed");
            return -1;
        }
    }
}