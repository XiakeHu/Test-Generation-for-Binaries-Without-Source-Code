#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int a;
    int b;
} hhh;

int cmp(const void *a, const void *b) ;
   int cmp(const void *a, const void *b) ;
int cmp(const void *a, const void *b)
{
    const hhh *h1 = (const hhh *)a;
    const hhh *h2 = (const hhh *)b;

    if (h1->b < h2->b)
        return -1;
    if (h1->b > h2->b)
        return 1;
    if (h1->a < h2->a)
        return -1;
    if (h1->a > h2->a)
        return 1;
    return 0;
}
int main() {
    int m, n;
    int unique_count = 0;
    int result_count = 0;
    int difference;
    int found_flag;
    int start_value;
    int current_index;
    int inner_flag;
    int outer_flag;
    int k;
    int p, q;
    int i, j;
    hhh *results;
    int *unique_squares;
    char *is_square_present;

    scanf("%d%d", &n, &m);
    is_square_present = (char *)calloc(m * m + 1, 1);
    unique_squares = (int *)malloc(sizeof(int) * (m * m / 2));

    for (p = 0; p <= m; ++p) {
        for (q = p; q <= m; ++q) {
            int square_sum = p * p + q * q;
            if (!is_square_present[square_sum]) {
                unique_squares[unique_count++] = square_sum;
                is_square_present[square_sum] = 1;
            }
        }
    }

    qsort(unique_squares, unique_count, sizeof(int), (int (*)(const void *, const void *))cmp);
    results = (hhh *)malloc(sizeof(hhh) * unique_count);

    for (i = 0; i <= unique_count - n; ++i) {
        start_value = unique_squares[i];
        j = i;
        while (1) {
            ++j;
            inner_flag = 0;
            outer_flag = 0;
            difference = unique_squares[j] - unique_squares[i];
            if (j > unique_count - n + 2 || start_value + difference * (n - 1) > unique_squares[unique_count - 1])
                break;
            for (k = 2; k < n; ++k) {
                if (!is_square_present[difference * k + start_value]) {
                    inner_flag = 1;
                    break;
                }
            }
            if (!inner_flag) {
                results[result_count].a = start_value;
                results[result_count++].b = difference;
            }
            if (outer_flag)
                goto loop_end;
        }
        outer_flag = 1;
    loop_end:;
    }

    qsort(results, result_count, sizeof(hhh), cmp);
    for (i = 0; i < result_count; ++i)
        printf("%d %d\n", results[i].a, results[i].b);
    if (!result_count)
        printf("NONE");

    free(is_square_present);
    free(unique_squares);
    free(results);
    return 0;
}