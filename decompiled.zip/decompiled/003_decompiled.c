#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

int compare_lines(const void *a, const void *b) ;
int read_lines(char (*lines)[200], int max_lines) ;
void print_lines(const char (*lines)[200], int line_count) ;
void sort_lines(char (*lines)[200], int line_count) ;
int main(int argc, const char **argv, const char **envp) ;
int compare_lines(const void *a, const void *b) {
    const char *line1 = (const char *)a;
    const char *line2 = (const char *)b;
    int i = 0;
    int j = 0;
    
    while (line1[i] != '\0' && line2[j] != '\0') {
        char c1 = tolower((unsigned char)line1[i]);
        char c2 = tolower((unsigned char)line2[j]);
        
        if (c1 != c2) {
            return c1 - c2;
        }
        i++;
        j++;
    }
    
    return line1[i] - line2[j];
}
int read_lines(char (*lines)[200], int max_lines) {
    int count;
    int is_empty;
    int i;
    size_t len;
    
    for (count = 0; count < max_lines && fgets(&lines[count][0], 200, stdin); ++count) {
        len = strlen(&lines[count][0]);
        if (len && lines[count][len - 1] == '\n') {
            lines[count][len - 1] = 0;
        }
        is_empty = 1;
        for (i = 0; lines[count][i]; ++i) {
            if ((((*__ctype_b_loc())[(unsigned char)lines[count][i]] & 0x2000) == 0)) {
                is_empty = 0;
                break;
            }
        }
        if (is_empty) {
            break;
        }
    }
    return count;
}
void print_lines(const char (*lines)[200], int line_count) {
    int i;
    
    for (i = 0; i < line_count; ++i) {
        puts(&(*lines)[200 * i]);
    }
}
void sort_lines(char (*lines)[200], int line_count) {
    if (line_count > 1) {
        qsort(lines, line_count, 200, (int (*)(const void *, const void *))compare_lines);
    }
}
int main(int argc, const char **argv, const char **envp) {
    int line_count;
    char lines[100][200];
    
    puts("请输入多行文本，以空行结束:");
    line_count = read_lines(lines, 100);
    
    if (line_count) {
        sort_lines(lines, line_count);
        puts("\n===== 排序后的文本 =====");
        print_lines(lines, line_count);
    } else {
        puts("未输入任何文本。");
    }
    
    return 0;
}