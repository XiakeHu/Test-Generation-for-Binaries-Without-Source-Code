#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef long long lli;

lli ksm(lli a, lli b, lli p);

int main();

lli ksm(lli a, lli b, lli p)
{
    lli result = 1LL;
    lli base = a % p;
    while (b > 0)
    {
        if ((b & 1) != 0)
            result = (base * result) % p;
        base = (base * base) % p;
        b >>= 1;
    }
    return result;
}
int main()
{
    lli a, b, p, s;
    scanf("%lld %lld %lld", &a, &b, &p);
    s = ksm(a, b, p);
    printf("%lld^%lld mod %lld=%lld", a, b, p, s);
    return 0;
}