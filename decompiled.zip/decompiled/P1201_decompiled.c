#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef struct {
    char name[105];
    int money;
}Person;

Person people[100];
int n;
char x[105];
int have;
int l;
char buddy[105];

int compare(const void *a, const void *b) ;
   int compare(const void *a, const void *b) ;
int compare(const void *a, const void *b)
{
    const Person *pa = (const Person *)a;
    const Person *pb = (const Person *)b;
    return strcmp(pa->name, pb->name);
}
int main()
{
    int outer_loop_counter;
    int buddy_index;
    int giver_index;
    int inner_loop_counter_2;
    int inner_loop_counter_1;
    int person_index;
    int second_outer_loop_counter;
    int first_outer_loop_counter;

    scanf("%d", &n);
    for (first_outer_loop_counter = 0; first_outer_loop_counter < n; ++first_outer_loop_counter)
    {
        scanf("%s", people[first_outer_loop_counter].name);
        people[first_outer_loop_counter].money = 0;
    }
    qsort(people, n, sizeof(Person), compare);
    for (second_outer_loop_counter = 1; second_outer_loop_counter <= n; ++second_outer_loop_counter)
    {
        scanf("%s %d %d", x, &have, &l);
        if (l)
        {
            person_index = -1;
            for (inner_loop_counter_1 = 0; inner_loop_counter_1 < n; ++inner_loop_counter_1)
            {
                if (!strcmp(people[inner_loop_counter_1].name, x))
                {
                    person_index = inner_loop_counter_1;
                    break;
                }
            }
            have %= l;
            people[person_index].money = (int)((double)have - (double)(have / l) * (double)l + (double)people[person_index].money);
            for (inner_loop_counter_2 = 1; inner_loop_counter_2 <= l; ++inner_loop_counter_2)
            {
                scanf("%s", buddy);
                buddy_index = -1;
                for (giver_index = 0; giver_index < n; ++giver_index)
                {
                    if (!strcmp(people[giver_index].name, buddy))
                    {
                        buddy_index = giver_index;
                        break;
                    }
                }
                people[buddy_index].money = (int)((double)(have / l) + (double)people[buddy_index].money);
            }
        }
    }
    for (outer_loop_counter = 0; outer_loop_counter < n; ++outer_loop_counter)
        printf("%s %d\n", people[outer_loop_counter].name, people[outer_loop_counter].money);
    return 0;
}