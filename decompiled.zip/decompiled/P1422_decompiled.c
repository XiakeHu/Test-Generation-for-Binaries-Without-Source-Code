#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

 int main() ;
int main()
{
    int n;
    double b = 0.0;
    double rounded_value;

    scanf("%d", &n);

    if (n > 150)
    {
        if (n > 400)
        {
            b = (double)(n - 400) * 0.5663 + 183.52;
        }
        else
        {
            b = (double)(n - 150) * 0.4663 + 66.94499999999999;
        }
    }
    else
    {
        b = 0.4463 * (double)n;
    }

    rounded_value = floor(b * 10.0 + 0.5) / 10.0;
    printf("%.1f\n", rounded_value);

    return 0;
}
