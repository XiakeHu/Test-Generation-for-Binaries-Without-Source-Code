#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    unsigned long long data;
} Bitset;

unsigned long long to_ullong(const Bitset *bs);
Bitset *new_bitset(unsigned long long data);
unsigned long long get_bit(const Bitset *bs, int pos);
void set_bit(Bitset *bs, int pos, unsigned int value);
void delete_bitset(Bitset *bs);
int main(int argc, const char **argv, const char **envp);

unsigned long long to_ullong(const Bitset *bs)
{
    return bs->data;
}
Bitset *new_bitset(unsigned long long data)
{
    Bitset *bs;

    bs = (Bitset *)malloc(sizeof(Bitset));
    if (!bs)
        return 0;
    bs->data = data;
    return bs;
}
unsigned long long get_bit(const Bitset *bs, int pos)
{
    return (bs->data >> pos) & 1ULL;
}
void set_bit(Bitset *bs, int pos, unsigned int value)
{
    unsigned long long mask;
    unsigned long long new_data;

    mask = 1ULL << pos;
    if (value)
    {
        new_data = bs->data | mask;
    }
    else
    {
        new_data = bs->data & ~mask;
    }
    bs->data = new_data;
}
void delete_bitset(Bitset *bs)
{
    free(bs);
}
int main(int argc, const char **argv, const char **envp)
{
    unsigned long long input_value = 0;
    Bitset *binary = NULL;
    Bitset *reversed = NULL;
    int loop_counter;
    unsigned long long bit_value;

    scanf("%llu", &input_value);

    binary = new_bitset(input_value);
    reversed = new_bitset(0ULL);

    for (loop_counter = 0; loop_counter <= 15; ++loop_counter)
    {
        bit_value = get_bit(binary, loop_counter);
        set_bit(reversed, loop_counter + 16, bit_value);
    }

    for (loop_counter = 0; loop_counter <= 15; ++loop_counter)
    {
        bit_value = get_bit(binary, loop_counter + 16);
        set_bit(reversed, loop_counter, bit_value);
    }

    bit_value = to_ullong(reversed);
    printf("%llu\n", bit_value);

    delete_bitset(binary);
    delete_bitset(reversed);

    return 0;
}