#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
typedef int ll;

void deal_zero() ;
void pre_hash() ;
void pre_pow() ;
int main(int argc, const char **argv, const char **envp) ;
void deal_zero()
{
}
void pre_hash()
{
    ;
}
void pre_pow()
{
    ;
}
int main(int argc, const char **argv, const char **envp)
{
    char str[2005];
    ll num1[2005];
    ll num2[2005];
    ll fac1[2005];
    ll fac2[2005];
    int f1[2005];
    int f2[2005];
    int nexn[2005];
    int lasn[2005];
    int n;

    pre_pow();
    while (scanf("%s", str + 1) != EOF)
    {
        n = strlen(str + 1);
        pre_hash();
        deal_zero();
    }
    return 0;
}
