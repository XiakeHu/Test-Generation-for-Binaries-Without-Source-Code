#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct BSTNode {
    int v;
    struct BSTNode *ls;
    struct BSTNode *rs;
} BSTNode;

typedef struct Node {
    int key;
    struct Node *s[2];
} Node;

void Rotate(Node **rt, int d);
void BSTInsert(BSTNode **rt, int x, int d);
int getm(Node *rt, int d);
void splay(Node **rt, int x);
void Insert(Node **rt, int x);

void Rotate(Node **rt, int d)
{
    Node *tmp;

    tmp = (*rt)->s[d];
    (*rt)->s[d] = tmp->s[d ^ 1];
    tmp->s[d ^ 1] = *rt;
    *rt = tmp;
}

void BSTInsert(BSTNode **rt, int x, int d)
{
    if (*rt)
    {
        if (x >= (*rt)->v)
        {
            BSTInsert(&(*rt)->rs, x, d + 1);
        }
        else
        {
            BSTInsert(&(*rt)->ls, x, d + 1);
        }
    }
    else
    {
        *rt = (BSTNode *)malloc(sizeof(BSTNode));
        (*rt)->v = x;
        (*rt)->ls = NULL;
        (*rt)->rs = NULL;
    }
}

int getm(Node *rt, int d)
{
    if (rt->s[d] != NULL)
    {
        return getm(rt->s[d], d);
    }
    else
    {
        return rt->key;
    }
}

void splay(Node **rt, int x)
{
    int direction1;
    int direction2;

    if (x < (*rt)->key)
    {
        direction1 = 0;
    }
    else if (x == (*rt)->key)
    {
        direction1 = -1;
    }
    else
    {
        direction1 = 1;
    }

    if (direction1 != -1)
    {
        if (x < (*rt)->s[direction1]->key)
        {
            direction2 = 0;
        }
        else if (x == (*rt)->s[direction1]->key)
        {
            direction2 = -1;
        }
        else
        {
            direction2 = 1;
        }

        if (direction2 != -1)
        {
            splay(&(*rt)->s[direction1]->s[direction2], x);
            if (direction1 == direction2)
            {
                Rotate(rt, direction1);
            }
            else
            {
                Rotate(&(*rt)->s[direction1], direction2);
            }
        }
        Rotate(rt, direction1);
    }
}

void Insert(Node **rt, int x)
{
    if (*rt)
    {
        int direction = (x >= (*rt)->key) ? 1 : 0;
        Insert(&((*rt)->s[direction]), x);
    }
    else
    {
        *rt = (Node *)malloc(sizeof(Node));
        (*rt)->key = x;
        (*rt)->s[0] = NULL;
        (*rt)->s[1] = NULL;
    }
}

int main()
{
    int a;
    int n;
    BSTNode *RooT = NULL;
    Node *Root = NULL;
    int s;
    int p;
    int i;

    scanf("%d", &n);
    scanf("%d", &a);
    Insert(&Root, a);
    BSTInsert(&RooT, a, 1);
    for (i = 2; i <= n; ++i)
    {
        scanf("%d", &a);
        Insert(&Root, a);
        splay(&Root, a);
        if (Root->s[0])
            p = getm(Root->s[0], 1);
        else
            p = 0;
        if (Root->s[1])
            s = getm(Root->s[1], 0);
        else
            s = 0;
        BSTInsert(&RooT, a, 1);
    }
    return 0;
}