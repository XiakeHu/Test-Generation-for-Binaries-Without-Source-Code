#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int x;
    int y;
    int l;
    int num;
} NODE;

NODE a[100005];
NODE b[100005];
int vis[100005];

void fprint(int x) ;
typedef double LD;  LD calcx(int xx, int yy, int ll, LD k) ;
LD calcy(int xx, int yy, int ll, LD invk) ;
int cmp2(const void *a, const void *b) ;
int cmp1(const void *a, const void *b) ;
void fprint_ch(int x, char ch_0) ;
void read(int *x) ;
void work(int n, int xx, int yy) ;
int main() ;
void fprint(int x)
{
    int positive_value = x;
    if (x < 0)
    {
        putchar('-');
        positive_value = -x;
    }
    if (positive_value > 9)
        fprint(positive_value / 10);
    putchar(positive_value % 10 + '0');
}
LD calcx(int xx, int yy, int ll, LD k)
{
    LD scaled_x = (LD)xx * k;

    if (scaled_x < (LD)yy || (LD)(yy + ll) < scaled_x)
    {
        return -1.0;
    }
    else
    {
        return (LD)xx;
    }
}
LD calcy(int xx, int yy, int ll, LD invk)
{
    LD kx = (LD)yy * invk;
    if (kx < (LD)xx || (LD)(xx + ll) < kx)
        return -1.0;
    else
        return (LD)yy;
}
int cmp2(const void *a, const void *b)
{
    const NODE *node_a = (const NODE *)a;
    const NODE *node_b = (const NODE *)b;

    if (node_a->y == node_b->y)
        return node_a->x - node_b->x;
    else
        return node_a->y - node_b->y;
}
int cmp1(const void *a, const void *b)
{
    const NODE *node_a = (const NODE *)a;
    const NODE *node_b = (const NODE *)b;

    if (node_a->x == node_b->x)
        return node_a->y - node_b->y;
    else
        return node_a->x - node_b->x;
}
void fprint_ch(int x, char ch_0)
{
    fprint(x);
    putchar(ch_0);
}
void read(int *x)
{
    char c;
    int sign;

    *x = 0;
    sign = 1;
    c = getchar();
    while (c > '9' || c <= '/')
    {
        if (c == '-')
            sign = -1;
        c = getchar();
    }
    while (c <= '9' && c > '/')
    {
        *x = 10 * *x + c - '0';
        c = getchar();
    }
    *x *= sign;
}
void work(int n, int xx, int yy)
{
    int i;
    int j;
    double ret_x;
    double ret_y;
    double invk;
    double k;
    int chosen_index;
    double best_result;

    k = (double)yy / (double)xx;
    invk = (double)xx / (double)yy;
    best_result = 1000000000.0;
    chosen_index = 0;

    for (i = 1; i <= n; ++i)
    {
        ret_x = calcx(a[i].x, a[i].y, a[i].l, k);
        if (ret_x > -0.00000001)
        {
            if (ret_x < 1000000000.0)
            {
                best_result = ret_x;
                chosen_index = a[i].num;
            }
            break;
        }
    }

    for (j = 1; j <= n; ++j)
    {
        ret_y = calcy(b[j].x, b[j].y, b[j].l, invk);
        if (ret_y > -0.00000001)
        {
            if (best_result > ret_y)
                chosen_index = b[j].num;
            break;
        }
    }

    vis[chosen_index] = 1;
}
int main()
{
    int i;
    int j;
    int n;
    int ans = 0;

    read(&n);
    for (i = 1; i <= n; ++i)
    {
        read(&a[i].x);
        read(&a[i].y);
        read(&a[i].l);
        b[i].x = a[i].x;
        b[i].y = a[i].y;
        b[i].l = a[i].l;
        b[i].num = i;
        a[i].num = i;
    }

    qsort(&a[1], n, sizeof(NODE), cmp1);
    qsort(&b[1], n, sizeof(NODE), cmp2);

    for (j = 1; j <= 100000; ++j)
    {
        work(n, j, 100000);
        work(n, 100000, j);
    }

    for (i = 1; i <= n; ++i)
        ans += vis[i];

    fprint_ch(ans, 10);
    return 0;
}