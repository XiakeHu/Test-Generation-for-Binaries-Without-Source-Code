#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int y, m, d;
    int num;
    char s[50];
} student;

int n;

int compare(const void *a, const void *b);

int compare(const void *a, const void *b)
{
    const student *studentA = (const student *)a;
    const student *studentB = (const student *)b;

    if (studentA->y != studentB->y)
        return studentA->y - studentB->y;
    if (studentA->m != studentB->m)
        return studentA->m - studentB->m;
    if (studentA->d != studentB->d)
        return studentA->d - studentB->d;
    return studentB->num - studentA->num;
}
int main()
{
    student *students;
    char temp_name[50];

    scanf("%d", &n);

    students = (student *)malloc(n * sizeof(student));
    if (students == NULL) {
        return 1;
    }

    for (int i = 0; i < n; ++i) {
        scanf("%s %d %d %d", temp_name, &students[i].y, &students[i].m, &students[i].d);
        strcpy(students[i].s, temp_name);
        students[i].num = i + 1;
    }

    qsort(students, n, sizeof(student), compare);

    for (int i = 0; i < n; ++i) {
        puts(students[i].s);
    }

    free(students);

    return 0;
}