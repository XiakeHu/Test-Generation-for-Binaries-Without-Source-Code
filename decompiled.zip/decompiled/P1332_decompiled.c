#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>
#define MAX 1005
typedef struct {
    int x;
    int y;
    int Time;
}Node;

Node s[MAX * MAX];
int P[MAX][MAX];
int vis[MAX][MAX];
int tail, head;
int n, m, a, b;
int c[MAX], d[MAX], e[MAX], f[MAX];

void bfs() ;
int main() ;
void bfs()
{
    int current_x;
    int current_y;
    int current_time;

    tail = 0;
    head = 0;
    for (int i = 1; i <= a; ++i)
    {
        s[++tail].x = c[i];
        s[tail].y = d[i];
        s[tail].Time = 0;
        P[c[i]][d[i]] = 0;
    }
    while (head < tail)
    {
        current_x = s[++head].x;
        current_y = s[head].y;
        current_time = s[head].Time;

        if (current_x < n && !vis[current_x + 1][current_y])
        {
            s[++tail].x = current_x + 1;
            s[tail].y = current_y;
            s[tail].Time = current_time + 1;
            P[current_x + 1][current_y] = s[tail].Time;
            vis[current_x + 1][current_y] = 1;
        }
        if (current_x > 1 && !vis[current_x - 1][current_y])
        {
            s[++tail].x = current_x - 1;
            s[tail].y = current_y;
            s[tail].Time = current_time + 1;
            P[current_x - 1][current_y] = s[tail].Time;
            vis[current_x - 1][current_y] = 1;
        }
        if (current_y < m && !vis[current_x][current_y + 1])
        {
            s[++tail].x = current_x;
            s[tail].y = current_y + 1;
            s[tail].Time = current_time + 1;
            P[current_x][current_y + 1] = s[tail].Time;
            vis[current_x][current_y + 1] = 1;
        }
        if (current_y > 1 && !vis[current_x][current_y - 1])
        {
            s[++tail].x = current_x;
            s[tail].y = current_y - 1;
            s[tail].Time = current_time + 1;
            P[current_x][current_y - 1] = s[tail].Time;
            vis[current_x][current_y - 1] = 1;
        }
    }
}
int main()
{
    int i;
    scanf("%d%d%d%d", &n, &m, &a, &b);
    for (i = 1; i <= a; ++i)
    {
        scanf("%d%d", &c[i], &d[i]);
        vis[c[i]][d[i]] = 1;
    }
    bfs();
    for (i = 1; i <= b; ++i)
    {
        scanf("%d%d", &e[i], &f[i]);
        printf("%d\n", P[e[i]][f[i]]);
    }
    return 0;
}