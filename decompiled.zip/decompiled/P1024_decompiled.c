#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

double a, b, c, d;

double fc(double x)
{
    return d + a * x * x * x + b * x * x + c * x;
}

int main()
{
    double midpoint_value;
    double right_value;
    double left_value;
    int i;
    int solution_count = 0;
    double right_bound;
    double left_bound;

    solution_count = 0;
    scanf("%lf%lf%lf%lf", &a, &b, &c, &d);
    for (i = -100; i <= 99; ++i)
    {
        left_bound = (double)i;
        right_bound = (double)(i + 1);
        left_value = fc((double)i);
        right_value = fc(right_bound);
        if (left_value == 0.0)
        {
            printf("%.2lf ", left_bound);
            ++solution_count;
        }
        if (left_value * right_value < 0.0)
        {
            while (right_bound - left_bound >= 0.001)
            {
                midpoint_value = fc((left_bound + right_bound) / 2.0);
                if (midpoint_value * fc(right_bound) > 0.0)
                    right_bound = (left_bound + right_bound) / 2.0;
                else
                    left_bound = (left_bound + right_bound) / 2.0;
            }
            printf("%.2lf ", right_bound);
            ++solution_count;
        }
        if (solution_count == 3)
            break;
    }
    return 0;
}